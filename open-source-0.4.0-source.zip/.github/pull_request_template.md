## Summary

Describe the user-visible change and its motivation.

## Validation

- [ ] Tests added or updated
- [ ] `node --test` passes
- [ ] `npm run check` passes
- [ ] Desktop build/smoke test performed when relevant
- [ ] No secrets, user data, logs, private paths, or build artifacts added
- [ ] Documentation and changelog updated when needed

## Security review

Describe changes to path validation, approvals, sandboxing, network access, or
credential handling. Write `None` only when those areas are untouched.