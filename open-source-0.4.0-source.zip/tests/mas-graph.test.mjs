import test from 'node:test';
import assert from 'node:assert/strict';
import { StateGraph, GraphError } from '../src/core/mas/graph.mjs';

function collectEvents() {
  const events = [];
  return { events, onEvent: (event) => events.push(event) };
}

test('线性图按依赖顺序执行并合并共享状态', async () => {
  const graph = new StateGraph({ name: 'linear' });
  const order = [];
  graph.addNode('a', { run: async () => { order.push('a'); return { a: 1 }; } });
  graph.addNode('b', { deps: ['a'], run: async (state) => { order.push('b'); return { b: state.a + 1 }; } });
  graph.addNode('c', { deps: ['b'], run: async (state) => { order.push('c'); return { c: state.b + 1 }; } });
  const result = await graph.compile().run({});
  assert.equal(result.status, 'completed');
  assert.deepEqual(order, ['a', 'b', 'c']);
  assert.equal(result.state.c, 3);
  assert.equal(result.steps.length, 3);
});

test('无依赖的同层节点并发执行，并在汇合点等待全部完成', async () => {
  const graph = new StateGraph({ name: 'fanout', concurrency: 3 });
  let concurrent = 0;
  let peak = 0;
  const slow = (id, ms) => async () => {
    concurrent += 1;
    peak = Math.max(peak, concurrent);
    await new Promise((resolve) => setTimeout(resolve, ms));
    concurrent -= 1;
    return { [id]: true };
  };
  graph.addNode('a', { run: slow('a', 80) });
  graph.addNode('b', { run: slow('b', 40) });
  graph.addNode('c', { run: slow('c', 20) });
  graph.addNode('join', { deps: ['a', 'b', 'c'], run: async (state) => ({ joined: state.a && state.b && state.c }) });
  const result = await graph.compile().run({});
  assert.equal(result.status, 'completed');
  assert.equal(peak, 3, '三个节点应并发执行');
  assert.equal(result.state.joined, true);
});

test('条件边为假时下游被跳过，且跳过会级联', async () => {
  const graph = new StateGraph({ name: 'conditional' });
  graph.addNode('decide', { run: async () => ({ go: false }) });
  graph.addNode('take', {
    deps: [{ id: 'decide', when: (state) => state.go === true }],
    run: async () => ({ took: true }),
  });
  graph.addNode('after', { deps: ['take'], run: async () => ({ after: true }) });
  const { events, onEvent } = collectEvents();
  const result = await graph.compile({ onEvent }).run({});
  assert.equal(result.status, 'completed');
  assert.equal(result.state.took, undefined);
  assert.equal(result.nodes.take, 'skipped');
  assert.equal(result.nodes.after, 'skipped');
  assert.ok(events.some((event) => event.type === 'mas.node.skipped' && event.nodeId === 'take'));
});

test('节点失败后按 retries 重试，成功则继续', async () => {
  const graph = new StateGraph({ name: 'retry' });
  let attempts = 0;
  graph.addNode('flaky', {
    retries: 2,
    run: async () => {
      attempts += 1;
      if (attempts < 3) throw new Error('临时失败');
      return { ok: true };
    },
  });
  const result = await graph.compile().run({});
  assert.equal(result.status, 'completed');
  assert.equal(attempts, 3);
  assert.equal(result.steps[0].attempts, 3);
});

test('重试耗尽后按 abort 策略中断，并跳过下游节点', async () => {
  const graph = new StateGraph({ name: 'abort' });
  graph.addNode('boom', { run: async () => { throw new Error('致命失败'); } });
  graph.addNode('downstream', { deps: ['boom'], run: async () => ({ ran: true }) });
  const result = await graph.compile().run({});
  assert.equal(result.status, 'failed');
  assert.equal(result.nodes.boom, 'failed');
  assert.equal(result.nodes.downstream, 'skipped');
  assert.match(result.error.message, /致命失败/);
});

test('failurePolicy=continue 时失败不扩散到整图', async () => {
  const graph = new StateGraph({ name: 'continue' });
  graph.addNode('optional', { failurePolicy: 'continue', run: async () => { throw new Error('可选步骤失败'); } });
  graph.addNode('tail', { deps: [{ id: 'optional', optional: true }], run: async () => ({ tail: true }) });
  const result = await graph.compile().run({});
  assert.equal(result.status, 'completed');
  assert.equal(result.nodes.optional, 'failed');
  assert.equal(result.state.tail, true);
});

test('节点超时被中止并记为失败', async () => {
  const graph = new StateGraph({ name: 'timeout' });
  graph.addNode('slow', {
    timeoutMs: 60,
    run: async () => {
      await new Promise((resolve) => setTimeout(resolve, 300));
      return { done: true };
    },
  });
  const result = await graph.compile().run({});
  assert.equal(result.status, 'failed');
  assert.match(result.error.message, /超时/);
});

test('存在环时 validate 直接拒绝', () => {
  const graph = new StateGraph({ name: 'cycle' });
  graph.addNode('a', { run: async () => ({}) });
  graph.addNode('b', { deps: ['a'], run: async () => ({}) });
  graph.addEdge('b', 'a');
  assert.throws(() => graph.validate(), GraphError);
  assert.throws(() => graph.compile(), /图存在环/);
});

test('取消信号会让运行返回 cancelled 而不是 failed', async () => {
  const graph = new StateGraph({ name: 'cancel' });
  graph.addNode('wait', {
    run: async (_state, ctx) => {
      await new Promise((resolve, reject) => {
        const timer = setTimeout(resolve, 200);
        ctx.signal?.addEventListener('abort', () => { clearTimeout(timer); reject(new Error('运行已取消')); }, { once: true });
      });
      return {};
    },
  });
  const controller = new AbortController();
  setTimeout(() => controller.abort(), 40);
  const result = await graph.compile().run({}, { signal: controller.signal });
  assert.equal(result.status, 'cancelled');
});
