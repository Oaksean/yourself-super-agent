import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { loadConfig } from '../src/core/config.mjs';
import { createRuntime } from '../src/core/runtime.mjs';
import { createAgentServer } from '../src/server/server.mjs';

async function waitForTask(url, taskId, timeoutMs = 20000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const response = await fetch(`${url}/api/tasks/${encodeURIComponent(taskId)}`);
    const task = await response.json();
    if (['completed', 'failed', 'cancelled'].includes(task.status)) return task;
    await new Promise((resolve) => setTimeout(resolve, 120));
  }
  throw new Error('任务等待超时');
}

test('end-to-end user -> router -> isolated worker -> session report', { timeout: 30000 }, async (t) => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'agent-e2e-'));
  const taskFolder = path.join(root, 'selected-task-folder');
  await fs.mkdir(taskFolder);
  await fs.writeFile(path.join(taskFolder, 'README.md'), '# Demo\n\nThis is a local worker test.', 'utf8');
  const config = loadConfig({ root });
  config.port = 0;
  config.maxWorkers = 1;
  config.provider.apiKey = '';
  const runtime = createRuntime(config);
  const app = createAgentServer({ runtime });
  const url = await app.listen();
  t.after(async () => {
    await app.close();
    await fs.rm(root, { recursive: true, force: true });
  });

  const selectedWorkspace = await fs.realpath(taskFolder);
  const configResponse = await fetch(`${url}/api/config`, {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ workspace: selectedWorkspace, autoApproveWorkspaceWrites: true }),
  });
  assert.equal(configResponse.status, 200);
  const updatedConfig = await configResponse.json();
  assert.equal(updatedConfig.workspace, selectedWorkspace);
  assert.equal(updatedConfig.autoApproveWorkspaceWrites, true);

  const chatResponse = await fetch(`${url}/api/chat`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ text: '分析当前工作区并读取 README' }),
  });
  assert.equal(chatResponse.status, 200);
  const chat = await chatResponse.json();
  assert.ok(chat.sessionId);
  assert.equal(chat.tasks.length, 1);
  assert.equal(chat.tasks[0].workspace, selectedWorkspace);

  const task = await waitForTask(url, chat.tasks[0].id);
  assert.equal(task.status, 'completed');
  assert.match(task.result, /README\.md|本地路径/);

  const detail = await (await fetch(`${url}/api/sessions/${chat.sessionId}`)).json();
  assert.equal(detail.tasks[0].status, 'completed');
  assert.ok(detail.messages.some((message) => message.metadata?.kind === 'task_report'));
  assert.ok(detail.memories.length >= 1);

  const subscriptionResponse = await fetch(`${url}/api/subscriptions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ sessionId: chat.sessionId, taskId: task.id, source: 'file', matcher: { text: 'README' } }),
  });
  assert.equal(subscriptionResponse.status, 201);
  const triggerResponse = await fetch(`${url}/api/triggers`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ source: 'file', text: 'README changed', metadata: { path: 'README.md' } }),
  });
  const routed = await triggerResponse.json();
  assert.equal(routed.routed, true);
  assert.equal(routed.direct, true);
  assert.equal(routed.task.capabilities.includes('read'), true);
  const directTask = await waitForTask(url, routed.task.id);
  assert.equal(directTask.status, 'completed');
});

