import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { AgentStore } from '../src/core/db.mjs';
import { MemoryService } from '../src/core/memory.mjs';
import { toolsForCapabilities, executeTool } from '../src/worker/tools.mjs';

async function tempDir(prefix) {
  return await fs.mkdtemp(path.join(os.tmpdir(), prefix));
}

function serviceFor(store, dataDir, workspace) {
  return new MemoryService(store, { available: false }, null, null, {
    config: { dataDir, workspace, memory: { topK: 8, minScore: 0.15, maxInlineMemories: 12, indexMaxLines: 200, indexMaxBytes: 25600 } },
  });
}

test('legacy memories schema migrates before new indexes are created', async (t) => {
  const dir = await tempDir('memory-migrate-');
  const file = path.join(dir, 'agent.db');
  const legacy = new DatabaseSync(file);
  legacy.exec(`
    CREATE TABLE sessions (id TEXT PRIMARY KEY, title TEXT NOT NULL, summary TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
    CREATE TABLE memories (
      id TEXT PRIMARY KEY, session_id TEXT NOT NULL, kind TEXT NOT NULL, content TEXT NOT NULL,
      importance INTEGER NOT NULL DEFAULT 1, source_task_id TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    INSERT INTO sessions VALUES ('ses_old','旧会话','','2026-01-01T00:00:00.000Z','2026-01-01T00:00:00.000Z');
    INSERT INTO memories VALUES ('mem_old','ses_old','fact','跨版本保留的事实',3,NULL,'2026-01-01T00:00:00.000Z','2026-01-01T00:00:00.000Z');
  `);
  legacy.close();
  const store = new AgentStore(file);
  t.after(async () => { store.close(); await fs.rm(dir, { recursive: true, force: true }); });
  const columns = store.db.prepare('PRAGMA table_info(memories)').all().map((column) => column.name);
  for (const name of ['scope', 'workspace', 'status', 'confidence', 'access_count', 'fingerprint', 'supersedes_json', 'dreamed_at']) {
    assert.ok(columns.includes(name), `missing migrated column ${name}`);
  }
  const memory = store.getMemory('mem_old');
  assert.equal(memory.content, '跨版本保留的事实');
  assert.equal(memory.status, 'active');
  assert.ok(store.db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='memory_transcripts'").get());
  assert.ok(store.db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='memory_pages'").get());
});

test('messages automatically become immutable transcripts', async (t) => {
  const dir = await tempDir('memory-transcript-');
  const store = new AgentStore(path.join(dir, 'agent.db'));
  t.after(async () => { store.close(); await fs.rm(dir, { recursive: true, force: true }); });
  const session = store.createSession('流水');
  store.addMessage({ sessionId: session.id, role: 'user', content: '原始用户消息' });
  store.addMessage({ sessionId: session.id, role: 'assistant', content: '原始助手消息', metadata: { kind: 'report' } });
  const transcripts = store.listTranscripts({ sessionId: session.id, limit: 10 });
  assert.equal(transcripts.length, 2);
  assert.ok(transcripts.some((item) => item.source === 'message.user' && item.content === '原始用户消息'));
  assert.ok(transcripts.some((item) => item.source === 'message.assistant' && item.metadata.kind === 'report'));
});

test('raw transcripts are isolated by workspace when requested', async (t) => {
  const dir = await tempDir('memory-transcript-workspace-');
  const store = new AgentStore(path.join(dir, 'agent.db'));
  t.after(async () => { store.close(); await fs.rm(dir, { recursive: true, force: true }); });
  const session = store.createSession('流水隔离');
  store.addTranscript({ sessionId: session.id, source: 'worker', content: '项目 A 流水', workspace: 'D:\\workspace-a' });
  store.addTranscript({ sessionId: session.id, source: 'worker', content: '项目 B 流水', workspace: 'D:\\workspace-b' });
  const records = store.listTranscripts({ workspace: 'D:\\workspace-a', limit: 20 });
  assert.equal(records.length, 1);
  assert.equal(records[0].content, '项目 A 流水');
});

test('project and global memories cross sessions but never cross workspaces', async (t) => {
  const dir = await tempDir('memory-scope-');
  const workspaceA = path.join(dir, 'workspace-a');
  const workspaceB = path.join(dir, 'workspace-b');
  await fs.mkdir(workspaceA); await fs.mkdir(workspaceB);
  const store = new AgentStore(path.join(dir, 'agent.db'));
  t.after(async () => { store.close(); await fs.rm(dir, { recursive: true, force: true }); });
  const first = store.createSession('第一个会话');
  const second = store.createSession('第二个会话');
  const memory = serviceFor(store, dir, workspaceA);
  const project = await memory.remember({ sessionId: first.id, content: '项目接口使用 4317 端口', scope: 'project', importance: 4, workspace: workspaceA });
  const global = await memory.remember({ sessionId: first.id, content: '用户偏好中文回复', scope: 'global', importance: 4, workspace: workspaceA });
  const duplicate = await memory.remember({ sessionId: first.id, content: '项目接口使用 4317 端口', scope: 'project', importance: 4, workspace: workspaceA });
  assert.equal(duplicate.id, project.id, 'fingerprint deduplication should reuse the note');
  const sameWorkspace = await memory.recall(second.id, '4317 端口', { workspace: workspaceA });
  assert.ok(sameWorkspace.some((item) => item.id === project.id));
  assert.ok(sameWorkspace.some((item) => item.id === global.id));
  const otherWorkspace = await memory.recall(second.id, '4317 端口', { workspace: workspaceB });
  assert.equal(otherWorkspace.length, 0);
});

test('deduplication is isolated by memory scope and explicit search limits are respected', async (t) => {
  const dir = await tempDir('memory-scope-dedupe-');
  const workspace = path.join(dir, 'workspace');
  await fs.mkdir(workspace);
  const store = new AgentStore(path.join(dir, 'agent.db'));
  t.after(async () => { store.close(); await fs.rm(dir, { recursive: true, force: true }); });
  const session = store.createSession('作用域去重');
  const memory = new MemoryService(store, { available: false }, null, null, {
    config: { dataDir: dir, workspace, memory: { topK: 4, minScore: 0.1, maxInlineMemories: 3, indexMaxLines: 200, indexMaxBytes: 25600 } },
  });
  const project = await memory.remember({ sessionId: session.id, content: '相同内容必须按作用域隔离', scope: 'project', workspace });
  const global = await memory.remember({ sessionId: session.id, content: '相同内容必须按作用域隔离', scope: 'global', workspace });
  const local = await memory.remember({ sessionId: session.id, content: '相同内容必须按作用域隔离', scope: 'session', workspace });
  assert.equal(new Set([project.id, global.id, local.id]).size, 3);
  for (let index = 0; index < 18; index += 1) {
    await memory.remember({ sessionId: session.id, content: `可搜索记忆 ${index}`, scope: 'project', workspace, dedupe: false });
  }
  const recalled = await memory.recall(session.id, '', { workspace, topK: 16 });
  assert.equal(recalled.length, 16);
  const defaultRecall = await memory.recall(session.id, '', { workspace });
  assert.equal(defaultRecall.length, 3);
});

test('Dreaming decay still runs when the model returns keep operations', async (t) => {
  const dir = await tempDir('memory-dream-decay-');
  const workspace = path.join(dir, 'workspace');
  await fs.mkdir(workspace);
  const store = new AgentStore(path.join(dir, 'agent.db'));
  t.after(async () => { store.close(); await fs.rm(dir, { recursive: true, force: true }); });
  const session = store.createSession('衰减');
  const llm = {
    available: true,
    config: { routerModel: 'stub' },
    chatJson: async () => ({ json: { operations: [{ type: 'keep' }], pages: [] } }),
  };
  const memory = new MemoryService(store, llm, null, null, {
    config: { dataDir: dir, workspace, memory: { maxInlineMemories: 12, dreaming: { decayPerMonth: 0.1 } } },
  });
  const record = await memory.remember({ sessionId: session.id, content: '六十天前的旧事实', scope: 'project', workspace, confidence: 0.8 });
  store.db.prepare('UPDATE memories SET created_at=? WHERE id=?').run(new Date(Date.now() - 60 * 86400000).toISOString(), record.id);
  const run = await memory.dream({ workspace, trigger: 'test' });
  assert.equal(run.status, 'completed');
  assert.ok(store.getMemory(record.id).confidence < 0.8);
});

test('prompt index is hard-capped at 200 lines and 25 KB', async (t) => {
  const dir = await tempDir('memory-index-');
  const workspace = path.join(dir, 'workspace');
  await fs.mkdir(workspace);
  const store = new AgentStore(path.join(dir, 'agent.db'));
  t.after(async () => { store.close(); await fs.rm(dir, { recursive: true, force: true }); });
  const session = store.createSession('索引');
  const memory = serviceFor(store, dir, workspace);
  for (let index = 0; index < 260; index += 1) {
    await memory.remember({
      sessionId: session.id, kind: 'fact', scope: 'project', workspace,
      content: `第 ${index} 条长期记忆：${'这是一段需要被压缩的真实事实。'.repeat(18)}`,
      importance: (index % 5) + 1, confidence: 0.8, dedupe: false,
    });
  }
  const index = await memory.buildPromptIndex(workspace);
  assert.ok(index.lineCount <= 200);
  assert.ok(index.bytes <= 25600, `index was ${index.bytes} bytes`);
  assert.ok(index.path.endsWith('MEMORY.md'));
  const file = await fs.readFile(index.path, 'utf8');
  assert.equal(Buffer.byteLength(file, 'utf8'), index.bytes);
});

test('Dreaming deduplicates notes, writes Wiki pages and preserves facts', async (t) => {
  const dir = await tempDir('memory-dream-');
  const workspace = path.join(dir, 'workspace');
  await fs.mkdir(workspace);
  const store = new AgentStore(path.join(dir, 'agent.db'));
  t.after(async () => { store.close(); await fs.rm(dir, { recursive: true, force: true }); });
  const session = store.createSession('Dreaming');
  const memory = serviceFor(store, dir, workspace);
  const first = await memory.remember({ sessionId: session.id, content: '部署路径固定为 D:\\Agent\\app', scope: 'project', workspace, importance: 4, dedupe: false });
  const second = await memory.remember({ sessionId: session.id, content: '部署路径固定为 D:\\Agent\\app', scope: 'project', workspace, importance: 3, dedupe: false });
  const settled = memory.settleMemoryFeedback(first.id, { helpful: false });
  assert.ok(settled.confidence < 0.66);
  const run = await memory.dream({ workspace, trigger: 'test' });
  assert.equal(run.status, 'completed');
  assert.ok(run.stats.merged >= 1);
  assert.ok(run.stats.pages >= 1);
  assert.ok(['active', 'dormant'].includes(store.getMemory(first.id).status));
  assert.equal(store.getMemory(second.id).status, 'superseded');
  const pages = await memory.listPages(workspace, { status: 'all', withContent: true });
  assert.ok(pages.length >= 1);
  assert.ok(pages.some((page) => /部署路径|fact/.test(`${page.title} ${page.content_md}`)));
  const index = await memory.buildPromptIndex(workspace);
  assert.match(index.content, /Memory Notes/);
  await assert.doesNotReject(fs.access(index.path));
});

test('worker can only access memory through read-only IPC tools', async () => {
  const names = toolsForCapabilities(['read']).map((definition) => definition.function.name);
  assert.ok(names.includes('memory_search'));
  assert.ok(names.includes('memory_read_page'));
  const calls = [];
  const result = await executeTool('memory_search', { query: '架构' }, {
    requestMemory: async (name, args) => { calls.push({ name, args }); return [{ id: 'mem_1', content: 'Router / Worker' }]; },
  });
  assert.equal(calls[0].name, 'memory_search');
  assert.equal(result[0].id, 'mem_1');
  const page = await executeTool('memory_read_page', { slug: 'architecture' }, {
    requestMemory: async (name, args) => { calls.push({ name, args }); return { slug: 'architecture', content_md: '# ok' }; },
  });
  assert.equal(page.slug, 'architecture');
});
