import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { resolveSandbox, buildSandboxCommand, findHost, provisionAppContainer } from '../src/core/sandbox.mjs';

const projectRoot = path.resolve(import.meta.dirname, '..');

test('sandbox resolution reports a tier and never forbids a safe fallback by default', () => {
  const sandbox = resolveSandbox({ sandboxMode: 'auto', projectRoot });
  assert.ok(['jobobject', 'appcontainer', 'process'].includes(sandbox.tier));
  if (sandbox.tier === 'jobobject' || sandbox.tier === 'appcontainer') {
    assert.ok(sandbox.host);
  }
});

test('sandbox can be explicitly disabled', () => {
  const sandbox = resolveSandbox({ sandboxMode: 'off', projectRoot });
  assert.equal(sandbox.tier, 'process');
});

test('buildSandboxCommand wraps the runner inside the host when sandboxing', () => {
  const sandbox = resolveSandbox({ sandboxMode: 'auto', projectRoot });
  const command = buildSandboxCommand({ sandbox, execPath: 'node', runnerPath: 'runner.mjs', tier: 'process-readonly' });
  if (sandbox.host) {
    assert.equal(command.sandboxed, true);
    assert.equal(command.args[0], '--');
    assert.equal(command.args[1], 'node');
    assert.equal(command.args[2], 'runner.mjs');
    assert.ok(command.env.SANDBOX_MODE);
  } else {
    assert.equal(command.sandboxed, false);
  }
});

test('sandbox host binary is present and executable on this machine', { skip: process.platform !== 'win32' }, () => {
  const host = findHost(projectRoot);
  assert.ok(host, 'native/WindowsSandboxHost.exe 缺失，请运行 scripts/build-sandbox.ps1');
  assert.ok(fs.statSync(host).size > 0);
});
