import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { loadConfig } from '../src/core/config.mjs';
import { createRuntime } from '../src/core/runtime.mjs';
import { createAgentServer } from '../src/server/server.mjs';

async function waitForRun(url, runId, timeoutMs = 10000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const runs = await (await fetch(`${url}/api/memory/runs`)).json();
    const run = runs.find((item) => item.id === runId);
    if (run && ['completed', 'failed'].includes(run.status)) return run;
    await new Promise((resolve) => setTimeout(resolve, 80));
  }
  throw new Error('memory run timeout');
}

test('long-term memory API exposes records, overview, wiki, transcripts and Dreaming', { timeout: 20000 }, async (t) => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'memory-api-'));
  const workspace = path.join(root, 'workspace');
  await fs.mkdir(workspace);
  const config = loadConfig({ root });
  config.port = 0;
  config.workspace = workspace;
  config.allowedRoots = [workspace];
  config.provider.apiKey = '';
  config.memory.dreaming.enabled = false;
  const runtime = createRuntime(config);
  const app = createAgentServer({ runtime });
  const url = await app.listen();
  t.after(async () => {
    await app.close();
    await fs.rm(root, { recursive: true, force: true });
  });

  const session = await (await fetch(`${url}/api/sessions`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ title: 'API 记忆' }) })).json();
  const createdResponse = await fetch(`${url}/api/memory/records`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ sessionId: session.id, content: 'API 写入的项目记忆', scope: 'project', importance: 4 }),
  });
  assert.equal(createdResponse.status, 201);
  const created = await createdResponse.json();
  assert.equal(created.scope, 'project');

  const records = await (await fetch(`${url}/api/memory/records?sessionId=${session.id}&status=all&workspace=${encodeURIComponent(workspace)}`)).json();
  assert.ok(records.some((item) => item.id === created.id));

  const patched = await (await fetch(`${url}/api/memory/records/${created.id}`, {
    method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ pinned: true, content: '已更新的项目记忆' }),
  })).json();
  assert.equal(patched.pinned, true);
  assert.equal(patched.content, '已更新的项目记忆');

  const feedback = await (await fetch(`${url}/api/memory/records/${created.id}/feedback`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ helpful: true }),
  })).json();
  assert.ok(feedback.confidence >= 0.66);

  const overview = await (await fetch(`${url}/api/memory/overview?sessionId=${session.id}&workspace=${encodeURIComponent(workspace)}`)).json();
  assert.ok(overview.counts.total >= 1);
  assert.ok(overview.index.maxLines <= 200);

  const runResponse = await fetch(`${url}/api/memory/dream`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ workspace }) });
  assert.equal(runResponse.status, 202);
  const run = await runResponse.json();
  const finished = await waitForRun(url, run.id);
  assert.equal(finished.status, 'completed');
  const pages = await (await fetch(`${url}/api/memory/pages?workspace=${encodeURIComponent(workspace)}&status=all`)).json();
  assert.ok(Array.isArray(pages));

  const deleted = await (await fetch(`${url}/api/memory/records/${created.id}`, { method: 'DELETE' })).json();
  assert.equal(deleted.deleted, true);
});
