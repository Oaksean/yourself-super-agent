import test from 'node:test';
import assert from 'node:assert/strict';
import { RuleEngine, inferCapabilities } from '../src/core/rules.mjs';

test('RuleEngine keeps simple chat as direct user routing without local hints', () => {
  const result = new RuleEngine().evaluate({ source: 'user', text: '你好，解释一下什么是记忆分层' });
  assert.equal(result.shouldRoute, true);
  assert.equal(result.hints.needsLocalAccess, false);
  assert.deepEqual(result.hints.capabilities, ['read']);
});

test('RuleEngine escalates write and execute capabilities', () => {
  const result = new RuleEngine().evaluate({ source: 'user', text: '修改文件并运行测试' });
  assert.deepEqual(result.hints.capabilities, ['read', 'write', 'execute']);
  assert.equal(result.hints.isolation, 'process-exec-gated');
});

test('inferCapabilities de-duplicates capability flags', () => {
  assert.deepEqual(inferCapabilities('读取 README，然后写入报告，最后执行 npm test'), ['read', 'write', 'execute']);
});
