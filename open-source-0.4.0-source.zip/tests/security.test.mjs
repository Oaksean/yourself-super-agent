import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { resolveSafePath, assertNoSecretFile } from '../src/core/security.mjs';

test('resolveSafePath permits only configured roots', async (t) => {
  const base = await fs.mkdtemp(path.join(os.tmpdir(), 'agent-security-'));
  const root = path.join(base, 'workspace');
  const outside = path.join(base, 'outside.txt');
  await fs.mkdir(root);
  await fs.writeFile(outside, 'secret');
  t.after(async () => fs.rm(base, { recursive: true, force: true }));

  assert.equal(resolveSafePath(path.join(root, 'a.txt'), [root]), path.join(root, 'a.txt'));
  assert.throws(() => resolveSafePath(outside, [root]), /越界/);
  assert.throws(() => resolveSafePath(path.join(root, '..', 'outside.txt'), [root]), /越界/);
});

test('assertNoSecretFile blocks secrets and private keys', () => {
  assert.throws(() => assertNoSecretFile('C:/workspace/.env'), /敏感/);
  assert.throws(() => assertNoSecretFile('C:/workspace/data/secrets.json'), /敏感/);
  assert.throws(() => assertNoSecretFile('C:/workspace/key.pem'), /敏感/);
  assert.doesNotThrow(() => assertNoSecretFile('C:/workspace/README.md'));
});
