import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { AgentStore } from '../src/core/db.mjs';
import { WatcherService } from '../src/core/watchers/watcher-service.mjs';

async function waitFor(predicate, timeoutMs = 8000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (await predicate()) return true;
    await new Promise((resolve) => setTimeout(resolve, 120));
  }
  return false;
}

test('watcher service turns file changes into triggers', async (t) => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'agent-watch-'));
  const store = new AgentStore(path.join(dir, 'test.db'));
  const session = store.createSession('监听测试');
  const config = {
    workspace: dir,
    allowedRoots: [dir],
    watchers: { enabled: true, debounceMs: 120, ignorePatterns: [] },
  };
  const service = new WatcherService({ config, store });
  t.after(async () => { service.stop(); store.close(); await fs.rm(dir, { recursive: true, force: true }); });

  const triggers = [];
  service.on('trigger', (trigger) => triggers.push(trigger));
  service.start();
  const watcher = service.register({ sessionId: session.id, path: dir, pattern: '\\.md$', events: ['add', 'change'] });
  assert.equal(watcher.session_id, session.id);

  await fs.writeFile(path.join(dir, 'note.md'), 'hello', 'utf8');
  const saw = await waitFor(() => triggers.length > 0);
  assert.ok(saw, 'expected a file trigger');
  assert.equal(triggers[0].source, 'file');
  assert.match(triggers[0].metadata.relative, /note\.md/);
  assert.ok(store.listWatcherEvents(10).length >= 1);
});

test('watcher service ignores non-matching patterns and unregisters cleanly', async (t) => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'agent-watch-ignore-'));
  const store = new AgentStore(path.join(dir, 'test.db'));
  const session = store.createSession('过滤测试');
  const config = { workspace: dir, allowedRoots: [dir], watchers: { enabled: true, debounceMs: 80, ignorePatterns: [] } };
  const service = new WatcherService({ config, store });
  t.after(async () => { service.stop(); store.close(); await fs.rm(dir, { recursive: true, force: true }); });

  const triggers = [];
  service.on('trigger', (trigger) => triggers.push(trigger));
  service.start();
  const watcher = service.register({ sessionId: session.id, path: dir, pattern: '\\.md$' });

  await fs.writeFile(path.join(dir, 'ignored.txt'), 'x', 'utf8');
  await new Promise((resolve) => setTimeout(resolve, 500));
  assert.equal(triggers.length, 0);

  const removed = service.unregister(watcher.id);
  assert.equal(removed.active, false);
  assert.equal(service.snapshot().active, 0);
});
