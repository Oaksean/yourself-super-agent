import test from 'node:test';
import assert from 'node:assert/strict';
import { embedText, cosineSimilarity, EMBEDDING_DIM } from '../src/core/embed/local-embedder.mjs';
import { EmbeddingService } from '../src/core/embed/embedding-service.mjs';

test('local embedder produces normalized fixed-dimension vectors', () => {
  const vector = embedText('Router 与 Worker 双层架构');
  assert.equal(vector.length, EMBEDDING_DIM);
  const norm = Math.sqrt(vector.reduce((sum, value) => sum + value * value, 0));
  assert.ok(Math.abs(norm - 1) < 1e-9, `expected unit norm, got ${norm}`);
  assert.deepEqual(embedText('Router 与 Worker 双层架构'), vector);
});

test('local embedder ranks related text above unrelated text', () => {
  const query = embedText('本地智能体 Router Worker 架构');
  const related = embedText('Router 与 Worker 双层智能体架构分派');
  const unrelated = embedText('今天天气很好适合出门散步');
  assert.ok(cosineSimilarity(query, related) > cosineSimilarity(query, unrelated));
});

test('embedding service falls back to local embedder without a remote model', async () => {
  const service = new EmbeddingService({ provider: { apiKey: '', baseUrl: '', embeddingModel: '' }, config: { memory: { embeddingDim: 384 } } });
  const vector = await service.embed('测试文本');
  assert.equal(vector.length, 384);
  assert.equal(service.model, 'local-hash-384');
});
