import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { AgentStore } from '../src/core/db.mjs';
import { MemoryService } from '../src/core/memory.mjs';
import { EmbeddingService } from '../src/core/embed/embedding-service.mjs';

function createService(store) {
  const embeddings = new EmbeddingService({ provider: {}, config: { memory: { embeddingDim: 384 } } });
  return { embeddings, memory: new MemoryService(store, { available: false }, null, embeddings) };
}

test('memory service indexes and semantically recalls related memories', async (t) => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'agent-memory-'));
  const store = new AgentStore(path.join(dir, 'test.db'));
  t.after(async () => { store.close(); await fs.rm(dir, { recursive: true, force: true }); });

  const session = store.createSession('记忆测试');
  const { memory } = createService(store);
  const facts = [
    '项目使用 Router 与 Worker 双层架构，Router 不直接操作文件。',
    '长期记忆存储在 SQLite 的 memories 表中，并带向量索引。',
    '用户偏好用中文回复，代码注释保持简洁。',
    '周末计划去爬山，天气不错。',
  ];
  for (const content of facts) {
    const stored = store.addMemory({ sessionId: session.id, kind: 'fact', content, importance: 3 });
    await memory.indexMemory(stored);
  }

  assert.equal(memory.stats(session.id).indexed, 4);

  const recalled = await memory.recall(session.id, 'Router 和 Worker 是怎么分工的？', { minScore: 0.05 });
  assert.ok(recalled.length >= 1);
  assert.match(recalled[0].content, /Router/);
  assert.ok(recalled[0].similarity > 0);
});

test('recall falls back to importance ordering when nothing matches', async (t) => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'agent-memory-fallback-'));
  const store = new AgentStore(path.join(dir, 'test.db'));
  t.after(async () => { store.close(); await fs.rm(dir, { recursive: true, force: true }); });

  const session = store.createSession('回退测试');
  const { memory } = createService(store);
  store.addMemory({ sessionId: session.id, kind: 'fact', content: '低优先级琐事', importance: 1 });
  const important = store.addMemory({ sessionId: session.id, kind: 'decision', content: '重要架构决定', importance: 5 });
  await memory.indexMemory(important);

  const recalled = await memory.recall(session.id, 'zzzzzzzz 完全无关的查询', { minScore: 0.99 });
  assert.ok(recalled.some((item) => item.id === important.id));
});
