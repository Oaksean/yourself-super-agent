import test from 'node:test';
import assert from 'node:assert/strict';
import { findHost, provisionAppContainer, ensureAppContainerAccess, resolveSandbox } from '../src/core/sandbox.mjs';
import path from 'node:path';

const projectRoot = path.resolve(import.meta.dirname, '..');

test('auto mode prefers Job Object and never silently selects AppContainer', () => {
  const sandbox = resolveSandbox({ sandboxMode: 'auto', projectRoot });
  if (sandbox.host) assert.notEqual(sandbox.tier, 'appcontainer');
});

test('explicit appcontainer mode selects the AppContainer tier', { skip: process.platform !== 'win32' }, () => {
  const sandbox = resolveSandbox({ sandboxMode: 'appcontainer', projectRoot });
  assert.equal(sandbox.tier, 'appcontainer');
  assert.equal(sandbox.mode, 'appcontainer');
});

test('AppContainer provisioning is bounded and shallow by default', { skip: process.platform !== 'win32' }, async () => {
  const host = findHost(projectRoot);
  if (!host) return;
  const started = Date.now();
  const result = provisionAppContainer({ host, readPaths: [projectRoot] });
  const elapsed = Date.now() - started;
  assert.ok(elapsed < 60000, `provisioning took too long: ${elapsed}ms`);
  assert.equal(typeof result.ok, 'boolean');
  assert.ok(result.sid === null || /^S-1-15-2-/.test(result.sid));
});

test('ensureAppContainerAccess tolerates a missing host without throwing', () => {
  const result = ensureAppContainerAccess({ host: null, roots: ['C:/nope'] });
  assert.equal(result.ok, false);
});
