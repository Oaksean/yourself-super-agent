import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { AgentStore } from '../src/core/db.mjs';
import { EventBus } from '../src/core/events.mjs';
import { RuleEngine } from '../src/core/rules.mjs';
import { Router } from '../src/core/router.mjs';
import { CollaborationCoordinator } from '../src/core/collaboration.mjs';
import { nowIso } from '../src/core/ids.mjs';

async function waitFor(predicate, timeoutMs = 3000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 15));
  }
  throw new Error('等待条件超时');
}

test('Router 将多任务计划升级为协作组，并只在组完成后写入一份最终报告', { timeout: 8000 }, async (t) => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'agent-router-collab-'));
  const store = new AgentStore(path.join(root, 'agent.db'));
  const events = new EventBus();
  const manager = {
    enqueued: [],
    enqueue(id) { this.enqueued.push(id); },
    cancel(id, reason) {
      store.updateTask(id, { status: 'cancelled', error: reason, finished_at: nowIso() });
      events.emit({ type: 'task.cancelled', task: store.getTask(id) });
    },
  };
  const llm = {
    available: true,
    async chatJson() {
      return { json: {
        decision: 'delegate', reply: '将并行分析并独立校验。', runTitle: '路由协作测试',
        failurePolicy: 'continue',
        tasks: [
          { title: '分析', agentRole: 'researcher', prompt: '分析工作区', capabilities: ['read'], expectedOutput: '分析证据' },
          { title: '校验', agentRole: 'reviewer', prompt: '校验分析结论', capabilities: ['read'], dependsOn: [0], verification: { required: true }, expectedOutput: '校验结论' },
        ],
      } };
    },
    async chat(messages) {
      const text = messages.map((message) => message.content).join('\n');
      return { content: text.includes('Agent 1') ? '统一交付：分析通过独立校验。' : '统一交付：全部分支已完成。' };
    },
  };
  const memory = {
    contextFor: () => ({ recentMessages: [] }),
    summaryForPrompt: async () => '',
    indexMemory: async () => {},
    recordTaskResult: async () => {},
  };
  const config = {
    workspace: root, allowedRoots: [root], taskMaxAttempts: 2,
    provider: { routerModel: 'mock-router', workerModel: 'mock-worker' },
    collaboration: { maxAgents: 5, timeoutMs: 60000 },
  };
  let router;
  const collaboration = new CollaborationCoordinator({
    config, store, manager, events, logger: { warn() {}, info() {} },
    onSettled: (run, tasks) => router.summarizeCollaboration(run, tasks),
  });
  router = new Router({
    config, store, llm, memory, manager, collaboration,
    rules: new RuleEngine(), events, logger: { warn() {}, info() {} },
  });
  t.after(async () => {
    collaboration.close();
    store.close();
    await fs.rm(root, { recursive: true, force: true });
  });

  const result = await router.handleUserMessage({ text: '请并行分析并让另一个 Agent 独立校验' });
  assert.ok(result.run?.id);
  assert.equal(result.tasks.length, 2);
  assert.equal(manager.enqueued.length, 1, '只应启动无依赖的上游 Agent');
  assert.equal(result.assistant.metadata.collaborationRunId, result.run.id);

  const [analyze, review] = result.tasks;
  store.updateTask(analyze.id, { status: 'completed', result: '分析通过', finished_at: nowIso() });
  events.emit({ type: 'task.completed', task: store.getTask(analyze.id) });
  await waitFor(() => manager.enqueued.includes(review.id));
  assert.match(store.getTask(review.id).prompt, /分析通过/);
  assert.equal(store.listMessages(result.sessionId).filter((message) => message.metadata?.kind === 'task_report').length, 0);

  store.updateTask(review.id, { status: 'completed', result: '校验通过', finished_at: nowIso() });
  events.emit({ type: 'task.completed', task: store.getTask(review.id) });
  await waitFor(() => store.getCollaborationRun(result.run.id).status === 'completed');
  await waitFor(() => store.listMessages(result.sessionId).some((message) => message.metadata?.kind === 'collaboration_report'));
  const reports = store.listMessages(result.sessionId).filter((message) => message.metadata?.kind === 'collaboration_report');
  assert.equal(reports.length, 1);
  assert.match(reports[0].content, /统一交付/);
});
