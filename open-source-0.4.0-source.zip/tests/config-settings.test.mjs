import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { loadConfig, publicConfig, updateLocalSettings } from '../src/core/config.mjs';

test('model settings and API key persist across reloads', (t) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'agent-settings-'));
  const dataDir = path.join(root, 'data');
  const logDir = path.join(root, 'logs');
  const previous = {
    AGENT_DATA_DIR: process.env.AGENT_DATA_DIR,
    AGENT_LOG_DIR: process.env.AGENT_LOG_DIR,
    AGENT_WORKSPACE: process.env.AGENT_WORKSPACE,
    OPENAI_BASE_URL: process.env.OPENAI_BASE_URL,
    OPENAI_MODEL: process.env.OPENAI_MODEL,
  };
  process.env.AGENT_DATA_DIR = dataDir;
  process.env.AGENT_LOG_DIR = logDir;
  process.env.AGENT_WORKSPACE = root;
  delete process.env.OPENAI_BASE_URL;
  delete process.env.OPENAI_MODEL;

  t.after(() => {
    for (const [key, value] of Object.entries(previous)) {
      if (value == null) delete process.env[key];
      else process.env[key] = value;
    }
    fs.rmSync(root, { recursive: true, force: true });
  });

  const config = loadConfig({ root });
  const taskFolder = path.join(root, 'chosen-task-folder');
  fs.mkdirSync(taskFolder);
  const saved = updateLocalSettings(config, {
    baseUrl: 'https://example.test/v1/',
    routerModel: 'router-test',
    workerModel: 'worker-test',
    apiKey: 'sk-test-secret',
    autoApproveCommands: true,
    workspace: taskFolder,
  });

  assert.equal(saved.provider.baseUrl, 'https://example.test/v1');
  assert.equal(saved.provider.routerModel, 'router-test');
  assert.equal(saved.provider.workerModel, 'worker-test');
  assert.equal(saved.provider.model, 'router-test');
  assert.equal(saved.provider.hasApiKey, true);
  assert.equal(Object.hasOwn(saved.provider, 'apiKey'), false);
  assert.equal(saved.workspace, fs.realpathSync.native(taskFolder));
  assert.ok(saved.allowedRoots.some((entry) => path.resolve(entry).toLowerCase() === path.resolve(taskFolder).toLowerCase()));

  const settingsFile = path.join(dataDir, 'config.local.json');
  const secretsFile = path.join(dataDir, 'secrets.json');
  const settings = JSON.parse(fs.readFileSync(settingsFile, 'utf8'));
  const secrets = JSON.parse(fs.readFileSync(secretsFile, 'utf8'));
  assert.equal(settings.provider.baseUrl, 'https://example.test/v1');
  assert.equal(settings.provider.workerModel, 'worker-test');
  assert.equal(settings.workspace, fs.realpathSync.native(taskFolder));
  assert.ok(Array.isArray(settings.allowedRoots));
  assert.equal(secrets.provider.apiKey, 'sk-test-secret');

  // The desktop shell no longer injects AGENT_WORKSPACE, so verify that the
  // folder saved from the UI is the source of truth across restarts.
  delete process.env.AGENT_WORKSPACE;
  const reloaded = loadConfig({ root });
  const visible = publicConfig(reloaded);
  assert.equal(visible.provider.baseUrl, 'https://example.test/v1');
  assert.equal(visible.provider.routerModel, 'router-test');
  assert.equal(visible.provider.workerModel, 'worker-test');
  assert.equal(visible.provider.hasApiKey, true);
  assert.equal(visible.autoApproveCommands, true);
  assert.equal(visible.workspace, fs.realpathSync.native(taskFolder));

  assert.throws(
    () => updateLocalSettings(reloaded, { workspace: path.join(root, 'missing-folder') }),
    /任务文件夹不存在或无法访问/,
  );

  updateLocalSettings(reloaded, { autoApproveWorkspaceWrites: true, autoApproveCommands: false });
  const reloadedAgain = publicConfig(loadConfig({ root }));
  assert.equal(reloadedAgain.autoApproveWorkspaceWrites, true);
  assert.equal(reloadedAgain.autoApproveCommands, false);
  assert.equal(reloadedAgain.provider.hasApiKey, true);
  assert.equal(reloadedAgain.workspace, fs.realpathSync.native(taskFolder));
});
