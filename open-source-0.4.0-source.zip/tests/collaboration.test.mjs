import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { AgentStore } from '../src/core/db.mjs';
import { EventBus } from '../src/core/events.mjs';
import { CollaborationCoordinator, validateCollaborationPlan } from '../src/core/collaboration.mjs';
import { nowIso } from '../src/core/ids.mjs';

async function waitFor(predicate, timeoutMs = 2500) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 15));
  }
  throw new Error('等待条件超时');
}

async function setup(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'agent-collab-'));
  const store = new AgentStore(path.join(root, 'agent.db'));
  const events = new EventBus();
  const manager = {
    enqueued: [], cancelled: [],
    enqueue(id) { this.enqueued.push(id); },
    cancel(id, reason) {
      this.cancelled.push(id);
      store.updateTask(id, { status: 'cancelled', error: reason, finished_at: nowIso() });
      events.emit({ type: 'task.cancelled', task: store.getTask(id) });
    },
  };
  const settled = [];
  const coordinator = new CollaborationCoordinator({
    config: {
      workspace: root,
      allowedRoots: [root],
      taskMaxAttempts: 2,
      collaboration: { maxAgents: 5, timeoutMs: 60_000 },
    },
    store,
    manager,
    events,
    logger: { warn() {}, info() {} },
    onSettled: async (run) => { settled.push(run.id); return `最终交付：${run.title}`; },
  });
  const session = store.createSession('测试协作');
  t.after(async () => {
    coordinator.close();
    store.close();
    await fs.rm(root, { recursive: true, force: true });
  });
  return { root, store, events, manager, coordinator, settled, session };
}

function complete(store, events, taskId, result) {
  store.updateTask(taskId, { status: 'completed', result, finished_at: nowIso() });
  events.emit({ type: 'task.completed', task: store.getTask(taskId) });
}

function fail(store, events, taskId, error) {
  store.updateTask(taskId, { status: 'failed', error, finished_at: nowIso() });
  events.emit({ type: 'task.failed', task: store.getTask(taskId) });
}

test('DAG 只调度就绪 Agent，并按上下游交接且只统一汇总一次', async (t) => {
  const { store, events, manager, coordinator, settled, session } = await setup(t);
  const created = await coordinator.createRun({
    sessionId: session.id,
    title: '依赖与并行',
    goal: '测试 DAG',
    tasks: [
      { title: '研究', prompt: '收集材料', agentRole: 'researcher', capabilities: ['read'] },
      { title: '实现', prompt: '完成实现', agentRole: 'implementer', capabilities: ['read', 'write'], isolation: 'process-workspace-write', dependsOn: [0] },
      { title: '配置分析', prompt: '分析配置', agentRole: 'researcher', capabilities: ['read'] },
      { title: '校验', prompt: '独立校验全部产物', agentRole: 'reviewer', capabilities: ['read'], dependsOn: [1, 2], verification: { required: true } },
    ],
  });
  const [research, implement, config, review] = created.tasks;
  assert.deepEqual(new Set(manager.enqueued), new Set([research.id, config.id]));

  complete(store, events, research.id, '研究结果：关键证据 E1');
  await waitFor(() => manager.enqueued.includes(implement.id));
  const handedToImplement = store.getTask(implement.id);
  assert.match(handedToImplement.prompt, /研究结果：关键证据 E1/);
  assert.match(handedToImplement.prompt, /中心化协作交接上下文/);

  complete(store, events, config.id, '配置结果：端口 4317');
  await new Promise((resolve) => setTimeout(resolve, 40));
  assert.equal(manager.enqueued.includes(review.id), false, '校验节点必须等待实现节点');

  complete(store, events, implement.id, '实现结果：文件已更新');
  await waitFor(() => manager.enqueued.includes(review.id));
  const handedToReview = store.getTask(review.id);
  assert.match(handedToReview.prompt, /研究结果：关键证据 E1/);
  assert.match(handedToReview.prompt, /实现结果：文件已更新/);
  assert.match(handedToReview.prompt, /配置结果：端口 4317/);

  complete(store, events, review.id, '校验通过：pass');
  await waitFor(() => store.getCollaborationRun(created.run.id).status === 'completed');
  await new Promise((resolve) => setTimeout(resolve, 40));
  assert.equal(settled.length, 1, '协作组只能产生一次最终汇总');
  assert.equal(store.getCollaborationRun(created.run.id).summary, '最终交付：依赖与并行');
  const reports = store.listMessages(session.id).filter((message) => message.metadata?.kind === 'collaboration_report');
  assert.equal(reports.length, 0, '测试回调不应绕过 Router 直接写入消息');
});

test('failurePolicy=continue 会隔离失败分支并保留并行成功结果', async (t) => {
  const { store, events, manager, coordinator, settled, session } = await setup(t);
  const created = await coordinator.createRun({
    sessionId: session.id,
    title: '容错协作',
    goal: '测试失败隔离',
    failurePolicy: 'continue',
    tasks: [
      { title: '失败上游', prompt: '会失败', capabilities: ['read'] },
      { title: '依赖节点', prompt: '依赖失败上游', capabilities: ['read'], dependsOn: [0] },
      { title: '独立节点', prompt: '独立完成', capabilities: ['read'] },
    ],
  });
  const [upstream, dependent, independent] = created.tasks;
  fail(store, events, upstream.id, '模拟失败');
  await waitFor(() => store.getTask(dependent.id).status === 'failed');
  complete(store, events, independent.id, '独立结果');
  await waitFor(() => store.getCollaborationRun(created.run.id).status === 'partial');
  assert.equal(store.getTask(dependent.id).supervisor.dependencyFailure, true);
  assert.equal(settled.length, 1);
  assert.equal(manager.enqueued.includes(dependent.id), false);
});

test('循环依赖和超过上限的 Agent 计划在执行前被拒绝', () => {
  assert.throws(() => validateCollaborationPlan([
    { title: 'A', prompt: 'A', dependsOn: [1] },
    { title: 'B', prompt: 'B', dependsOn: [0] },
  ]), /循环/);
  assert.throws(() => validateCollaborationPlan(Array.from({ length: 6 }, (_, index) => ({ title: `A${index}`, prompt: 'x' }))), /上限/);
});

test('协作任务字段可持久化并在旧数据库迁移后读取', async (t) => {
  const { store, session } = await setup(t);
  const task = store.createTask({
    sessionId: session.id,
    title: '迁移检查',
    prompt: 'x',
    status: 'blocked',
    runId: 'col_test',
    agentRole: 'reviewer',
    dependsOn: ['task_a'],
    handoff: { evidence: true },
    verification: { required: true },
    collaborationOrder: 2,
  });
  const loaded = store.getTask(task.id);
  assert.equal(loaded.runId, 'col_test');
  assert.equal(loaded.agentRole, 'reviewer');
  assert.deepEqual(loaded.dependsOn, ['task_a']);
  assert.deepEqual(loaded.handoff, { evidence: true });
  assert.equal(loaded.collaborationOrder, 2);
});
