import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { AgentStore } from '../src/core/db.mjs';
import { EventBus } from '../src/core/events.mjs';
import { WorkerManager } from '../src/core/worker-manager.mjs';
import { Watchdog } from '../src/core/watchdog.mjs';

const logger = {
  info() {},
  warn() {},
  error() {},
  debug() {},
};

test('legacy task tables gain persisted supervision fields', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'agent-migrate-'));
  const file = path.join(root, 'agent.db');
  const legacy = new DatabaseSync(file);
  legacy.exec(`
    CREATE TABLE tasks (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      title TEXT NOT NULL,
      prompt TEXT NOT NULL,
      type TEXT NOT NULL,
      status TEXT NOT NULL,
      capabilities_json TEXT NOT NULL,
      isolation TEXT NOT NULL,
      workspace TEXT,
      expected_output TEXT,
      result TEXT,
      error TEXT,
      progress TEXT,
      worker_pid INTEGER,
      created_at TEXT NOT NULL,
      started_at TEXT,
      finished_at TEXT
    );
  `);
  legacy.close();

  const store = new AgentStore(file);
  const columns = store.db.prepare('PRAGMA table_info(tasks)').all().map((column) => column.name);
  assert.ok(columns.includes('attempt'));
  assert.ok(columns.includes('max_attempts'));
  assert.ok(columns.includes('last_heartbeat_at'));
  assert.ok(columns.includes('supervisor_json'));
  store.close();
});

test('watchdog asks the manager to recover a stalled task instead of cancelling it', async () => {
  const calls = [];
  const manager = {
    active: new Map([['task_1', {
      task: { id: 'task_1', sessionId: 'ses_1' },
      lastActivity: Date.now() - 200000,
      lastProgress: '正在执行 list_files',
      repeatedProgress: 0,
      partialResult: '',
    }]]),
    async recover(...args) { calls.push(args); },
  };
  const events = [];
  const watchdog = new Watchdog({
    manager,
    store: { addEvent() {} },
    events: { emit(event) { events.push(event); } },
    logger,
    intervalMs: 1000,
    stallMs: 1000,
  });

  await watchdog.check();
  assert.equal(calls.length, 1);
  assert.match(calls[0][1], /无心跳/);
  assert.equal(calls[0][2].retryable, true);
  assert.equal(events[0].action, 'retry');
});

test('worker manager retries once and only fails after attempts are exhausted', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'agent-supervisor-'));
  const config = {
    projectRoot: process.cwd(),
    workspace: root,
    allowedRoots: [root],
    dataDir: root,
    logDir: root,
    maxWorkers: 0,
    taskTimeoutMs: 30000,
    taskMaxAttempts: 2,
    taskRetryDelayMs: 60000,
    taskHeartbeatMs: 1000,
    watchdogIntervalMs: 1000,
    watchdogStallMs: 5000,
    sandboxMode: 'off',
    sandboxMemoryMb: 256,
    sandboxAllowChildren: false,
    allowProcessFallback: true,
    provider: { workerModel: 'test-model' },
  };
  const store = new AgentStore(path.join(root, 'agent.db'));
  const session = store.createSession('监督测试');
  const created = store.createTask({
    sessionId: session.id,
    title: '长任务',
    prompt: '执行一个长任务',
    maxAttempts: 2,
  });
  const manager = new WorkerManager({
    config,
    store,
    llm: { chat: async () => ({ content: '' }) },
    events: new EventBus(),
    logger,
    memory: { recordTaskResult: async () => {} },
  });

  const first = await manager.recover(created.id, '测试停滞');
  assert.equal(first.status, 'queued');
  assert.equal(first.attempt, 2);
  assert.match(first.progress, /自动恢复/);

  const final = await manager.recover(created.id, '再次停滞');
  assert.equal(final.status, 'failed');
  assert.match(final.error, /已尝试 2\/2 轮/);

  const restarted = manager.retry(created.id, '用户重新执行');
  assert.equal(restarted.status, 'queued');
  assert.equal(restarted.attempt, 1);
  assert.match(restarted.progress, /重新排队/);
  manager.close();
  store.close();
});

