import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { readFile, listFiles, searchText, writeFile } from '../src/worker/tools.mjs';

test('worker tools stay inside workspace and support approved writes', async (t) => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'agent-tools-'));
  await fs.writeFile(path.join(root, 'hello.txt'), 'alpha\nbeta needle\ngamma', 'utf8');
  t.after(async () => fs.rm(root, { recursive: true, force: true }));
  const context = { workspace: root, roots: [root], requestApproval: async () => true };

  const listed = await listFiles({ path: root, depth: 1 }, context);
  assert.equal(listed.entries.some((entry) => entry.path === 'hello.txt'), true);
  const listedRelative = await listFiles({ path: '.', depth: 1 }, context);
  assert.equal(listedRelative.root, root);
  assert.equal(listedRelative.entries.some((entry) => entry.path === 'hello.txt'), true);
  const read = await readFile({ path: path.join(root, 'hello.txt') }, context);
  assert.match(read.content, /needle/);
  const relativeRead = await readFile({ path: 'hello.txt' }, context);
  assert.match(relativeRead.content, /needle/);
  const searched = await searchText({ query: 'needle', path: root }, context);
  assert.equal(searched.matches.length, 1);
  const written = await writeFile({ path: path.join(root, 'out.txt'), content: 'result' }, context);
  assert.equal(written.bytes, 6);
  assert.equal(await fs.readFile(path.join(root, 'out.txt'), 'utf8'), 'result');
  await writeFile({ path: 'relative-out.txt', content: 'relative' }, context);
  assert.equal(await fs.readFile(path.join(root, 'relative-out.txt'), 'utf8'), 'relative');
});

test('worker tools reject denied writes', async (t) => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'agent-tools-denied-'));
  t.after(async () => fs.rm(root, { recursive: true, force: true }));
  const context = { workspace: root, roots: [root], requestApproval: async () => false };
  await assert.rejects(() => writeFile({ path: path.join(root, 'denied.txt'), content: 'x' }, context), /拒绝/);
});
