import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { loadConfig } from '../src/core/config.mjs';
import { openStore } from '../src/core/db.mjs';
import { EventBus } from '../src/core/events.mjs';
import { createLogger } from '../src/core/logger.mjs';
import { MasService } from '../src/core/mas/pipeline.mjs';

const PAGE_TEXT = [
  '多智能体系统通过任务分解、消息传递与共享记忆，把复杂目标拆给多个专业智能体共同完成。',
  'LangGraph 用状态图显式定义智能体之间的流转逻辑，支持分支、循环与条件路由。',
  'AutoGen 把多智能体协作建模成群聊，由 GroupChatManager 负责轮流发言与消息路由。',
  '引用校验的价值在于：模型生成的每条论断都能被回抓到原文，而不是只靠模型自述。',
].join('\n');

const DUPLICATE_CLAIM_QUOTE = 'LangGraph 用状态图显式定义智能体之间的流转逻辑，支持分支、循环与条件路由。';

function fakeLlm({ failWriter = false } = {}) {
  const calls = [];
  return {
    calls,
    async chatJson(messages) {
      const system = messages[0]?.content || '';
      const user = messages[1]?.content || '';
      calls.push({ kind: 'json', system: system.slice(0, 40) });
      if (system.includes('目标分析')) {
        return {
          json: {
            question: '多智能体协同的主流架构与落地边界是什么？',
            boundary: '只讨论 LLM 多智能体编排，不含传统 MAS 控制论',
            deliverable: '一份带证据链的技术调研报告',
            audiences: ['技术决策者'],
            outline: ['结论', '架构范式', '框架对比', '风险边界', '落地建议'],
            subQuestions: [
              { id: 'q1', title: '架构范式', focus: '中心化与去中心化的取舍', queries: ['多智能体协同 架构'] },
              { id: 'q2', title: '框架实现', focus: '主流框架的状态与通信机制', queries: ['LangGraph StateGraph'] },
              { id: 'q3', title: '风险边界', focus: '收敛与引用可信度', queries: ['多智能体 引用校验'] },
            ],
          },
          content: '{}', usage: { total_tokens: 120 },
        };
      }
      if (system.includes('任务拆解')) {
        assert.ok(user.includes('研究问题'), '拆解提示词应带上研究问题');
        return {
          json: {
            subtasks: [
              { id: 't1', title: '架构范式', focus: '中心化与去中心化编排的差异', queries: ['多智能体协同 架构'] },
              { id: 't2', title: '框架实现', focus: '状态图与群聊两种实现路径', queries: ['LangGraph StateGraph'] },
              { id: 't3', title: '风险边界', focus: '引用可信度与收敛风险', queries: ['多智能体 校验'] },
            ],
          },
          content: '{}', usage: { total_tokens: 140 },
        };
      }
      if (system.includes('检索分析')) {
        return {
          json: {
            claims: [
              { text: '多智能体系统用任务分解与共享记忆协同完成复杂目标', quote: '多智能体系统通过任务分解、消息传递与共享记忆，把复杂目标拆给多个专业智能体共同完成。', sourceId: 'S1', confidence: 'high' },
              { text: 'LangGraph 以状态图显式定义智能体流转', quote: DUPLICATE_CLAIM_QUOTE, sourceId: 'S1', confidence: 'high' },
            ],
            gaps: ['缺少成本对比数据'],
            notes: '证据强度中等',
          },
          content: '{}', usage: { total_tokens: 260 },
        };
      }
      if (system.includes('仲裁 Agent')) {
        return {
          json: { decision: 'ship', reason: '引用通过率与审校均达标', mustFix: [], openRisks: [] },
          content: '{}', usage: { total_tokens: 90 },
        };
      }
      if (system.includes('审校 Agent')) {
        return {
          json: {
            score: 86,
            verdict: 'pass',
            issues: [{ severity: 'low', where: '第 3 节', problem: '缺少成本对比', fix: '补充 token 成本估算' }],
            unsupportedClaims: [],
            summary: '结构与引用基本达标',
          },
          content: '{}', usage: { total_tokens: 180 },
        };
      }
      return { json: {}, content: '{}', usage: { total_tokens: 10 } };
    },
    async chat(messages) {
      calls.push({ kind: 'text' });
      if (failWriter) throw new Error('撰写服务不可用');
      const system = messages[0]?.content || '';
      assert.ok(system.includes('撰写 Agent'), '写作节点应使用撰写提示词');
      const user = messages[1]?.content || '';
      return {
        content: [
          '# 多智能体协同技术调研',
          '',
          '## 结论',
          '中心化编排在可控性与可审计性上更优，适合作为首版落地形态 [1]。',
          '',
          '## 架构与实现',
          '状态图把 Agent 之间的流转显式建模，使编排逻辑可测试 [2]。',
          '群聊式协作把协调隐含在对话轮次里，灵活但不易审计。',
          '',
          '## 风险边界',
          '引用必须回抓原文校验，否则“共识”只是模型自述。',
          `证据缺口：${user.includes('成本') ? '成本对比数据缺失' : '见附录'}，需要在后续补齐。`,
          '',
          '## 落地建议',
          '先以 3-5 个 Agent 的中心化集群做 POC，再考虑分层扩容。',
        ].join('\n'),
        usage: { total_tokens: 420 },
      };
    },
  };
}

function fakeTools() {
  const stat = { searches: 0, fetches: 0 };
  return {
    stat,
    searchWeb: async (query) => {
      stat.searches += 1;
      return {
        query,
        backend: 'baidu',
        errors: [],
        results: [
          { title: '多智能体协同综述', url: 'https://example.com/ma-survey', snippet: '任务分解与共享记忆', backend: 'baidu' },
          { title: 'LangGraph 状态图', url: 'https://example.com/langgraph', snippet: '状态图编排', backend: 'baidu' },
        ],
      };
    },
    fetchPage: async (url) => {
      stat.fetches += 1;
      return { ok: true, status: 200, url, title: '样例页面', text: PAGE_TEXT, chars: PAGE_TEXT.length, note: null };
    },
  };
}

async function waitForRun(service, runId, timeoutMs = 25000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const run = service.detail(runId)?.run;
    if (run && ['completed', 'failed', 'cancelled'].includes(run.status)) return run;
    await new Promise((resolve) => setTimeout(resolve, 120));
  }
  throw new Error('协同运行等待超时');
}

test('调研流水线端到端：并行检索 → 引用校验 → 写作审校仲裁 → 落盘', { timeout: 40000 }, async (t) => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'mas-e2e-'));
  const workspace = path.join(root, 'workspace');
  await fs.mkdir(workspace, { recursive: true });
  const config = loadConfig({ root });
  config.workspace = workspace;
  config.provider.apiKey = '';
  const store = openStore(config);
  const events = new EventBus();
  const eventTypes = [];
  events.subscribe((event) => eventTypes.push(event.type));
  const tools = fakeTools();
  const llm = fakeLlm();
  const service = new MasService({
    config,
    store,
    llm,
    events,
    logger: createLogger({}),
    memory: null,
    toolset: { searchWeb: tools.searchWeb, fetchPage: tools.fetchPage },
  });

  t.after(async () => {
    await service.close();
    store.close();
    await fs.rm(root, { recursive: true, force: true });
  });

  const run = service.createRun({ topic: '多智能体协同架构选型', depth: 2, maxRevisions: 1 });
  assert.equal(run.status, 'queued');
  const finished = await waitForRun(service, run.id);

  assert.equal(finished.status, 'completed', finished.error || '');
  assert.equal(finished.metrics.decision, 'ship');
  assert.equal(finished.metrics.rounds, 1);

  const detail = service.detail(run.id);
  const nodeIds = detail.steps.map((step) => step.nodeId);
  for (const expected of ['brief', 'plan', 'scout_1', 'scout_2', 'scout_3', 'verify', 'write', 'review', 'arbitrate', 'finalize']) {
    assert.ok(nodeIds.includes(expected), `缺少节点步骤 ${expected}`);
  }

  // 三个检索 Agent 并行执行，绝不串行
  const scouts = detail.steps.filter((step) => step.nodeId.startsWith('scout_'));
  assert.equal(scouts.length, 3);
  assert.ok(scouts.every((step) => step.status === 'completed'));

  const state = finished.state;
  assert.equal(state.verification.total, 6, '3 个检索 Agent × 2 条论断');
  assert.equal(state.verification.passRate, 1, '示例页面均含原句，回抓应全部通过');
  assert.ok(state.claims.every((claim) => claim.verified?.ok));
  assert.equal(state.report.writeStatus, 'written');

  const reportFile = state.report.path;
  assert.ok(reportFile && reportFile.startsWith(workspace), '报告应写入工作区');
  const content = await fs.readFile(reportFile, 'utf8');
  assert.match(content, /# 多智能体协同架构选型/);
  assert.match(content, /附录 A · 证据清单与校验结果/);
  assert.match(content, /引用回抓通过率 100%/);
  await fs.access(state.report.verifyPath);

  assert.ok(llm.calls.length >= 7, `LLM 调用次数应覆盖全部角色，实际 ${llm.calls.length}`);
  assert.ok(tools.stat.searches >= 3);
  assert.ok(tools.stat.fetches >= 3);
  assert.ok(eventTypes.includes('mas.run.started'));
  assert.ok(eventTypes.includes('mas.node.completed'));
  assert.ok(eventTypes.includes('mas.run.completed'));

  const artifacts = store.listMasArtifacts(run.id);
  assert.equal(artifacts.filter((item) => item.kind === 'report').length, 1);
  assert.equal(artifacts.filter((item) => item.kind === 'verification').length, 1);
});

test('写作节点失败时整轮判失败，且不会产生报告产物', { timeout: 30000 }, async (t) => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'mas-fail-'));
  const workspace = path.join(root, 'workspace');
  await fs.mkdir(workspace, { recursive: true });
  const config = loadConfig({ root });
  config.workspace = workspace;
  config.provider.apiKey = '';
  const store = openStore(config);
  const service = new MasService({
    config, store, llm: fakeLlm({ failWriter: true }), events: new EventBus(),
    logger: createLogger({}), memory: null, toolset: fakeTools(),
  });
  t.after(async () => {
    await service.close();
    store.close();
    await fs.rm(root, { recursive: true, force: true });
  });

  const run = service.createRun({ topic: '失败路径验证', depth: 1, maxRevisions: 0 });
  const finished = await waitForRun(service, run.id);
  assert.equal(finished.status, 'failed');
  assert.match(finished.error, /撰写服务不可用/);
  assert.equal(service.report(run.id), null);
});

test('取消正在运行的协同任务会进入 cancelled 终态', { timeout: 30000 }, async (t) => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'mas-cancel-'));
  const workspace = path.join(root, 'workspace');
  await fs.mkdir(workspace, { recursive: true });
  const config = loadConfig({ root });
  config.workspace = workspace;
  config.provider.apiKey = '';
  const store = openStore(config);
  // 让检索阶段足够慢，以便在运行中途取消
  const slowSearch = async () => {
    await new Promise((resolve) => setTimeout(resolve, 60));
    return { results: [{ title: 'a', url: 'https://example.com/a', snippet: '', backend: 'baidu' }], backend: 'baidu', errors: [] };
  };
  const service = new MasService({
    config, store, llm: fakeLlm(), events: new EventBus(), logger: createLogger({}), memory: null,
    toolset: { searchWeb: slowSearch, fetchPage: fakeTools().fetchPage },
  });
  t.after(async () => {
    await service.close();
    store.close();
    await fs.rm(root, { recursive: true, force: true });
  });

  const run = service.createRun({ topic: '取消路径验证', depth: 3, maxRevisions: 1 });
  await new Promise((resolve) => setTimeout(resolve, 120));
  service.cancel(run.id);
  const finished = await waitForRun(service, run.id);
  assert.equal(finished.status, 'cancelled');
});
