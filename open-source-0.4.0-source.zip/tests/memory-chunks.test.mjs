import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { AgentStore } from '../src/core/db.mjs';
import { MemoryService, chunkText } from '../src/core/memory.mjs';
import { EmbeddingService } from '../src/core/embed/embedding-service.mjs';

test('chunkText splits long memories into retrieval-sized pieces', () => {
  const long = `${'项目说明。'.repeat(200)}`;
  const chunks = chunkText(long);
  assert.ok(chunks.length > 1);
  assert.ok(chunks.every((chunk) => chunk.length <= 320));
  assert.deepEqual(chunkText('短句。'), ['短句。']);
  assert.deepEqual(chunkText(''), []);
});

test('chunk-level recall finds a relevant sentence inside a long noisy memory', async (t) => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'agent-chunk-'));
  const store = new AgentStore(path.join(dir, 'test.db'));
  t.after(async () => { store.close(); await fs.rm(dir, { recursive: true, force: true }); });

  const session = store.createSession('分块召回');
  const embeddings = new EmbeddingService({ provider: {}, config: { memory: { embeddingDim: 384 } } });
  const memory = new MemoryService(store, { available: false }, null, embeddings);

  const noisy = [
    '以下是一次工作区扫描的冗长输出，包含大量无关文件路径。',
    'bin/super-agent.mjs',
    'src/core/router.mjs',
    '工程采用微 VM gVisor 来隔离任意执行型 Worker。',
    'logs/server.out.log',
    'data/agent.db',
  ].join('\n');
  const stored = store.addMemory({ sessionId: session.id, kind: 'fact', content: noisy, importance: 3 });
  await memory.indexMemory(stored);

  assert.ok(memory.stats(session.id).chunks >= 2);
  const recalled = await memory.recall(session.id, '任意执行型 Worker 用什么隔离？', { minScore: 0.02 });
  assert.ok(recalled.length >= 1);
  assert.ok(recalled.some((item) => item.matchedChunk && item.matchedChunk.includes('gVisor')));
});
