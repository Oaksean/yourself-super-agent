// WindowsSandboxHost
// Confines a Worker process tree inside a Windows Job Object and optionally
// launches it inside an AppContainer profile. Built with the in-box
// .NET Framework compiler (C# 5), so it has no external dependencies.
//
//   WindowsSandboxHost.exe [--probe] -- <executable> [args...]
//
// Environment:
//   SANDBOX_MODE             job | appcontainer   (default: job)
//   SANDBOX_MEMORY_MB        per-process memory cap (default: 0 = off)
//   SANDBOX_ALLOW_CHILDREN   0|1                  (default: 1)
//   SANDBOX_ALLOW_BREAKAWAY  0|1                  (default: 0)
//   SANDBOX_APPCONTAINER     AppContainer name    (default: local-super-agent-worker)

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

internal static class Program
{
    private const uint JobObjectLimitActiveProcess = 0x00000008;
    private const uint JobObjectLimitProcessMemory = 0x00000100;
    private const uint JobObjectLimitBreakawayOk = 0x00000800;
    private const uint JobObjectLimitKillOnJobClose = 0x00002000;

    private const int JobObjectExtendedLimitInfoClass = 9;

    private const uint CreateSuspended = 0x00000004;
    private const uint CreateNoWindow = 0x08000000;
    private const uint CreateUnicodeEnvironment = 0x00000400;
    private const uint ExtendedStartupInfoPresent = 0x00080000;
    private const uint StartfUseStdHandles = 0x00000100;
    private const uint HandleFlagInherit = 0x00000001;
    private const uint StillActive = 259;
    private static readonly IntPtr ProcThreadAttributeSecurityCapabilities = new IntPtr(0x00020009);

    private const int StdInputHandle = -10;
    private const int StdOutputHandle = -11;
    private const int StdErrorHandle = -12;

    [StructLayout(LayoutKind.Sequential)]
    private struct JobObjectBasicLimitInformation
    {
        public long PerProcessUserTimeLimit;
        public long PerJobUserTimeLimit;
        public uint LimitFlags;
        public UIntPtr MinimumWorkingSetSize;
        public UIntPtr MaximumWorkingSetSize;
        public uint ActiveProcessLimit;
        public UIntPtr Affinity;
        public uint PriorityClass;
        public uint SchedulingClass;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct IoCounters
    {
        public ulong ReadOperationCount;
        public ulong WriteOperationCount;
        public ulong OtherOperationCount;
        public ulong ReadTransferCount;
        public ulong WriteTransferCount;
        public ulong OtherTransferCount;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct JobObjectExtendedLimitInformation
    {
        public JobObjectBasicLimitInformation BasicLimitInformation;
        public IoCounters IoInfo;
        public UIntPtr ProcessMemoryLimit;
        public UIntPtr JobMemoryLimit;
        public UIntPtr PeakProcessMemoryUsed;
        public UIntPtr PeakJobMemoryUsed;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct StartupInfo
    {
        public int cb;
        public string lpReserved;
        public string lpDesktop;
        public string lpTitle;
        public int dwX;
        public int dwY;
        public int dwXSize;
        public int dwYSize;
        public int dwXCountChars;
        public int dwYCountChars;
        public int dwFillAttribute;
        public int dwFlags;
        public short wShowWindow;
        public short cbReserved2;
        public IntPtr lpReserved2;
        public IntPtr hStdInput;
        public IntPtr hStdOutput;
        public IntPtr hStdError;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct StartupInfoEx
    {
        public StartupInfo StartupInfo;
        public IntPtr lpAttributeList;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct ProcessInformation
    {
        public IntPtr hProcess;
        public IntPtr hThread;
        public int dwProcessId;
        public int dwThreadId;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct SecurityCapabilities
    {
        public IntPtr AppContainerSid;
        public IntPtr Capabilities;
        public uint CapabilityCount;
        public uint Reserved;
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr CreateJobObject(IntPtr attributes, string name);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool SetInformationJobObject(IntPtr job, int infoClass, IntPtr info, uint length);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool AssignProcessToJobObject(IntPtr job, IntPtr process);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool TerminateJobObject(IntPtr job, uint exitCode);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool TerminateProcess(IntPtr process, uint exitCode);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool CloseHandle(IntPtr handle);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool GetExitCodeProcess(IntPtr process, out uint exitCode);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern uint ResumeThread(IntPtr thread);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr GetStdHandle(int which);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool SetHandleInformation(IntPtr handle, uint mask, uint flags);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool CreateProcess(
        string applicationName,
        StringBuilder commandLine,
        IntPtr processAttributes,
        IntPtr threadAttributes,
        bool inheritHandles,
        uint creationFlags,
        IntPtr environment,
        string currentDirectory,
        ref StartupInfo startupInfo,
        out ProcessInformation processInformation);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool CreateProcess(
        string applicationName,
        StringBuilder commandLine,
        IntPtr processAttributes,
        IntPtr threadAttributes,
        bool inheritHandles,
        uint creationFlags,
        IntPtr environment,
        string currentDirectory,
        ref StartupInfoEx startupInfo,
        out ProcessInformation processInformation);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool InitializeProcThreadAttributeList(IntPtr attributeList, int attributeCount, int flags, ref IntPtr size);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool UpdateProcThreadAttribute(IntPtr attributeList, uint flags, IntPtr attribute, IntPtr value, IntPtr size, IntPtr previousValue, IntPtr returnSize);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern void DeleteProcThreadAttributeList(IntPtr attributeList);

    [DllImport("userenv.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern int CreateAppContainerProfile(string name, string displayName, string description, IntPtr capabilities, uint capabilityCount, out IntPtr sid);

    [DllImport("userenv.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern int DeriveAppContainerSidFromAppContainerName(string name, out IntPtr sid);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool FreeSid(IntPtr sid);

    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool ConvertSidToStringSid(IntPtr sid, out IntPtr stringSid);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr LocalFree(IntPtr handle);
    private static IntPtr jobHandle = IntPtr.Zero;
    private static IntPtr processHandle = IntPtr.Zero;
    private static IntPtr threadHandle = IntPtr.Zero;

    private static int Main(string[] rawArgs)
    {
        // Output is deliberately left in the console's default encoding. All
        // messages and the JSON/SID payloads written to stdout are pure ASCII,
        // and forcing UTF-8 on a redirected handle corrupts them on Windows.

        var args = new List<string>(rawArgs);
        if (args.Count > 0 && args[0] == "--") args.RemoveAt(0);

        bool probe = args.Count > 0 && args[0] == "--probe";
        if (probe) args.RemoveAt(0);

        string mode = ReadString("SANDBOX_MODE", "job").ToLowerInvariant();
        bool appContainer = mode == "appcontainer";

        if (probe)
        {
            Console.WriteLine("{\"ok\":true,\"mode\":\"" + (appContainer ? "appcontainer" : "job") + "\",\"host\":\"WindowsSandboxHost\"}");
            return 0;
        }

        if (args.Count > 0 && args[0] == "--prepare-appcontainer")
        {
            bool recursive = args.Count > 3 && string.Equals(args[3], "recursive", StringComparison.OrdinalIgnoreCase);
            return PrepareAppContainer(args.Count > 1 ? args[1] : null, args.Count > 2 ? args[2] : null, recursive);
        }

        if (args.Count > 0 && args[0] == "--appcontainer-sid")
        {
            IntPtr sid = EnsureAppContainer();
            if (sid == IntPtr.Zero) return 1;
            Console.WriteLine(SidToString(sid));
            FreeSid(sid);
            return 0;
        }

        if (args.Count == 0)
        {
            Console.Error.WriteLine("WindowsSandboxHost: missing executable");
            return 2;
        }

        string commandLine = BuildCommandLine(args);
        try
        {
            return Launch(commandLine, appContainer);
        }
        catch (Exception error)
        {
            Console.Error.WriteLine("WindowsSandboxHost: " + error);
            return 9;
        }
    }

    private static int Launch(string commandLine, bool appContainer)
    {
        jobHandle = CreateJobObject(IntPtr.Zero, null);
        if (jobHandle == IntPtr.Zero)
        {
            Console.Error.WriteLine("WindowsSandboxHost: CreateJobObject failed: " + LastError());
            return 3;
        }

        if (!ApplyJobLimits())
        {
            Cleanup();
            return 4;
        }

        IntPtr stdIn = GetStdHandle(StdInputHandle);
        IntPtr stdOut = GetStdHandle(StdOutputHandle);
        IntPtr stdErr = GetStdHandle(StdErrorHandle);
        if (stdIn != IntPtr.Zero) SetHandleInformation(stdIn, HandleFlagInherit, HandleFlagInherit);
        if (stdOut != IntPtr.Zero) SetHandleInformation(stdOut, HandleFlagInherit, HandleFlagInherit);
        if (stdErr != IntPtr.Zero) SetHandleInformation(stdErr, HandleFlagInherit, HandleFlagInherit);

        IntPtr appContainerSid = IntPtr.Zero;
        IntPtr attributeList = IntPtr.Zero;
        IntPtr capabilitiesBlock = IntPtr.Zero;
        bool created = false;
        ProcessInformation info = new ProcessInformation();
        uint baseFlags = CreateSuspended | CreateUnicodeEnvironment | CreateNoWindow;

        try
        {
            if (appContainer)
            {
                appContainerSid = EnsureAppContainer();
                if (appContainerSid == IntPtr.Zero)
                {
                    Console.Error.WriteLine("WindowsSandboxHost: AppContainer unavailable, falling back to Job Object isolation");
                    appContainer = false;
                }
            }

            if (appContainer)
            {
                var startupEx = new StartupInfoEx();
                startupEx.StartupInfo.cb = Marshal.SizeOf(typeof(StartupInfoEx));
                startupEx.StartupInfo.dwFlags = (int)StartfUseStdHandles;
                startupEx.StartupInfo.hStdInput = stdIn;
                startupEx.StartupInfo.hStdOutput = stdOut;
                startupEx.StartupInfo.hStdError = stdErr;

                IntPtr size = IntPtr.Zero;
                InitializeProcThreadAttributeList(IntPtr.Zero, 1, 0, ref size);
                attributeList = Marshal.AllocHGlobal(size);
                if (!InitializeProcThreadAttributeList(attributeList, 1, 0, ref size))
                {
                    Console.Error.WriteLine("WindowsSandboxHost: InitializeProcThreadAttributeList failed: " + LastError());
                    Cleanup();
                    return 7;
                }

                var capabilities = new SecurityCapabilities();
                capabilities.AppContainerSid = appContainerSid;
                capabilities.Capabilities = IntPtr.Zero;
                capabilities.CapabilityCount = 0;
                capabilities.Reserved = 0;

                capabilitiesBlock = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(SecurityCapabilities)));
                Marshal.StructureToPtr(capabilities, capabilitiesBlock, false);
                bool updated = UpdateProcThreadAttribute(
                    attributeList, 0, ProcThreadAttributeSecurityCapabilities, capabilitiesBlock,
                    new IntPtr(Marshal.SizeOf(typeof(SecurityCapabilities))), IntPtr.Zero, IntPtr.Zero);
                if (!updated)
                {
                    Console.Error.WriteLine("WindowsSandboxHost: UpdateProcThreadAttribute failed: " + LastError());
                    Cleanup();
                    return 8;
                }

                startupEx.lpAttributeList = attributeList;
                created = CreateProcess(null, new StringBuilder(commandLine), IntPtr.Zero, IntPtr.Zero, true,
                    baseFlags | ExtendedStartupInfoPresent, IntPtr.Zero, null, ref startupEx, out info);
            }
            else
            {
                var startup = new StartupInfo();
                startup.cb = Marshal.SizeOf(typeof(StartupInfo));
                startup.dwFlags = (int)StartfUseStdHandles;
                startup.hStdInput = stdIn;
                startup.hStdOutput = stdOut;
                startup.hStdError = stdErr;
                created = CreateProcess(null, new StringBuilder(commandLine), IntPtr.Zero, IntPtr.Zero, true,
                    baseFlags, IntPtr.Zero, null, ref startup, out info);
            }
        }
        finally
        {
            if (capabilitiesBlock != IntPtr.Zero) Marshal.FreeHGlobal(capabilitiesBlock);
            if (attributeList != IntPtr.Zero)
            {
                DeleteProcThreadAttributeList(attributeList);
                Marshal.FreeHGlobal(attributeList);
            }
            if (appContainerSid != IntPtr.Zero) FreeSid(appContainerSid);
        }

        if (!created && appContainer)
        {
            // AppContainer needs the executable directory to be readable by the
            // package SID. When that is not the case we fall back to Job Object
            // isolation rather than failing the task outright.
            Console.Error.WriteLine("WindowsSandboxHost: AppContainer launch failed, falling back to Job Object isolation");
            var fallbackStartup = new StartupInfo();
            fallbackStartup.cb = Marshal.SizeOf(typeof(StartupInfo));
            fallbackStartup.dwFlags = (int)StartfUseStdHandles;
            fallbackStartup.hStdInput = stdIn;
            fallbackStartup.hStdOutput = stdOut;
            fallbackStartup.hStdError = stdErr;
            created = CreateProcess(null, new StringBuilder(commandLine), IntPtr.Zero, IntPtr.Zero, true,
                baseFlags, IntPtr.Zero, null, ref fallbackStartup, out info);
        }

        if (!created)
        {
            Console.Error.WriteLine("WindowsSandboxHost: CreateProcess failed: " + LastError());
            Cleanup();
            return 5;
        }

        processHandle = info.hProcess;
        threadHandle = info.hThread;

        if (!AssignProcessToJobObject(jobHandle, processHandle))
        {
            Console.Error.WriteLine("WindowsSandboxHost: AssignProcessToJobObject failed: " + LastError());
            TerminateProcess(processHandle, 6);
            Cleanup();
            return 6;
        }

        ResumeThread(threadHandle);

        uint exitCode = 0;
        while (true)
        {
            uint current;
            if (!GetExitCodeProcess(processHandle, out current)) break;
            if (current != StillActive) { exitCode = current; break; }
            Thread.Sleep(40);
        }

        Console.Out.Flush();
        Console.Error.Flush();
        Cleanup();
        return unchecked((int)exitCode);
    }

    private static bool ApplyJobLimits()
    {
        var limits = new JobObjectExtendedLimitInformation();
        limits.BasicLimitInformation.LimitFlags = JobObjectLimitKillOnJobClose;

        int memoryMb = ReadInt("SANDBOX_MEMORY_MB", 0);
        if (memoryMb > 0)
        {
            limits.BasicLimitInformation.LimitFlags |= JobObjectLimitProcessMemory;
            limits.ProcessMemoryLimit = new UIntPtr((ulong)memoryMb * 1024UL * 1024UL);
        }
        if (ReadFlag("SANDBOX_ALLOW_BREAKAWAY", false))
        {
            limits.BasicLimitInformation.LimitFlags |= JobObjectLimitBreakawayOk;
        }
        if (!ReadFlag("SANDBOX_ALLOW_CHILDREN", true))
        {
            limits.BasicLimitInformation.LimitFlags |= JobObjectLimitActiveProcess;
            limits.BasicLimitInformation.ActiveProcessLimit = 1;
        }

        IntPtr block = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(JobObjectExtendedLimitInformation)));
        try
        {
            Marshal.StructureToPtr(limits, block, false);
            bool applied = SetInformationJobObject(jobHandle, JobObjectExtendedLimitInfoClass, block,
                (uint)Marshal.SizeOf(typeof(JobObjectExtendedLimitInformation)));
            if (!applied) Console.Error.WriteLine("WindowsSandboxHost: SetInformationJobObject failed: " + LastError());
            return applied;
        }
        finally
        {
            Marshal.FreeHGlobal(block);
        }
    }

    private static IntPtr EnsureAppContainer()
    {
        string name = ReadString("SANDBOX_APPCONTAINER", "local-super-agent-worker");

        IntPtr sid = IntPtr.Zero;
        int hr = DeriveAppContainerSidFromAppContainerName(name, out sid);
        if (hr >= 0 && sid != IntPtr.Zero) return sid;

        hr = CreateAppContainerProfile(name, name, "Local Super Agent Worker", IntPtr.Zero, 0, out sid);
        if (hr >= 0 && sid != IntPtr.Zero) return sid;

        Console.Error.WriteLine("WindowsSandboxHost: AppContainer profile unavailable (hr=0x" + hr.ToString("X8") + ")");
        return IntPtr.Zero;
    }

    private static int PrepareAppContainer(string readOnlyPath, string readWritePath, bool recursive)
    {
        IntPtr sid = EnsureAppContainer();
        if (sid == IntPtr.Zero) return 1;
        string sidString = SidToString(sid);
        FreeSid(sid);
        if (sidString == null) return 1;

        bool ok = true;
        // Shallow by default: a recursive ACL sweep across a large workspace
        // can take minutes and delay Router startup. Callers that truly need
        // recursion pass "recursive" explicitly.
        string inherit = recursive ? "(OI)(CI)" : "";
        if (!string.IsNullOrEmpty(readOnlyPath)) ok &= GrantAcl(readOnlyPath, sidString, inherit + "RX", recursive);
        if (!string.IsNullOrEmpty(readWritePath)) ok &= GrantAcl(readWritePath, sidString, inherit + "M", recursive);
        Console.WriteLine("{\"sid\":\"" + sidString + "\",\"ok\":" + (ok ? "true" : "false") + ",\"recursive\":" + (recursive ? "true" : "false") + "}");
        return ok ? 0 : 1;
    }

    private static bool GrantAcl(string targetPath, string sid, string rights, bool recursive)
    {
        try
        {
            var startInfo = new System.Diagnostics.ProcessStartInfo();
            startInfo.FileName = "icacls";
            startInfo.Arguments = Quote(targetPath) + " /grant *" + sid + ":" + rights + (recursive ? " /T" : "") + " /C /Q";
            startInfo.UseShellExecute = false;
            startInfo.CreateNoWindow = true;
            startInfo.RedirectStandardOutput = true;
            startInfo.RedirectStandardError = true;
            using (var process = System.Diagnostics.Process.Start(startInfo))
            {
                // Hard bound so a slow ACL walk can never hang the caller.
                if (!process.WaitForExit(45000))
                {
                    try { process.Kill(); } catch { }
                    Console.Error.WriteLine("WindowsSandboxHost: icacls 超时: " + targetPath);
                    return false;
                }
                return process.ExitCode == 0;
            }
        }
        catch (Exception error)
        {
            Console.Error.WriteLine("WindowsSandboxHost: icacls failed: " + error.Message);
            return false;
        }
    }

    private static string SidToString(IntPtr sid)
    {
        IntPtr text = IntPtr.Zero;
        if (!ConvertSidToStringSid(sid, out text)) return null;
        try { return Marshal.PtrToStringUni(text); }
        finally { LocalFree(text); }
    }

    private static void Cleanup()
    {
        if (jobHandle != IntPtr.Zero)
        {
            TerminateJobObject(jobHandle, 0);
            CloseHandle(jobHandle);
            jobHandle = IntPtr.Zero;
        }
        if (threadHandle != IntPtr.Zero) { CloseHandle(threadHandle); threadHandle = IntPtr.Zero; }
        if (processHandle != IntPtr.Zero) { CloseHandle(processHandle); processHandle = IntPtr.Zero; }
    }

    private static string LastError()
    {
        return new Win32Exception(Marshal.GetLastWin32Error()).Message;
    }

    private static string BuildCommandLine(IList<string> args)
    {
        var builder = new StringBuilder();
        for (int index = 0; index < args.Count; index++)
        {
            if (index > 0) builder.Append(' ');
            builder.Append(Quote(args[index]));
        }
        return builder.ToString();
    }

    private static string Quote(string value)
    {
        if (value.Length > 0 && value.IndexOfAny(new char[] { ' ', '\t', '"' }) < 0) return value;

        var builder = new StringBuilder();
        builder.Append('"');
        int backslashes = 0;
        foreach (char character in value)
        {
            if (character == '\\')
            {
                backslashes++;
                continue;
            }
            if (character == '"')
            {
                builder.Append('\\', backslashes * 2 + 1);
                builder.Append('"');
                backslashes = 0;
                continue;
            }
            builder.Append('\\', backslashes);
            backslashes = 0;
            builder.Append(character);
        }
        builder.Append('\\', backslashes * 2);
        builder.Append('"');
        return builder.ToString();
    }

    private static string ReadString(string name, string fallback)
    {
        string value = Environment.GetEnvironmentVariable(name);
        if (value == null || value.Trim().Length == 0) return fallback;
        return value.Trim();
    }

    private static bool ReadFlag(string name, bool fallback)
    {
        string value = ReadString(name, null);
        if (value == null) return fallback;
        value = value.ToLowerInvariant();
        return value == "1" || value == "true" || value == "yes" || value == "on";
    }

    private static int ReadInt(string name, int fallback)
    {
        int parsed;
        string value = Environment.GetEnvironmentVariable(name);
        if (value != null && int.TryParse(value, out parsed)) return parsed;
        return fallback;
    }
}








