# 长期记忆系统技术设计

版本：0.4.0

## 1. 目标与边界

长期记忆只保存“从真实任务和交互中习得、能够跨会话复用”的知识。它不是聊天记录的无限续写，也不是把全部历史切片直接灌入上下文。

系统遵循三条原则：

1. 原始流水必须保留，任何摘要、记忆笔记和 Wiki 都是可重建的二次加工层。
2. 顶层只注入轻量索引，细节按需检索；索引硬限制为 200 行 / 25 KB。
3. 在线写入负责及时捕获显著信息，离线 Dreaming 负责纠错、去重、合并、衰减和知识重组。

## 2. 四层架构

```text
用户消息 / Worker 工具调用
          │ 自动归档
          ▼
memory_transcripts（不可变原始流水）
          │ Dreaming 对照事实
          ▼
memories（事实 / 决定 / 偏好 / 任务结果 / 失败 / 技能）
          │ 按主题聚合
          ▼
memory_pages + wiki/*.md（结构化 Wiki）
          │ 目录化
          ▼
MEMORY.md（最多 200 行 / 25 KB，仅注入轻量索引）
```

### 2.1 Transcripts

- `addMessage()` 自动写入用户和助手消息。
- Worker 每次工具调用及结果通过 `captureTranscript()` 写入。
- 仅提供追加和检索，不提供修改/删除 API。
- 删除一条记忆不会删除其原始流水。

### 2.2 Memory Notes

每条笔记包含：

- `scope`：`session | project | global`
- `workspace`：绑定任务文件夹
- `kind`：事实、决定、偏好、任务结果、失败、笔记、技能
- `importance`、`confidence`、`status`
- `access_count`、`last_accessed_at`
- `source_type`、`source`、`fingerprint`
- `supersedes`、`valid_until`、`dreamed_at`

`session` 只对当前会话可见；`project` 和 `global` 可跨会话复用，但不会跨 workspace 泄漏。指纹去重按“作用域 + 工作区 + 会话”共同判断。

### 2.3 Wiki

- 页面正文存储在 `<dataDir>/memory/workspaces/<workspace-key>/wiki/*.md`。
- SQLite 的 `memory_pages` 保存标题、摘要、修订号、来源记忆、链接元数据和文件路径。
- UI 可展开全文；Router/Worker 可通过 `memory_read_page` 按 slug 或 ID 深读。

### 2.4 注入索引

- 文件：`<dataDir>/memory/workspaces/<workspace-key>/MEMORY.md`
- 硬限制：`indexMaxLines=200`、`indexMaxBytes=25600`
- 写入使用串行锁，按 UTF-8 字节截断，避免并发写入突破上限。
- 超限内容不进入提示词，只保留在 Wiki 和原始流水中。

## 3. 检索与排序

语义检索由以下信号加权：

| 信号 | 权重 |
|---|---:|
| 向量相似度 | 50% |
| 关键词匹配 | 15% |
| 置信度 | 14% |
| 重要度 | 9% |
| 时效 | 7% |
| 访问频次 | 5% |
| 置顶加分 | 4% |

默认使用内置 384 维本地哈希嵌入，离线可用；配置远端 embedding 模型时优先调用 OpenAI 兼容的 `/v1/embeddings`，失败自动回退本地。

`maxInlineMemories` 只限制提示词注入数量；显式传入 `topK` 的 UI/API 搜索可以返回最多 50 条结果。

## 4. Dreaming 闭环

### 触发

- Runtime 启动后等待 `startupDelayMs`，之后按 `intervalHours` 周期运行。
- 当前工作区活跃项目记忆少于 `minMemories` 时跳过计划任务。
- 用户可在记忆中心手动触发，不受数量门槛限制。

### 流程

1. 读取当前 workspace 的记忆笔记和原始流水。
2. 模型返回 `keep / update / archive / merge / pages` 操作。
3. 应用模型操作后，始终执行确定性去重和时效衰减。
4. 刷新记忆状态，再生成或修订 Wiki 页面。
5. 重建 `MEMORY.md`，写入运行统计。
6. 推送 `memory.dream.started/completed/failed` SSE 事件。

置顶记忆不衰减。休眠阈值由 `dormantDays` 控制；无活跃记忆时不会清空已有 Wiki。

### 失败处理

- 模型失败时记录警告，并执行确定性去重、衰减和 Wiki 生成。
- Dreaming 失败不阻塞 Router、Worker 或在线记忆写入。
- 所有运行写入 `memory_runs`，UI 可查看状态、错误和统计。

## 5. 数据表

| 表 | 用途 |
|---|---|
| `memory_transcripts` | 原始消息与工具流水 |
| `memories` | 长期记忆笔记 |
| `memory_pages` | Wiki 元数据与正文快照 |
| `memory_runs` | Dreaming 运行状态与统计 |
| `memory_access_log` | 召回审计与访问频次 |
| `memory_chunks` | 长记忆分块 |
| `memory_vectors` | 记忆向量 |

旧版数据库启动时自动补齐列、表和索引。

## 6. Worker 安全边界

Worker 只能只读访问长期记忆：

- `memory_search`：按查询返回相关记忆摘要
- `memory_read_page`：读取 Wiki 页面

Worker 无权新增、编辑、归档或删除长期记忆。记忆写入由 Router、任务终态记录和用户操作完成。

## 7. API

| 方法 | 路径 | 用途 |
|---|---|---|
| GET | `/api/memory/overview` | 统计、索引预算、Dreaming 状态 |
| GET/POST | `/api/memory/records` | 查询 / 新建记忆 |
| PATCH/DELETE | `/api/memory/records/:id` | 编辑 / 置顶 / 归档 / 删除 |
| POST | `/api/memory/records/:id/feedback` | 记忆质量反馈 |
| GET | `/api/memory/transcripts` | 原始流水检索 |
| GET | `/api/memory/pages` | Wiki 列表 |
| GET | `/api/memory/pages/:id` | Wiki 详情 |
| POST | `/api/memory/search` | 混合语义搜索 |
| POST | `/api/memory/sync` | 立即同步索引与 Wiki 文件 |
| POST | `/api/memory/backfill` | 补齐历史向量 |
| POST | `/api/memory/dream` | 异步 Dreaming |
| GET | `/api/memory/runs` | 运行历史 |
| GET | `/api/memory/stats` | 向量索引统计 |

## 8. UI 产品面

记忆中心包含：

- 六项统计：活跃、休眠、归档、Wiki、原始流水、索引行数
- 语义搜索与清除
- 手动 Dreaming、重建向量索引、刷新
- 子页签：记忆笔记 / Wiki / 原始流水 / 整理记录
- 手动写入、编辑、置顶、反馈、归档/恢复、删除
- Wiki 全文阅读与 Dreaming 状态轮询

宽度低于 980px 时，右侧检查器变为可滑出的抽屉；800px 与 1440px 均无横向溢出。

## 9. 配置

```json
{
  "memory": {
    "embeddingDim": 384,
    "topK": 8,
    "minScore": 0.18,
    "maxInlineMemories": 12,
    "indexMaxLines": 200,
    "indexMaxBytes": 25600,
    "dreaming": {
      "enabled": true,
      "intervalHours": 6,
      "startupDelayMs": 60000,
      "batchSize": 24,
      "minMemories": 8,
      "staleDays": 30,
      "dormantDays": 90,
      "decayPerMonth": 0.08
    }
  }
}
```

## 10. 验收覆盖

`tests/long-term-memory.test.mjs` 覆盖：

- 旧 memories 表迁移
- 消息自动流水与工作区隔离
- project/global 跨会话但不跨 workspace
- 作用域指纹去重
- 200 行 / 25 KB 索引上限
- 显式检索上限
- 反馈置信度
- Dreaming 去重、衰减和 Wiki 生成
- Worker 只读 IPC 工具

`tests/memory-api.test.mjs` 覆盖 CRUD、overview、Wiki、原始流水和 Dreaming API 闭环。当前完整测试集为 56 项，全部通过。
