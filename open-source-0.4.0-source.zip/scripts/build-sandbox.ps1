﻿param(
  [switch]$Force
)
$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$Source = Join-Path $ProjectRoot "sandbox\windows\WindowsSandboxHost.cs"
$OutputDir = Join-Path $ProjectRoot "native"
$Output = Join-Path $OutputDir "WindowsSandboxHost.exe"

if (-not (Test-Path -LiteralPath $Source)) { throw "找不到沙箱宿主源码: $Source" }

New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null

if ((Test-Path -LiteralPath $Output) -and -not $Force) {
  $sourceTime = (Get-Item -LiteralPath $Source).LastWriteTimeUtc
  $outputTime = (Get-Item -LiteralPath $Output).LastWriteTimeUtc
  if ($outputTime -ge $sourceTime) {
    Write-Host "沙箱宿主已是最新: $Output"
    exit 0
  }
}

$compilerCandidates = @(
  "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe",
  "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\csc.exe"
)
$compiler = $compilerCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $compiler) {
  throw "找不到 .NET Framework 编译器 csc.exe。请安装 .NET Framework 4.x 或 Visual Studio Build Tools。"
}

Push-Location $ProjectRoot
try {
  & $compiler /nologo /target:exe /platform:x64 /optimize+ /out:$Output $Source
  if ($LASTEXITCODE -ne 0) { throw "沙箱宿主编译失败 (exit $LASTEXITCODE)" }
}
finally {
  Pop-Location
}

$probe = & $Output --probe 2>&1
Write-Host "沙箱宿主已构建: $Output"
Write-Host "自检: $probe"