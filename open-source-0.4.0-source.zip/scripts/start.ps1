﻿param(
  [string]$ApiKey = "",
  [int]$Port = 4317,
  [string]$Workspace = ""
)
$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
if ($ApiKey) { $env:DEEPSEEK_API_KEY = $ApiKey }
if ($Port) { $env:AGENT_PORT = [string]$Port }
if ($Workspace) { $env:AGENT_WORKSPACE = $Workspace }
Set-Location -LiteralPath $ProjectRoot
node bin/super-agent.mjs
