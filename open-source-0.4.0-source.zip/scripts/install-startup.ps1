﻿param(
  [switch]$Force
)
$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$Startup = [Environment]::GetFolderPath("Startup")
$ShortcutPath = Join-Path $Startup "Local Super Agent.lnk"
if ((Test-Path -LiteralPath $ShortcutPath) -and -not $Force) {
  throw "启动项已存在。使用 -Force 覆盖：$ShortcutPath"
}
$PowerShell = (Get-Command powershell.exe).Source
$Script = Join-Path $ProjectRoot "scripts\start.ps1"
$Shell = New-Object -ComObject WScript.Shell
$Shortcut = $Shell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = $PowerShell
$Shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$Script`""
$Shortcut.WorkingDirectory = $ProjectRoot
$Shortcut.WindowStyle = 7
$Shortcut.Description = "Local Super Agent Router"
$Shortcut.Save()
Write-Host "已创建开机启动项: $ShortcutPath"
