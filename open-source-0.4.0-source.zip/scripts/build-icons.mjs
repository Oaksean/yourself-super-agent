// Generates the Tauri icon set without external tooling.
//
// Writes PNG files using a hand-rolled encoder (zlib + PNG chunks) and an ICO
// container that embeds PNG frames, which is valid for Tauri/Windows.
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

const OUT = path.resolve(import.meta.dirname ?? '.', '..', 'src-tauri', 'icons');

function crc32(buffer) {
  let crc = 0xffffffff;
  for (let i = 0; i < buffer.length; i++) {
    crc ^= buffer[i];
    for (let bit = 0; bit < 8; bit++) crc = crc & 1 ? (crc >>> 1) ^ 0xedb88320 : crc >>> 1;
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length);
  const typeBuf = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])));
  return Buffer.concat([length, typeBuf, data, crc]);
}

function png(width, height, pixelAt) {
  const raw = Buffer.alloc((width * 4 + 1) * height);
  let offset = 0;
  for (let y = 0; y < height; y++) {
    raw[offset++] = 0; // filter: none
    for (let x = 0; x < width; x++) {
      const [r, g, b, a] = pixelAt(x, y, width, height);
      raw[offset++] = r; raw[offset++] = g; raw[offset++] = b; raw[offset++] = a;
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;   // bit depth
  ihdr[9] = 6;   // color type RGBA
  ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

// Rounded-square mark: dark slate tile with a mint "S/A" style diagonal.
function pixelAt(x, y, width, height) {
  const cx = width / 2;
  const cy = height / 2;
  const dx = Math.abs(x + 0.5 - cx);
  const dy = Math.abs(y + 0.5 - cy);
  const radius = width * 0.22;
  const half = width / 2;
  const inside = dx <= half && dy <= half && (dx <= half - radius || dy <= half - radius ||
    ((dx - (half - radius)) ** 2 + (dy - (half - radius)) ** 2) <= radius * radius);
  if (!inside) return [0, 0, 0, 0];

  // diagonal band accent
  const t = (x + y) / (width + height);
  const accent = t > 0.38 && t < 0.62;
  if (accent) return [87, 230, 168, 255];

  // subtle vertical gradient
  const shade = Math.round(24 + (y / height) * 26);
  return [shade, shade + 6, shade + 16, 255];
}

const frames = [16, 24, 32, 48, 64, 128, 256];
const pngs = new Map();
for (const size of frames) {
  const buf = png(size, size, pixelAt);
  pngs.set(size, buf);
  if ([32, 128, 256].includes(size)) {
    fs.writeFileSync(path.join(OUT, `${size}x${size}.png`), buf);
  }
}
fs.writeFileSync(path.join(OUT, '128x128.png'), pngs.get(128));
fs.writeFileSync(path.join(OUT, '128x128@2x.png'), pngs.get(256));

// ICO with PNG-encoded entries (Windows Vista+ supports this).
const icoSizes = [16, 32, 48, 64, 128, 256];
const header = Buffer.alloc(6);
header.writeUInt16LE(0, 0);
header.writeUInt16LE(1, 2);
header.writeUInt16LE(icoSizes.length, 4);
const entries = [];
let dataOffset = 6 + icoSizes.length * 16;
for (const size of icoSizes) {
  const data = pngs.get(size);
  const entry = Buffer.alloc(16);
  entry[0] = size >= 256 ? 0 : size;
  entry[1] = size >= 256 ? 0 : size;
  entry[2] = 0; entry[3] = 0;
  entry.writeUInt16LE(1, 4);
  entry.writeUInt16LE(32, 6);
  entry.writeUInt32LE(data.length, 8);
  entry.writeUInt32LE(dataOffset, 12);
  entries.push(entry);
  dataOffset += data.length;
}
const ico = Buffer.concat([header, ...entries, ...icoSizes.map((size) => pngs.get(size))]);
fs.writeFileSync(path.join(OUT, 'icon.ico'), ico);
fs.writeFileSync(path.join(OUT, 'icon.png'), pngs.get(256));

console.log('icons written to', OUT);
for (const file of fs.readdirSync(OUT)) {
  const size = fs.statSync(path.join(OUT, file)).size;
  console.log(`  ${file} (${size} bytes)`);
}

