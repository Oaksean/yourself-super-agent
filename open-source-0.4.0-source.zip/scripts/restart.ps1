﻿param()
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath 'data\server.pid'){
  $oldPid=[int](Get-Content -LiteralPath 'data\server.pid' -Raw).Trim()
  Stop-Process -Id $oldPid -Force -ErrorAction SilentlyContinue
  Start-Sleep -Milliseconds 900
}
$portPids = @(Get-NetTCPConnection -LocalPort 4317 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
foreach($portPid in $portPids){
  if($portPid){
    Stop-Process -Id $portPid -Force -ErrorAction SilentlyContinue
  }
}
if($portPids.Count){ Start-Sleep -Milliseconds 900 }
$node=(Get-Command node).Source
$out=Join-Path (Get-Location) 'logs\server.out.log'
$err=Join-Path (Get-Location) 'logs\server.err.log'
$p=Start-Process -FilePath $node -ArgumentList @('bin/super-agent.mjs') -WorkingDirectory (Get-Location) -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $err -PassThru
Set-Content -LiteralPath 'data\server.pid' -Value $p.Id -Encoding ascii
$health=$null
for($i=0;$i -lt 60;$i++){ Start-Sleep -Milliseconds 250; try { $health=Invoke-RestMethod -Uri 'http://127.0.0.1:4317/api/health' -TimeoutSec 2; break } catch {} }
if(-not $health){ Get-Content -LiteralPath $err -Tail 40; throw 'server failed' }
"STARTED_PID=$($p.Id) SANDBOX=$($health.sandbox.tier)"
