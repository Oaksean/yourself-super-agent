import { AgentStore } from '../src/core/db.mjs';
import { MemoryService } from '../src/core/memory.mjs';
import { EmbeddingService } from '../src/core/embed/embedding-service.mjs';
import { cosineSimilarity } from '../src/core/embed/local-embedder.mjs';

const db = new AgentStore('data/agent.db');
const s = db.listSessions(1)[0];
const vectors = db.listMemoryVectors(s.id);
const q = new EmbeddingService({ provider: {}, config: { memory: {} } });
const queryText = '分析当前工作区结构并读取 README';
const queryVec = await q.embed(queryText);
for (const v of vectors) {
  const mem = db.getMemory(v.memory_id);
  console.log(cosineSimilarity(queryVec, v.vector).toFixed(4), '::', (mem?.content || '').slice(0, 45));
}
db.close();
