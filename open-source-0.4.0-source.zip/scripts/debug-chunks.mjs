import { chunkText } from '../src/core/memory.mjs';
const noisy = [
  '以下是一次工作区扫描的冗长输出，包含大量无关文件路径。',
  'bin/super-agent.mjs',
  'src/core/router.mjs',
  '工程采用微 VM gVisor 来隔离任意执行型 Worker。',
  'logs/server.out.log',
  'data/agent.db',
].join('\n');
console.log('raw len', noisy.length);
const chunks = chunkText(noisy);
console.log('chunks', chunks.length);
for (const c of chunks) console.log(' -', JSON.stringify(c));
