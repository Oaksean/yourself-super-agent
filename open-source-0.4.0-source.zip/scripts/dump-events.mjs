import { AgentStore } from '../src/core/db.mjs';
const db = new AgentStore('data/agent.db');
const rows = db.db.prepare("select type, payload_json from events where type in ('task.started','task.completed') order by created_at desc limit 4").all();
for (const row of rows) console.log(row.type, '::', row.payload_json.slice(0, 400));
console.log('--- watcher rows ---');
console.log(db.listWatchers({ activeOnly: false }).length);
db.close();
