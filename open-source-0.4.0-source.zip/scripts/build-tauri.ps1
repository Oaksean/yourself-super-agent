﻿param(
  [switch]$Dev,
  [switch]$Build,
  [switch]$SkipSandbox,
  [switch]$SkipInstall
)
$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $ProjectRoot

function Test-Command($name) {
  return [bool](Get-Command $name -ErrorAction SilentlyContinue)
}

function Add-PathPrefix($dir) {
  if ($dir -and (Test-Path -LiteralPath $dir)) {
    $env:Path = "$dir;$env:Path"
    return $true
  }
  return $false
}
# Bundle a known-good Node runtime with the desktop app. GUI launches do not
# inherit the developer shell PATH, so "node.exe" may be unavailable even when
# it works in a terminal. The packaged runtime makes startup self-contained.
function Prepare-NodeRuntime {
  $nodeCommand = Get-Command node -CommandType Application -ErrorAction SilentlyContinue |
    Select-Object -First 1
  if (-not $nodeCommand) {
    throw "node.exe was not found. Install Node.js 24+ or run this build from a shell where node is available."
  }

  $runtimeDir = Join-Path $ProjectRoot "runtime"
  $destination = Join-Path $runtimeDir "node.exe"
  New-Item -ItemType Directory -Force -Path $runtimeDir | Out-Null

  $sourceHash = (Get-FileHash -LiteralPath $nodeCommand.Source -Algorithm SHA256).Hash
  $needsCopy = -not (Test-Path -LiteralPath $destination)
  if (-not $needsCopy) {
    $destinationHash = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
    $needsCopy = $sourceHash -ne $destinationHash
  }
  if ($needsCopy) {
    Copy-Item -LiteralPath $nodeCommand.Source -Destination $destination -Force
  }

  $sourceDir = Split-Path -Parent $nodeCommand.Source
  foreach ($licenseName in @('LICENSE', 'LICENSE.txt')) {
    $license = Join-Path $sourceDir $licenseName
    if (Test-Path -LiteralPath $license) {
      Copy-Item -LiteralPath $license -Destination (Join-Path $runtimeDir "NODE-LICENSE.txt") -Force
      break
    }
  }

  Write-Host "Bundled Node runtime: $destination"
  Write-Host "Node version: $(& $destination --version)"
}

# The gnullvm target is UCRT-based, so the UCRT flavour of LLVM-MinGW must be
# preferred; linking with the MSVCRT flavour would pull in msvcrt.dll and
# mismatch the target's runtime.
function Find-LlvmMingwBin {
  $pkgRoot = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Packages"
  if (-not (Test-Path -LiteralPath $pkgRoot)) { return $null }
  $candidates = Get-ChildItem -LiteralPath $pkgRoot -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like 'MartinStorsjo.LLVM-MinGW*' } |
    ForEach-Object { Get-ChildItem -LiteralPath $_.FullName -Directory -Filter 'llvm-mingw*' -ErrorAction SilentlyContinue } |
    ForEach-Object { Join-Path $_.FullName 'bin' } |
    Where-Object { Test-Path -LiteralPath (Join-Path $_ 'x86_64-w64-mingw32-gcc.exe') }
  return @($candidates | Where-Object { $_ -match 'ucrt' } | Select-Object -First 1) +
         @($candidates | Where-Object { $_ -notmatch 'ucrt' } | Select-Object -First 1) |
    Select-Object -First 1
}

Write-Host "== Local Super Agent / Tauri build =="
Write-Host "This project pins the gnullvm (LLVM + UCRT) toolchain, so no Visual"
Write-Host "Studio / Windows SDK is required. See src-tauri/rust-toolchain.toml."

Write-Host "[1/6] Preparing bundled Node runtime"
Prepare-NodeRuntime

# 2. Windows sandbox host
if (-not $SkipSandbox) {
  Write-Host "[2/6] Building Windows sandbox host"
  & (Join-Path $PSScriptRoot "build-sandbox.ps1")
}

# 2. Rust
Write-Host "[3/6] Checking Rust toolchain"
Add-PathPrefix (Join-Path $env:USERPROFILE ".cargo\bin") | Out-Null
$rustup = Join-Path $env:USERPROFILE ".cargo\bin\rustup.exe"

if (-not (Test-Command "cargo")) {
  if ($SkipInstall) { throw "cargo not found. Install Rust from https://rustup.rs and reopen the terminal." }
  if (Test-Command "winget") {
    Write-Host "Installing Rust via winget..."
    winget install --id Rustlang.Rustup -e --accept-source-agreements --accept-package-agreements
  }
  if (-not (Test-Command "cargo")) { throw "Could not install Rust automatically." }
}

# 3. Linker: the gnullvm target links via LLVM-MinGW's clang/gcc driver.
Write-Host "[4/6] Checking LLVM-MinGW linker"
$llvmMingwBin = Find-LlvmMingwBin
if (-not $llvmMingwBin -and -not $SkipInstall) {
  Write-Host "LLVM-MinGW not found; installing the UCRT build via winget..."
  if (Test-Command "winget") {
    winget install --id MartinStorsjo.LLVM-MinGW.UCRT -e --accept-source-agreements --accept-package-agreements
    $llvmMingwBin = Find-LlvmMingwBin
  }
}
if (-not $llvmMingwBin) {
  throw "LLVM-MinGW was not found. Install it with: winget install MartinStorsjo.LLVM-MinGW.UCRT"
}
Add-PathPrefix $llvmMingwBin | Out-Null
Write-Host "Using LLVM-MinGW: $llvmMingwBin"

# 4. Toolchain + Tauri CLI
Write-Host "[5/6] Checking gnullvm toolchain and Tauri CLI"
if (Test-Path -LiteralPath $rustup) {
  $hasToolchain = ((& $rustup toolchain list 2>$null) -match 'gnullvm')
  if (-not $hasToolchain) {
    if ($SkipInstall) { throw "stable-x86_64-pc-windows-gnullvm is missing. Run: rustup toolchain install stable-x86_64-pc-windows-gnullvm" }
    Write-Host "Installing stable-x86_64-pc-windows-gnullvm..."
    & $rustup toolchain install stable-x86_64-pc-windows-gnullvm
  }
}

$hasTauriCli = $false
if (Test-Command "cargo-tauri") { $hasTauriCli = $true }
else {
  & cargo tauri --version *> $null
  $hasTauriCli = ($LASTEXITCODE -eq 0)
}
if (-not $hasTauriCli) {
  if ($SkipInstall) { throw "tauri-cli not found. Run: cargo install tauri-cli --version ^2 --locked" }
  Write-Host "Installing tauri-cli (this takes a while)..."
  & cargo install tauri-cli --version "^2" --locked
  if ($LASTEXITCODE -ne 0) { throw "tauri-cli install failed" }
}

# 5. Run
Write-Host "[6/6] Running Tauri"
Push-Location (Join-Path $ProjectRoot "src-tauri")
try {
  if ($Dev) { & cargo tauri dev }
  elseif ($Build) { & cargo tauri build }
  else { & cargo tauri build --no-bundle }
  if ($LASTEXITCODE -ne 0) { throw "Tauri command failed (exit $LASTEXITCODE)" }
}
finally { Pop-Location }

if (-not $Dev) {
  $bundleDir = Join-Path $ProjectRoot "src-tauri\target\release\bundle"
  $exePath = Join-Path $ProjectRoot "src-tauri\target\release\local-super-agent.exe"
  Write-Host ""
  if (Test-Path -LiteralPath $exePath) { Write-Host "Executable: $exePath" }
  if (Test-Path -LiteralPath $bundleDir) {
    Write-Host "Installers:"
    Get-ChildItem -Recurse -File -LiteralPath $bundleDir -Include '*.exe','*.msi' |
      Select-Object FullName,@{n='MB';e={[math]::Round($_.Length/1MB,2)}} | Format-Table -AutoSize
  } elseif ($Build) {
    Write-Host "No installer was produced (NSIS / WiX is downloaded on first build)."
  }
}