import { resolveSafePath } from './security.mjs';
import { inferCapabilities } from './rules.mjs';
import { nowIso } from './ids.mjs';

const VALID_ISOLATIONS = new Set(['process-readonly', 'process-workspace-write', 'process-exec-gated']);

export class Router {
  constructor({ config, store, llm, memory, manager, collaboration = null, rules, events, logger }) {
    this.config = config;
    this.store = store;
    this.llm = llm;
    this.memory = memory;
    this.manager = manager;
    this.collaboration = collaboration;
    this.rules = rules;
    this.events = events;
    this.logger = logger;
    this.events.subscribe((event) => {
      // Collaboration members are deliberately silent until the Coordinator
      // has settled the whole run and produced one consolidated delivery.
      if (event.type === 'task.completed' && !event.task?.runId) {
        this.#onTaskCompleted(event.task).catch((error) => this.logger.warn('任务完成汇总失败', error.message));
      }
      if (event.type === 'task.failed' && !event.task?.runId) {
        this.#onTaskFailed(event.task).catch((error) => this.logger.warn('任务失败汇总失败', error.message));
      }
    });
  }

  async handleUserMessage({ sessionId, text, source = 'user' }) {
    const content = String(text || '').trim();
    if (!content) throw new Error('消息不能为空');
    let session = sessionId ? this.store.getSession(sessionId) : null;
    if (!session) session = this.store.createSession(titleFromMessage(content));
    else if (session.title === '新会话') session = this.store.touchSession(session.id, { title: titleFromMessage(content) });

    const userMessage = this.store.addMessage({ sessionId: session.id, role: 'user', content });
    const triggerResult = this.rules.evaluate({ text: content, source, sessionId: session.id });
    this.store.addEvent({ type: 'trigger.received', sessionId: session.id, payload: { source, text: content, rule: triggerResult } });
    this.events.emit({ type: 'message.user', sessionId: session.id, message: userMessage, trigger: triggerResult });

    if (!triggerResult.shouldRoute) {
      const assistant = this.store.addMessage({ sessionId: session.id, role: 'assistant', content: '这条触发未通过规则过滤，没有创建任务。' });
      return { sessionId: session.id, assistant, tasks: [], filtered: true };
    }

    let plan;
    if (this.llm.available) plan = await this.#planWithLLM(session.id, content, triggerResult);
    else plan = this.#planFallback(content, triggerResult);

    plan = this.#normalizePlan(plan);
    const workspace = resolveSafePath(this.config.workspace, this.config.allowedRoots, { mustExist: true });
    let tasks = [];
    let run = null;
    if (plan.tasks.length > 1 && this.collaboration) {
      try {
        const created = await this.collaboration.createRun({
          sessionId: session.id,
          title: plan.runTitle || titleFromMessage(content),
          goal: content,
          strategy: plan.strategy || 'coordinator',
          failurePolicy: plan.failurePolicy || 'continue',
          maxRounds: plan.maxRounds || 2,
          tasks: plan.tasks,
          workspace,
        });
        tasks = created.tasks;
        run = created.run;
      } catch (error) {
        this.logger.warn('多智能体协作计划无效，降级为单 Worker', error.message);
        const fallbackTask = { ...plan.tasks[0], title: plan.tasks[0]?.title || titleFromMessage(content), prompt: content };
        tasks = this.#createTasks(session.id, [fallbackTask]);
        plan = { ...plan, reply: `${plan.reply || ''}\n\n协作计划校验失败，已安全降级为一个 Worker：${error.message}`.trim(), tasks: [fallbackTask] };
        this.manager.enqueue(tasks[0].id);
      }
    } else {
      tasks = this.#createTasks(session.id, plan.tasks);
      for (const task of tasks) this.manager.enqueue(task.id);
    }

    const replyParts = [plan.reply || (tasks.length ? `已分派 ${tasks.length} 个任务。` : '')];
    if (run) {
      const topology = tasks.map((task, index) => `- ${index + 1}. ${task.title} · ${task.agentRole || 'general'}${task.dependsOn?.length ? ` · 依赖 ${task.dependsOn.map((id) => tasks.find((item) => item.id === id)?.title || id).join('、')}` : ' · 可并行'}`).join('\n');
      replyParts.push(`协作组：${run.title}（${run.id}）\n${topology}`);
      replyParts.push(`协作策略：中心化编排 · 最多 ${run.maxAgents} 个 Agent · 失败策略 ${run.failurePolicy === 'stop' ? '中止' : '继续'}\nCoordinator 会等待全部有效分支、完成交接与校验后统一汇报，不再逐任务刷屏。`);
      replyParts.push(`任务文件夹：${workspace}`);
    } else if (tasks.length && !tasks.some((task) => plan.reply?.includes(task.id))) {
      replyParts.push(tasks.map((task) => `- ${task.title}（${task.id}）`).join('\n'));
      replyParts.push('任务已进入自动监督：我会持续跟踪进度，中断后自动恢复；完成或需要你处理时会通知你。');
      replyParts.push(`任务文件夹：${tasks[0].workspace}`);
    }
    const assistant = this.store.addMessage({
      sessionId: session.id,
      role: 'assistant',
      content: replyParts.filter(Boolean).join('\n\n'),
      metadata: {
        decision: plan.decision,
        taskIds: tasks.map((task) => task.id),
        collaborationRunId: run?.id || null,
        fallback: plan.fallback || false,
      },
    });
    for (const memory of plan.memoryUpdates || []) {
      if (!memory?.content) continue;
      await this.memory.remember({
        sessionId: session.id,
        kind: memory.kind || 'fact',
        content: String(memory.content).slice(0, 12000),
        importance: memory.importance || 2,
        scope: memory.scope || 'project',
        workspace: this.config.workspace,
        topic: memory.topic || null,
        sourceType: 'router',
        source: { source: 'router-plan', messageId: userMessage.id },
      });
    }
    this.events.emit({ type: 'message.assistant', sessionId: session.id, message: assistant, tasks, collaborationRunId: run?.id || null });
    return { sessionId: session.id, assistant, tasks, plan, run, filtered: false };
  }

  async #planWithLLM(sessionId, text, triggerResult) {
    const context = this.memory.contextFor(sessionId);
    const system = `你是本地超级智能体的中心 Coordinator（Router），不直接操作文件、不执行命令、不调用本地工具。
你的职责是：理解目标、维护长期记忆、设计可审计的 Agent DAG、分派一次性 Worker、监督收敛，并在协作组整体结束后统一汇总。

架构原则：
1. 你负责中心化编排，不让 Agent 之间做无约束 P2P 通信；所有交接都经过你写入下游任务上下文。
2. 简单任务只创建一个 Worker；确实能拆分出独立工作的复杂任务才创建 2–5 个 Agent。不要为了展示能力滥用多智能体。
3. 无依赖的 Agent 会并行；有依赖的 Agent 只在全部上游完成后启动。dependsOn 使用 tasks 数组的 0 基下标，只能引用更早任务，禁止自依赖和循环。
4. 需要独立校验时，显式增加 reviewer Agent，并让它依赖被校验任务；出现相互冲突的结论时，再增加 arbiter Agent。
5. 下游 Agent 只接收必要的结构化交接，不复制全部历史。handoff 写明希望上游交付的摘要、证据、产物路径或未解决问题。
6. failurePolicy=continue 用于可选分支；failurePolicy=stop 用于任何关键步骤失败都应中止的流程。
7. 不把长篇执行细节塞进长期记忆，只记录事实、决定、偏好和未完成事项。
8. 如果目标不明确，先提出一个最关键的问题，decision=clarify，tasks=[]。
9. 输出严格 JSON，不要用 Markdown 代码块。

可用的 agentRole：
- researcher：检索、分析、读取证据
- implementer：实现、修改文件、执行受控命令
- reviewer：独立校验上游结果，不扩大范围
- arbiter：在上游冲突时作最终裁决
- archivist：整理并归档最终产物
不要额外创建 coordinator Worker；Coordinator 就是当前 Router。

能力约束：
- capabilities 只能是 read、write、execute。write 必须同时包含 read；execute 必须同时包含 read、write、execute。
- 所有 Worker 只能访问当前任务文件夹；高风险写入/命令仍走审批。

JSON 结构：
{
  "decision": "answer|delegate|clarify",
  "reply": "直接回复或告知用户将要启动什么协作",
  "sessionTitle": "可选，10字以内",
  "runTitle": "多任务时的协作组短标题",
  "strategy": "coordinator",
  "failurePolicy": "continue|stop",
  "maxRounds": 2,
  "tasks": [{
    "title": "短标题",
    "agentRole": "researcher|implementer|reviewer|arbiter|archivist|general",
    "prompt": "给该 Agent 的完整独立任务说明，包含目标、边界、验收标准",
    "type": "workspace_inspect|code_change|document_generation|command_task|research|general",
    "capabilities": ["read"],
    "isolation": "process-readonly|process-workspace-write|process-exec-gated",
    "dependsOn": [0],
    "handoff": {"需要下游使用的字段": "说明"},
    "verification": {"required": false, "criteria": "可核查的验收标准"},
    "expectedOutput": "具体交付物"
  }],
  "memoryUpdates": [{"kind":"fact|decision|preference|task_result","content":"...", "importance":1}]
}`;
    const recalled = await this.memory.summaryForPrompt(sessionId, text);
    const user = `用户消息:\n${text}\n\n程序规则预判:\n${JSON.stringify(triggerResult)}\n\n会话上下文摘要:\n${recalled}\n\n最近对话:\n${context.recentMessages.map((message) => `${message.role}: ${message.content}`).join('\n').slice(-12000)}`;
    try {
      const response = await this.llm.chatJson([
        { role: 'system', content: system },
        { role: 'user', content: user },
      ], { model: this.config.provider.routerModel, temperature: 0.1 });
      if (response.json?.sessionTitle) this.store.touchSession(sessionId, { title: String(response.json.sessionTitle).slice(0, 40) });
      return response.json;
    } catch (error) {
      this.logger.warn('Router LLM 失败，使用本地回退分派', error.message);
      return { ...this.#planFallback(text, triggerResult), warning: error.message, fallback: true };
    }
  }

  #planFallback(text, triggerResult) {
    const capabilities = inferCapabilities(text);
    const needsWorker = triggerResult.hints.needsLocalAccess || capabilities.length > 1 || /文件|目录|项目|代码|工作区|命令|测试|构建|readme|package\.json/i.test(text);
    if (!needsWorker) {
      return {
        decision: 'answer',
        reply: '当前没有配置 LLM API Key。Router 的本地回退模式可以分派只读 Worker，但不能代替模型进行开放对话。请在“设置”中配置 DeepSeek 或其他 OpenAI 兼容端点。',
        tasks: [],
        fallback: true,
      };
    }
    const inferred = capabilities.includes('execute') ? ['read', 'write', 'execute'] : capabilities.includes('write') ? ['read', 'write'] : ['read'];
    return {
      decision: 'delegate',
      reply: '已创建一个隔离 Worker 处理本地任务。当前未配置 LLM，Worker 将以只读回退模式扫描工作区并汇报；涉及写入或命令的任务会被安全门阻止。',
      tasks: [{
        title: titleFromMessage(text),
        prompt: text,
        type: inferred.includes('execute') ? 'command_task' : inferred.includes('write') ? 'code_change' : 'workspace_inspect',
        capabilities: inferred,
        isolation: inferred.includes('execute') ? 'process-exec-gated' : inferred.includes('write') ? 'process-workspace-write' : 'process-readonly',
        expectedOutput: '给出可核查的发现、结果和未解决事项',
      }],
      fallback: true,
    };
  }

  #normalizePlan(plan) {
    const normalized = {
      decision: ['answer', 'delegate', 'clarify'].includes(plan?.decision) ? plan.decision : 'answer',
      reply: typeof plan?.reply === 'string' ? plan.reply : '',
      runTitle: String(plan?.runTitle || '').slice(0, 120),
      strategy: 'coordinator',
      failurePolicy: plan?.failurePolicy === 'stop' ? 'stop' : 'continue',
      maxRounds: Math.max(1, Math.min(3, Number(plan?.maxRounds) || 2)),
      tasks: Array.isArray(plan?.tasks) ? plan.tasks : [],
      memoryUpdates: Array.isArray(plan?.memoryUpdates) ? plan.memoryUpdates : [],
      fallback: Boolean(plan?.fallback),
    };
    normalized.tasks = normalized.tasks.slice(0, 5).map((task, index) => {
      const capabilities = [...new Set(['read', ...(Array.isArray(task.capabilities) ? task.capabilities : [])])]
        .filter((capability) => ['read', 'write', 'execute'].includes(capability));
      if (capabilities.includes('execute')) {
        for (const capability of ['read', 'write', 'execute']) if (!capabilities.includes(capability)) capabilities.push(capability);
      } else if (capabilities.includes('write') && !capabilities.includes('read')) capabilities.push('read');
      const isolation = capabilities.includes('execute')
        ? 'process-exec-gated'
        : capabilities.includes('write') ? 'process-workspace-write' : 'process-readonly';
      // Only earlier tasks may be dependencies, so the executable graph is
      // always acyclic even if the model emits a forward reference.
      const dependsOn = [...new Set((Array.isArray(task.dependsOn) ? task.dependsOn : [])
        .map((value) => Number(value))
        .filter((value) => Number.isInteger(value) && value >= 0 && value < index))];
      const title = String(task.title || `任务 ${index + 1}`).slice(0, 100);
      const roleText = String(task.agentRole || task.role || '').toLowerCase();
      const inferredRole = /review|verify|审核|校验|验证/.test(`${roleText} ${title}`)
        ? 'reviewer'
        : /arbit|仲裁/.test(`${roleText} ${title}`)
          ? 'arbiter'
          : capabilities.includes('write') || capabilities.includes('execute') ? 'implementer'
            : /research|调研|检索|分析/.test(`${roleText} ${task.type || ''} ${title}`) ? 'researcher' : 'general';
      const verification = typeof task.verification === 'boolean'
        ? { required: task.verification }
        : task.verification && typeof task.verification === 'object' ? task.verification : {};
      return {
        title,
        agentRole: ['researcher', 'implementer', 'reviewer', 'arbiter', 'archivist', 'general'].includes(roleText) ? roleText : inferredRole,
        prompt: String(task.prompt || '').slice(0, 30000),
        type: String(task.type || 'general').slice(0, 50),
        capabilities,
        isolation: VALID_ISOLATIONS.has(task.isolation) ? task.isolation : isolation,
        dependsOn,
        handoff: task.handoff && typeof task.handoff === 'object' && !Array.isArray(task.handoff) ? task.handoff : {},
        verification,
        expectedOutput: String(task.expectedOutput || '').slice(0, 2000),
      };
    }).filter((task) => task.prompt);
    if (!normalized.tasks.length && normalized.decision === 'delegate') normalized.decision = 'answer';
    if (normalized.decision === 'answer') normalized.tasks = [];
    return normalized;
  }

  #createTasks(sessionId, specs) {
    return specs.map((spec) => {
      const workspace = resolveSafePath(this.config.workspace, this.config.allowedRoots, { mustExist: true });
      return this.store.createTask({ sessionId, ...spec, workspace, maxAttempts: this.config.taskMaxAttempts || 3 });
    });
  }

  async #onTaskCompleted(task) {
    if (!task) return;
    const summary = await this.#summarizeTask(task, true);
    const message = this.store.addMessage({
      sessionId: task.sessionId,
      role: 'assistant',
      content: summary,
      metadata: { kind: 'task_report', taskId: task.id, status: task.status },
    });
    this.events.emit({ type: 'message.task_result', sessionId: task.sessionId, taskId: task.id, message });
  }

  async #onTaskFailed(task) {
    if (!task) return;
    const message = this.store.addMessage({
      sessionId: task.sessionId,
      role: 'assistant',
      content: `任务“${task.title}”失败。\n\n${task.error || 'Worker 未返回错误详情'}`,
      metadata: { kind: 'task_report', taskId: task.id, status: task.status },
    });
    this.events.emit({ type: 'message.task_result', sessionId: task.sessionId, taskId: task.id, message });
  }

  async #summarizeTask(task, success) {
    const result = String(task.result || '').slice(0, 24000);
    if (this.llm.available && result) {
      try {
        const response = await this.llm.chat([
          { role: 'system', content: '你是 Router。把 Worker 结果整理成给用户的最终答复：先给结论，再给关键证据/产物，最后列未解决事项。不要提内部推理过程，不超过 900 字。' },
          { role: 'user', content: `任务: ${task.title}\n目标: ${task.prompt}\n状态: ${task.status}\nWorker 原始结果:\n${result}` },
        ], { model: this.config.provider.routerModel, temperature: 0.1 });
        if (response.content) return response.content;
      } catch (error) {
        this.logger.warn('任务结果汇总失败', error.message);
      }
    }
    const label = success ? '任务完成' : '任务未完成';
    return `${label}：${task.title}\n\n${result || task.error || '没有返回结果。'}`;
  }

  /** Called exactly once by the Coordinator after the entire DAG is settled. */
  async summarizeCollaboration(run, tasks) {
    const labels = { researcher: '研究/检索', implementer: '执行', reviewer: '独立校验', arbiter: '仲裁', archivist: '归档', general: '通用' };
    const completed = tasks.filter((task) => task.status === 'completed');
    let summary = '';
    if (this.llm.available) {
      try {
        const response = await this.llm.chat([
          {
            role: 'system',
            content: '你是中心 Coordinator 的最终汇总层。把多 Agent 的已核查结果整合成一份给用户的交付：先给结论，再给关键证据/产物路径，再列失败项、冲突与遗留风险。不要逐条复述每个 Agent，不要暴露内部推理过程，不超过 1600 字。',
          },
          {
            role: 'user',
            content: [
              `协作组：${run.title}`,
              `用户目标：${run.goal}`,
              `最终状态：${run.status}`,
              `统计：${completed.length}/${tasks.length} 个 Agent 成功，重试 ${run.metrics?.retries || 0} 次`,
              '',
              ...tasks.map((task, index) => [
                `## Agent ${index + 1} · ${task.title} · ${labels[task.agentRole] || task.agentRole || '通用'} · ${task.status}`,
                `预期：${task.expectedOutput || ''}`,
                `结果：${String(task.result || task.error || '无结果').slice(0, 7000)}`,
              ].join('\n')),
            ].join('\n').slice(0, 42000),
          },
        ], { model: this.config.provider.routerModel, temperature: 0.1, timeoutMs: 180000 });
        if (response.content) summary = response.content;
      } catch (error) {
        this.logger.warn('协作最终汇总失败，使用本地汇总', error.message);
      }
    }
    if (!summary) {
      const lines = [
        `${run.status === 'completed' ? '协作任务已完成' : run.status === 'partial' ? '协作任务部分完成' : '协作任务未完成'}：${run.title}`,
        `Agent：${completed.length}/${tasks.length} 成功 · 重试 ${run.metrics?.retries || 0} 次`,
      ];
      for (const task of tasks) {
        lines.push(`\n## ${task.title} · ${labels[task.agentRole] || task.agentRole || '通用'}\n${String(task.result || task.error || '未返回结果').slice(0, 5000)}`);
      }
      summary = lines.join('\n');
    }
    const content = summary.trim().slice(0, 24000);
    const message = this.store.addMessage({
      sessionId: run.sessionId,
      role: 'assistant',
      content,
      metadata: {
        kind: 'collaboration_report', runId: run.id, status: run.status,
        taskIds: tasks.map((task) => task.id), metrics: run.metrics,
      },
    });
    const ts = nowIso();
    for (const task of tasks) {
      if (!task.notified_at) this.store.updateTask(task.id, { notified_at: ts });
    }
    await this.memory.remember({
      sessionId: run.sessionId,
      kind: 'task_result',
      content: `协作组“${run.title}”${run.status === 'completed' ? '已完成' : `结束状态为 ${run.status}`}：${content.slice(0, 5000)}`,
      importance: run.status === 'completed' ? 3 : 2,
      scope: 'project',
      workspace: run.workspace || this.config.workspace,
      topic: run.title,
      sourceType: 'collaboration',
      source: { runId: run.id, status: run.status },
    });
    this.events.emit({ type: 'message.collaboration_result', sessionId: run.sessionId, runId: run.id, message });
    return content;
  }
  async handleExternalTrigger(trigger) {
    const subscription = this.store.listSubscriptions({ activeOnly: true }).find((candidate) => {
      if (candidate.source !== (trigger.source || 'external')) return false;
      return Object.entries(candidate.matcher || {}).every(([key, expected]) => {
        const actual = key === 'text' ? trigger.text : trigger.metadata?.[key];
        if (typeof expected === 'string') return String(actual || '').includes(expected);
        return actual === expected;
      });
    });
    if (subscription) {
      const parent = subscription.task_id ? this.store.getTask(subscription.task_id) : null;
      const delegated = this.store.createTask({
        sessionId: subscription.session_id,
        title: `订阅触发：${String(trigger.text || trigger.source).slice(0, 40)}`,
        prompt: `${parent ? `原任务：${parent.prompt}\n\n` : ''}收到订阅触发。\n来源：${trigger.source || 'external'}\n内容：${trigger.text || ''}\n元数据：${JSON.stringify(trigger.metadata || {})}`,
        type: parent?.type || 'general',
        capabilities: parent?.capabilities || ['read'],
        isolation: parent?.isolation || 'process-readonly',
        workspace: parent?.workspace || this.config.workspace,
        expectedOutput: parent?.expectedOutput || '处理订阅事件并汇报',
        maxAttempts: this.config.taskMaxAttempts || 3,
      });
      this.manager.enqueue(delegated.id);
      this.store.addEvent({ type: 'trigger.subscription', sessionId: subscription.session_id, taskId: delegated.id, payload: { subscriptionId: subscription.id, trigger } });
      this.events.emit({ type: 'trigger.routed_directly', sessionId: subscription.session_id, taskId: delegated.id, subscriptionId: subscription.id, trigger });
      return { routed: true, direct: true, subscription, task: delegated };
    }
    const result = this.rules.evaluate(trigger);
    this.store.addEvent({ type: 'trigger.external', sessionId: trigger.sessionId || null, payload: { ...trigger, rule: result } });
    if (!result.shouldRoute || !trigger.sessionId) {
      this.events.emit({ type: 'trigger.ignored', trigger, rule: result });
      return { routed: false, rule: result };
    }
    return await this.handleUserMessage({ sessionId: trigger.sessionId, text: trigger.text, source: trigger.source || 'external' });
  }
}

function titleFromMessage(text) {
  return String(text || '新会话').replace(/\s+/g, ' ').trim().slice(0, 32) || '新会话';
}












