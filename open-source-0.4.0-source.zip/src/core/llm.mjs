export class LLMError extends Error {
  constructor(message, details = {}) {
    super(message);
    this.name = 'LLMError';
    this.details = details;
  }
}

function stripFence(text) {
  const value = String(text ?? '').trim();
  const match = value.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  return match ? match[1].trim() : value;
}

export function parseJsonResponse(text) {
  const raw = stripFence(text);
  try {
    return JSON.parse(raw);
  } catch {
    const first = raw.indexOf('{');
    const last = raw.lastIndexOf('}');
    if (first >= 0 && last > first) return JSON.parse(raw.slice(first, last + 1));
    throw new LLMError('模型没有返回有效 JSON', { raw });
  }
}

export class LLMClient {
  constructor(config) {
    this.config = config;
  }

  get available() {
    return Boolean(this.config.apiKey);
  }

  endpoint() {
    let base = String(this.config.baseUrl || '').trim().replace(/\/+$/, '');
    if (!base) throw new LLMError('没有配置 LLM baseUrl');
    if (!base.endsWith('/v1') && !/\/v\d+$/.test(base)) base = `${base}/v1`;
    return `${base}/chat/completions`;
  }

  async chat(messages, options = {}) {
    if (!this.available) throw new LLMError('没有配置 LLM API Key');
    const model = options.model || this.config.model || 'deepseek-chat';
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), options.timeoutMs || this.config.timeoutMs || 120000);
    try {
      const body = {
        model,
        messages,
        temperature: options.temperature ?? this.config.temperature ?? 0.2,
        stream: false,
      };
      if (options.tools?.length) {
        body.tools = options.tools;
        body.tool_choice = options.toolChoice || 'auto';
      }
      if (options.jsonMode) body.response_format = { type: 'json_object' };

      const response = await fetch(this.endpoint(), {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${this.config.apiKey}`,
        },
        body: JSON.stringify(body),
        signal: options.signal || controller.signal,
      });
      const text = await response.text();
      let data;
      try { data = JSON.parse(text); } catch { data = { raw: text }; }
      if (!response.ok) {
        throw new LLMError(`LLM 请求失败 (${response.status})`, { status: response.status, body: data });
      }
      const message = data.choices?.[0]?.message;
      if (!message) throw new LLMError('LLM 响应缺少 message', { body: data });
      return {
        message,
        content: message.content || '',
        toolCalls: message.tool_calls || [],
        usage: data.usage || null,
        raw: data,
      };
    } catch (error) {
      if (error?.name === 'AbortError') throw new LLMError('LLM 请求超时', { cause: error.message });
      if (error instanceof LLMError) throw error;
      throw new LLMError(`LLM 网络请求失败: ${error.message}`, { cause: error.message });
    } finally {
      clearTimeout(timeout);
    }
  }

  async chatJson(messages, options = {}) {
    const response = await this.chat(messages, { ...options, jsonMode: true });
    return { ...response, json: parseJsonResponse(response.content) };
  }
}

export function createLLMClient(config) {
  return new LLMClient(config.provider);
}
