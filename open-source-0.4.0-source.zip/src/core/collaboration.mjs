import { nowIso } from './ids.mjs';
import { resolveSafePath } from './security.mjs';

const TERMINAL = new Set(['completed', 'failed', 'cancelled']);
const ACTIVE = new Set(['queued', 'running', 'waiting_approval']);
const KNOWN_ROLES = new Set(['coordinator', 'researcher', 'implementer', 'reviewer', 'arbiter', 'archivist', 'general']);
const ROLE_ALIASES = new Map([
  ['research', 'researcher'], ['researcher', 'researcher'], ['检索', 'researcher'], ['研究', 'researcher'],
  ['implement', 'implementer'], ['implementer', 'implementer'], ['developer', 'implementer'], ['实现', 'implementer'], ['开发', 'implementer'],
  ['review', 'reviewer'], ['reviewer', 'reviewer'], ['verifier', 'reviewer'], ['审核', 'reviewer'], ['校验', 'reviewer'], ['验证', 'reviewer'],
  ['arbiter', 'arbiter'], ['仲裁', 'arbiter'],
  ['archive', 'archivist'], ['archivist', 'archivist'], ['归档', 'archivist'],
  ['coordinator', 'coordinator'], ['协调', 'coordinator'], ['编排', 'coordinator'],
]);

export function normalizeAgentRole(value, fallback = 'general') {
  const role = String(value || '').trim().toLowerCase();
  if (KNOWN_ROLES.has(role)) return role;
  return ROLE_ALIASES.get(role) || fallback;
}

function normalizeDependencies(value, index, count) {
  const raw = Array.isArray(value) ? value : [];
  return [...new Set(raw.map((item) => Number(item)).filter((item) => Number.isInteger(item) && item >= 0 && item < count && item !== index))];
}

/** Validate dependencies and reject cycles before any process is launched. */
export function validateCollaborationPlan(tasks, { maxAgents = 5 } = {}) {
  if (!Array.isArray(tasks) || !tasks.length) throw new Error('协作计划至少需要一个 Agent 任务');
  if (tasks.length > maxAgents) throw new Error(`协作计划超过 Agent 上限（${tasks.length}/${maxAgents}）`);
  const normalized = tasks.map((task, index) => {
    if (!task || !String(task.prompt || '').trim()) throw new Error(`第 ${index + 1} 个 Agent 缺少任务说明`);
    const dependsOn = normalizeDependencies(task.dependsOn, index, tasks.length);
    const declared = Array.isArray(task.dependsOn) ? new Set(task.dependsOn.map((item) => Number(item))).size : 0;
    if (declared !== dependsOn.length) throw new Error(`第 ${index + 1} 个 Agent 包含无效或自引用依赖`);
    return { ...task, dependsOn };
  });
  const state = new Array(normalized.length).fill(0);
  const visit = (index, trail = []) => {
    if (state[index] === 1) throw new Error(`协作依赖存在循环：${[...trail, index].map((item) => item + 1).join(' → ')}`);
    if (state[index] === 2) return;
    state[index] = 1;
    for (const dependency of normalized[index].dependsOn) visit(dependency, [...trail, index]);
    state[index] = 2;
  };
  for (let index = 0; index < normalized.length; index += 1) visit(index);
  return normalized;
}

function resultExcerpt(task, budget = 5200) {
  const text = String(task?.result || task?.error || '没有返回结果').trim();
  return text.length <= budget ? text : `${text.slice(0, budget)}\n…（结果已截断，完整内容保存在任务审计记录中）`;
}

function roleLabel(role) {
  return ({
    coordinator: '协调者', researcher: '研究/检索', implementer: '执行者', reviewer: '独立校验',
    arbiter: '仲裁者', archivist: '归档者', general: '通用 Agent',
  })[role] || role || '通用 Agent';
}

function fallbackSummary(run, tasks) {
  const completed = tasks.filter((task) => task.status === 'completed');
  const failed = tasks.filter((task) => task.status !== 'completed');
  const lines = [
    `${run.status === 'completed' ? '多智能体协作已完成' : run.status === 'partial' ? '多智能体协作部分完成' : '多智能体协作未完成'}：${run.title}`,
    `Agent：${completed.length}/${tasks.length} 成功，协作策略：${run.strategy}`,
  ];
  for (const task of completed.slice(-3)) {
    lines.push(`\n## ${task.title} · ${roleLabel(task.agentRole)}\n${resultExcerpt(task, 2800)}`);
  }
  if (failed.length) lines.push('\n## 需要处理', ...failed.map((task) => `- ${task.title}：${task.error || '未完成'}`));
  return lines.join('\n').slice(0, 18000);
}

export class CollaborationCoordinator {
  constructor({ config, store, manager, events, logger, onSettled = null }) {
    this.config = config;
    this.store = store;
    this.manager = manager;
    this.events = events;
    this.logger = logger;
    this.onSettled = onSettled;
    this.timers = new Map();
    this.schedules = new Map();
    this.finalizing = new Set();
    this.closed = false;
    this.unsubscribe = events.subscribe((event) => {
      if (!event?.task?.runId) return;
      if (!['task.completed', 'task.failed', 'task.cancelled', 'task.restarted'].includes(event.type)) return;
      queueMicrotask(() => {
        this.#schedule(event.task.runId).catch((error) => this.logger?.warn('协作调度失败', error.message));
      });
    });
  }

  async createRun({ sessionId, title, goal, strategy = 'coordinator', failurePolicy = 'continue', maxRounds = 2, tasks = [], workspace = null }) {
    if (!sessionId) throw new Error('协作运行缺少会话');
    const maxAgents = Math.max(1, Math.min(5, Number(this.config.collaboration?.maxAgents) || 5));
    const specs = validateCollaborationPlan(tasks, { maxAgents });
    const resolvedWorkspace = resolveSafePath(workspace || this.config.workspace, this.config.allowedRoots, { mustExist: true });
    const run = this.store.createCollaborationRun({
      sessionId,
      title: title || goal || '多智能体协作',
      goal,
      strategy,
      failurePolicy,
      maxAgents,
      maxRounds,
      timeoutMs: Number(this.config.collaboration?.timeoutMs) || 30 * 60 * 1000,
      plan: {
        strategy,
        failurePolicy,
        tasks: specs.map((task, index) => ({
          index,
          title: task.title,
          role: normalizeAgentRole(task.agentRole || task.role),
          dependsOn: task.dependsOn,
          capabilities: task.capabilities || ['read'],
          expectedOutput: task.expectedOutput || '',
          verification: task.verification || {},
        })),
      },
    });

    const created = [];
    for (let index = 0; index < specs.length; index += 1) {
      const spec = specs[index];
      const role = normalizeAgentRole(spec.agentRole || spec.role);
      const task = this.store.createTask({
        sessionId,
        title: spec.title || `Agent ${index + 1}`,
        prompt: String(spec.prompt).slice(0, 30000),
        type: spec.type || 'general',
        status: 'blocked',
        capabilities: spec.capabilities || ['read'],
        isolation: spec.isolation || 'process-readonly',
        workspace: spec.workspace || resolvedWorkspace,
        expectedOutput: spec.expectedOutput || '完成分配的子任务并提交可供下游交接的结果',
        maxAttempts: Number(spec.maxAttempts || this.config.taskMaxAttempts || 3),
        runId: run.id,
        agentRole: role,
        dependsOn: [],
        handoff: spec.handoff && typeof spec.handoff === 'object' ? spec.handoff : {},
        verification: spec.verification && typeof spec.verification === 'object' ? spec.verification : {},
        collaborationOrder: index,
        supervisor: {
          collaboration: { runId: run.id, role, order: index },
          basePrompt: String(spec.prompt).slice(0, 30000),
          collaborationDependencies: spec.dependsOn,
        },
      });
      created.push(task);
    }

    for (let index = 0; index < created.length; index += 1) {
      this.store.updateTask(created[index].id, {
        dependsOn: specs[index].dependsOn.map((dependency) => created[dependency].id),
        progress: specs[index].dependsOn.length ? '等待上游 Agent 交接' : '等待调度',
      });
    }

    const persistedTasks = this.store.listTasksByRun(run.id);
    const planTasks = persistedTasks.map((task, index) => ({
      ...run.plan.tasks[index], taskId: task.id, dependsOnTaskIds: task.dependsOn,
    }));
    const updatedRun = this.store.updateCollaborationRun(run.id, { plan: { ...run.plan, tasks: planTasks } });
    this.store.addEvent({
      type: 'collaboration.created', sessionId,
      payload: { runId: run.id, title: run.title, tasks: created.map((task) => ({ id: task.id, title: task.title, role: task.agentRole })) },
    });
    this.events.emit({ type: 'collaboration.created', sessionId, runId: run.id, run: updatedRun, tasks: persistedTasks });
    await this.#schedule(run.id);
    return { run: this.store.getCollaborationRun(run.id), tasks: this.store.listTasksByRun(run.id) };
  }

  async resumeRuns() {
    const runs = this.store.listCollaborationRuns({ limit: 500 })
      .filter((run) => ['queued', 'running'].includes(run.status));
    for (const run of runs) {
      this.store.addEvent({ type: 'collaboration.recovered', sessionId: run.sessionId, payload: { runId: run.id, reason: '应用重启' } });
      this.events.emit({ type: 'collaboration.recovered', sessionId: run.sessionId, runId: run.id, run });
      await this.#schedule(run.id);
    }
    return runs.length;
  }

  detail(runId) {
    const run = this.store.getCollaborationRun(runId);
    return run ? { run, tasks: this.store.listTasksByRun(runId) } : null;
  }

  async cancel(runId, reason = '用户取消协作') {
    const run = this.store.getCollaborationRun(runId);
    if (!run) return null;
    if (TERMINAL.has(run.status)) return run;
    this.#clearTimer(runId);
    this.finalizing.add(runId);
    for (const task of this.store.listTasksByRun(runId)) {
      if (TERMINAL.has(task.status)) continue;
      if (task.status === 'blocked') {
        this.store.updateTask(task.id, {
          status: 'cancelled', error: reason, progress: '协作已取消', finished_at: nowIso(),
          supervisor: { ...(task.supervisor || {}), collaborationCancelledAt: nowIso() },
        });
      } else {
        this.manager.cancel(task.id, reason);
      }
    }
    const tasks = this.store.listTasksByRun(runId);
    const updated = this.store.updateCollaborationRun(runId, {
      status: 'cancelled', error: reason, finished_at: nowIso(), metrics: this.#metrics(run, tasks),
    });
    this.events.emit({ type: 'collaboration.cancelled', sessionId: run.sessionId, runId, run: updated, reason });
    this.finalizing.delete(runId);
    return updated;
  }

  async retry(runId) {
    const oldRun = this.store.getCollaborationRun(runId);
    if (!oldRun) return null;
    const oldTasks = this.store.listTasksByRun(runId);
    if (!oldTasks.length) return null;
    const indexById = new Map(oldTasks.map((task, index) => [task.id, index]));
    return await this.createRun({
      sessionId: oldRun.sessionId,
      title: oldRun.title,
      goal: oldRun.goal,
      strategy: oldRun.strategy,
      failurePolicy: oldRun.failurePolicy,
      maxRounds: oldRun.maxRounds,
      workspace: oldTasks[0].workspace,
      tasks: oldTasks.map((task) => ({
        title: task.title,
        prompt: task.supervisor?.basePrompt || task.prompt,
        type: task.type,
        capabilities: task.capabilities,
        isolation: task.isolation,
        expectedOutput: task.expectedOutput,
        agentRole: task.agentRole,
        dependsOn: (task.dependsOn || []).map((id) => indexById.get(id)).filter(Number.isInteger),
        handoff: task.handoff,
        verification: task.verification,
        maxAttempts: task.maxAttempts,
      })),
    });
  }

  async #schedule(runId) {
    const previous = this.schedules.get(runId) || Promise.resolve();
    const current = previous.catch(() => {}).then(() => this.#runSchedule(runId));
    this.schedules.set(runId, current);
    try { await current; }
    finally { if (this.schedules.get(runId) === current) this.schedules.delete(runId); }
  }

  async #runSchedule(runId) {
    if (this.closed || this.finalizing.has(runId)) return;
    let run = this.store.getCollaborationRun(runId);
    if (!run || TERMINAL.has(run.status)) return;
    let tasks = this.store.listTasksByRun(runId);
    if (!tasks.length) return await this.#finalize(runId, { forcedStatus: 'failed', error: '协作计划没有可执行任务' });

    if (run.status === 'queued') {
      this.#startTimer(run);
      run = this.store.updateCollaborationRun(runId, {
        status: 'running', started_at: run.started_at || nowIso(), metrics: this.#metrics(run, tasks),
      });
    }

    const failedTask = tasks.find((task) => ['failed', 'cancelled'].includes(task.status));
    if (failedTask && run.failurePolicy === 'stop') {
      this.finalizing.add(runId);
      for (const task of tasks.filter((item) => !TERMINAL.has(item.status))) {
        if (task.status === 'blocked') {
          this.store.updateTask(task.id, {
            status: 'cancelled', error: `协作策略 stop：上游 ${failedTask.title} 失败`, progress: '因协作中止而取消', finished_at: nowIso(),
          });
        } else {
          this.manager.cancel(task.id, `协作策略 stop：上游 ${failedTask.title} 失败`);
        }
      }
      this.finalizing.delete(runId);
      tasks = this.store.listTasksByRun(runId);
      return await this.#finalize(runId, { forcedStatus: tasks.some((task) => task.status === 'completed') ? 'partial' : 'failed' });
    }

    const byId = new Map(tasks.map((task) => [task.id, task]));
    for (const task of tasks.filter((item) => item.status === 'blocked')) {
      const dependencies = (task.dependsOn || []).map((id) => byId.get(id)).filter(Boolean);
      const missing = (task.dependsOn || []).find((id) => !byId.has(id));
      const failedDependency = dependencies.find((dependency) => ['failed', 'cancelled'].includes(dependency.status)) || missing;
      if (failedDependency) {
        const title = typeof failedDependency === 'string' ? failedDependency : failedDependency.title;
        this.store.updateTask(task.id, {
          status: 'failed', error: `依赖 Agent 未成功：${title}`, progress: '依赖失败，未执行', finished_at: nowIso(),
          supervisor: { ...(task.supervisor || {}), dependencyFailure: true },
        });
        this.events.emit({ type: 'collaboration.node.blocked', sessionId: run.sessionId, runId, taskId: task.id, dependency: title });
        continue;
      }
      if (dependencies.length && dependencies.length === (task.dependsOn || []).length && dependencies.every((dependency) => dependency.status === 'completed')) {
        const updated = this.store.updateTask(task.id, {
          prompt: this.#withHandoff(task, dependencies, byId),
          status: 'queued',
          progress: `依赖已满足，交接给${roleLabel(task.agentRole)}`,
          started_at: null, finished_at: null, error: null,
          supervisor: {
            ...(task.supervisor || {}),
            handoffContext: dependencies.map((dependency) => ({
              taskId: dependency.id, title: dependency.title, role: dependency.agentRole, result: resultExcerpt(dependency, 1800),
            })),
            dispatchedAt: nowIso(),
          },
        });
        this.events.emit({ type: 'collaboration.node.ready', sessionId: run.sessionId, runId, taskId: task.id, task: updated });
        try { this.manager.enqueue(task.id); }
        catch (error) { this.store.updateTask(task.id, { status: 'failed', error: `调度失败：${error.message}`, finished_at: nowIso() }); }
      } else if (!task.dependsOn?.length) {
        const updated = this.store.updateTask(task.id, { status: 'queued', progress: '无依赖，立即执行', error: null });
        this.events.emit({ type: 'collaboration.node.ready', sessionId: run.sessionId, runId, taskId: task.id, task: updated });
        try { this.manager.enqueue(task.id); }
        catch (error) { this.store.updateTask(task.id, { status: 'failed', error: `调度失败：${error.message}`, finished_at: nowIso() }); }
      }
    }

    tasks = this.store.listTasksByRun(runId);
    run = this.store.updateCollaborationRun(runId, { metrics: this.#metrics(run, tasks), error: null });
    this.events.emit({ type: 'collaboration.updated', sessionId: run.sessionId, runId, run, tasks });
    if (tasks.every((task) => TERMINAL.has(task.status))) return await this.#finalize(runId);
    if (!tasks.some((task) => ACTIVE.has(task.status)) && !tasks.some((task) => task.status === 'blocked')) {
      return await this.#finalize(runId, { forcedStatus: 'failed', error: '协作调度停滞：没有可执行 Agent' });
    }
  }

  #withHandoff(task, dependencies, byId = new Map()) {
    const basePrompt = String(task.supervisor?.basePrompt || task.prompt || '');
    const requested = task.handoff && Object.keys(task.handoff).length
      ? `\n交接要求：${JSON.stringify(task.handoff).slice(0, 1500)}` : '';
    // Include direct dependencies and their ancestors so a reviewer can trace
    // evidence without asking Agents to communicate peer-to-peer.
    const gathered = [];
    const seen = new Set();
    const collect = (dependency) => {
      if (!dependency || seen.has(dependency.id)) return;
      seen.add(dependency.id);
      for (const id of dependency.dependsOn || []) collect(byId.get(id));
      gathered.push(dependency);
    };
    for (const dependency of dependencies) collect(dependency);
    const budget = Math.max(1800, Math.floor(16000 / Math.max(1, gathered.length)));
    const upstream = gathered.map((dependency, index) => [
      `### 上游 ${index + 1}：${dependency.title}`,
      `角色：${roleLabel(dependency.agentRole)}`,
      `目标：${dependency.expectedOutput || dependency.title}`,
      `交付结果：\n${resultExcerpt(dependency, budget)}`,
    ].join('\n')).join('\n\n');
    return [
      basePrompt, '', '--- 中心化协作交接上下文（来自上游 Agent，已由 Coordinator 汇总） ---', upstream, requested, '',
      '执行要求：只完成你负责的边界；复用上游已有产物，不重复已完成工作；如有冲突请明确列出证据和待仲裁项；最终交付必须可被下游直接使用。',
    ].filter(Boolean).join('\n').slice(0, 26000);
  }

  #metrics(run, tasks) {
    const completed = tasks.filter((task) => task.status === 'completed').length;
    const failed = tasks.filter((task) => task.status === 'failed').length;
    const cancelled = tasks.filter((task) => task.status === 'cancelled').length;
    const retries = tasks.reduce((sum, task) => sum + Math.max(0, (Number(task.attempt) || 1) - 1), 0);
    const usage = tasks.reduce((sum, task) => {
      const current = task.supervisor?.usage || {};
      sum.llmCalls += Number(current.llmCalls) || 0;
      sum.promptTokens += Number(current.promptTokens) || 0;
      sum.completionTokens += Number(current.completionTokens) || 0;
      sum.totalTokens += Number(current.totalTokens) || 0;
      return sum;
    }, { llmCalls: 0, promptTokens: 0, completionTokens: 0, totalTokens: 0 });
    const endedAt = run.finished_at || nowIso();
    return {
      agentCount: tasks.length, completed, failed, cancelled, retries, usage,
      successRate: tasks.length ? Number((completed / tasks.length).toFixed(3)) : 0,
      durationMs: Math.max(0, Date.parse(endedAt) - Date.parse(run.started_at || run.created_at)),
      maxRoundsObserved: tasks.reduce((max, task) => Math.max(max, Number(task.attempt) || 1), 0),
    };
  }

  async #finalize(runId, { forcedStatus = null, error = null } = {}) {
    if (this.finalizing.has(runId)) return this.store.getCollaborationRun(runId);
    this.finalizing.add(runId);
    this.#clearTimer(runId);
    try {
      let run = this.store.getCollaborationRun(runId);
      let tasks = this.store.listTasksByRun(runId);
      if (!run || run.status === 'cancelled' || TERMINAL.has(run.status)) return run;
      const completed = tasks.filter((task) => task.status === 'completed').length;
      const status = forcedStatus || (completed === tasks.length ? 'completed' : completed > 0 ? 'partial' : 'failed');
      const failures = tasks.filter((task) => task.status !== 'completed').map((task) => `${task.title}: ${task.error || task.status}`);
      run = this.store.updateCollaborationRun(runId, {
        status, metrics: this.#metrics(run, tasks),
        error: error || failures.join('\n') || null, finished_at: nowIso(),
      });
      let summary = '';
      if (typeof this.onSettled === 'function') {
        try { summary = await this.onSettled(run, tasks); }
        catch (callbackError) { this.logger?.warn('协作最终汇总失败', callbackError.message); }
      }
      if (!summary) summary = fallbackSummary(run, tasks);
      run = this.store.updateCollaborationRun(runId, { summary: String(summary).slice(0, 30000) });
      this.store.addEvent({
        type: `collaboration.${status}`, sessionId: run.sessionId,
        payload: { runId, status, metrics: run.metrics, summary: run.summary },
      });
      this.events.emit({
        type: `collaboration.${status}`, sessionId: run.sessionId, runId, run,
        tasks: this.store.listTasksByRun(runId), summary: run.summary,
      });
      return run;
    } finally {
      this.finalizing.delete(runId);
    }
  }

  #startTimer(run) {
    this.#clearTimer(run.id);
    const elapsed = Math.max(0, Date.now() - Date.parse(run.created_at));
    const remaining = Math.max(1000, (Number(run.timeoutMs) || 30 * 60 * 1000) - elapsed);
    const timer = setTimeout(() => {
      this.timers.delete(run.id);
      this.#timeout(run.id).catch((error) => this.logger?.warn('协作超时处理失败', error.message));
    }, remaining);
    timer.unref?.();
    this.timers.set(run.id, timer);
  }

  async #timeout(runId) {
    const run = this.store.getCollaborationRun(runId);
    if (!run || TERMINAL.has(run.status)) return;
    this.finalizing.add(runId);
    for (const task of this.store.listTasksByRun(runId)) {
      if (TERMINAL.has(task.status)) continue;
      if (task.status === 'blocked') {
        this.store.updateTask(task.id, { status: 'failed', error: '协作组超过总时限', progress: '协作超时', finished_at: nowIso() });
      } else {
        this.manager.cancel(task.id, '协作组超过总时限');
      }
    }
    this.finalizing.delete(runId);
    await this.#finalize(runId, { forcedStatus: 'failed', error: `协作超过总时限（${Math.round(run.timeoutMs / 1000)} 秒）` });
  }

  #clearTimer(runId) {
    const timer = this.timers.get(runId);
    if (timer) clearTimeout(timer);
    this.timers.delete(runId);
  }

  snapshot() {
    return {
      active: this.finalizing.size, scheduling: this.schedules.size, timers: this.timers.size,
      maxAgents: Number(this.config.collaboration?.maxAgents) || 5,
    };
  }

  close() {
    this.closed = true;
    for (const timer of this.timers.values()) clearTimeout(timer);
    this.timers.clear();
    this.unsubscribe?.();
  }
}

export function createCollaborationCoordinator(options) {
  return new CollaborationCoordinator(options);
}


