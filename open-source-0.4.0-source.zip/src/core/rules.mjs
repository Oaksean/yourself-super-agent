const READ_WORDS = [
  '读取', '查看', '分析', '总结', '检查', '搜索', '查找', '扫描', '审阅', 'review', 'read', 'inspect', 'search', 'analyze', 'summarize',
];
const WRITE_WORDS = ['修改', '写入', '创建文件', '编辑', '重命名', '删除', '生成文件', 'write', 'edit', 'create file', 'rename', 'delete'];
const COMMAND_WORDS = ['运行', '执行', '构建', '测试', '安装', '启动', '命令', 'npm', 'pnpm', 'node ', 'python ', 'cargo', 'git ', 'run', 'execute', 'build', 'test', 'install'];

const normalize = (value) => String(value || '').toLowerCase();

export class RuleEngine {
  evaluate(trigger) {
    const text = normalize(trigger.text);
    const reasons = [];
    if (trigger.source === 'user') reasons.push('用户直接输入必须进入 Router');

    const hasRead = READ_WORDS.some((word) => text.includes(word));
    const hasWrite = WRITE_WORDS.some((word) => text.includes(word));
    const hasCommand = COMMAND_WORDS.some((word) => text.includes(word));
    if (hasWrite) reasons.push('检测到写入意图');
    if (hasCommand) reasons.push('检测到执行意图');
    if (hasRead) reasons.push('检测到本地分析意图');

    const capabilities = ['read'];
    if (hasWrite) capabilities.push('write');
    if (hasCommand) capabilities.push('execute');
    const isolation = hasCommand ? 'process-exec-gated' : hasWrite ? 'process-workspace-write' : 'process-readonly';
    const shouldRoute = trigger.source === 'user' || hasRead || hasWrite || hasCommand;
    return {
      shouldRoute,
      reasons,
      hints: { capabilities, isolation, needsLocalAccess: hasRead || hasWrite || hasCommand },
      score: [hasRead, hasWrite, hasCommand].filter(Boolean).length,
    };
  }
}

export function inferCapabilities(text) {
  const result = ['read'];
  const value = normalize(text);
  if (WRITE_WORDS.some((word) => value.includes(word))) result.push('write');
  if (COMMAND_WORDS.some((word) => value.includes(word))) result.push('execute');
  return [...new Set(result)];
}
