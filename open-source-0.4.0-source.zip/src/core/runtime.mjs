import path from 'node:path';
import { loadConfig, publicConfig, updateLocalSettings } from './config.mjs';
import { createLogger } from './logger.mjs';
import { EventBus } from './events.mjs';
import { openStore } from './db.mjs';
import { createLLMClient } from './llm.mjs';
import { RuleEngine } from './rules.mjs';
import { MemoryService } from './memory.mjs';
import { EmbeddingService } from './embed/embedding-service.mjs';
import { WorkerManager } from './worker-manager.mjs';
import { Watchdog } from './watchdog.mjs';
import { WatcherService } from './watchers/watcher-service.mjs';
import { Router } from './router.mjs';
import { createCollaborationCoordinator } from './collaboration.mjs';
import { createMasService } from './mas/pipeline.mjs';
import { sandboxCapabilities, ensureAppContainerAccess } from './sandbox.mjs';

export function createRuntime(config = loadConfig()) {
  const logger = createLogger({ logDir: config.logDir, level: process.env.AGENT_LOG_LEVEL || 'info' });
  const events = new EventBus();
  const store = openStore(config);
  const llm = createLLMClient(config);
  const rules = new RuleEngine();
  const embeddings = new EmbeddingService({ provider: config.provider, config, logger });
  const memory = new MemoryService(store, llm, logger, embeddings, { config, events });
  memory.setWorkspace(config.workspace);
  memory.configure(config.memory || {});
  const manager = new WorkerManager({ config, store, llm, events, logger, memory });
  const watchdog = new Watchdog({
    manager,
    store,
    events,
    logger,
    intervalMs: config.watchdogIntervalMs,
    stallMs: config.watchdogStallMs,
  });
  let router;
  const collaboration = createCollaborationCoordinator({
    config, store, manager, events, logger,
    onSettled: (run, tasks) => router.summarizeCollaboration(run, tasks),
  });
  router = new Router({ config, store, llm, memory, manager, collaboration, rules, events, logger });
  const mas = createMasService({ config, store, llm, events, logger, memory });
  const watchers = new WatcherService({ config, store, logger });
  watchers.on('trigger', (trigger) => {
    router.handleExternalTrigger(trigger).catch((error) => logger.warn('文件触发路由失败', error.message));
  });

  return {
    config,
    logger,
    events,
    store,
    llm,
    memory,
    embeddings,
    manager,
    watchdog,
    watchers,
    router,
    collaboration,
    mas,
    start() {
      watchdog.start();
      memory.setWorkspace(config.workspace);
      memory.scheduleDreaming();
      memory.syncIndex(config.workspace).catch((error) => logger.warn('长期记忆索引同步失败', error.message));
      watchers.start();
      manager.resumePendingTasks();
      collaboration.resumeRuns().catch((error) => logger.warn('协作运行恢复失败', error.message));
      const recoveredMas = mas.resumePendingRuns();
      if (recoveredMas) logger.info('已恢复 ' + recoveredMas + ' 个专项协同运行');
      // When AppContainer isolation is active the restricted token needs
      // explicit read access to the Node runtime, the project and the
      // workspace, otherwise the Worker cannot even load node.exe.
      if (manager.sandbox.tier === 'appcontainer' && manager.sandbox.host) {
        ensureAppContainerAccess({
          host: manager.sandbox.host,
          roots: [...config.allowedRoots, config.projectRoot],
          runtimeDir: path.dirname(process.execPath),
          logger,
        });
      }
      memory.backfill().then((count) => {
        if (count) logger.info(`已为 ${count} 条历史记忆建立向量索引`);
      }).catch((error) => logger.warn('记忆向量回填失败', error.message));
    },
    updateSettings(patch) {
      const result = updateLocalSettings(config, patch);
      memory.configure(config.memory || {});
      memory.setWorkspace(result.workspace);
      store.workspace = result.workspace;
      memory.scheduleDreaming();
      memory.queueIndexSync(result.workspace);
      if (patch?.workspace && manager.sandbox.tier === 'appcontainer' && manager.sandbox.host) {
        ensureAppContainerAccess({
          host: manager.sandbox.host,
          roots: [result.workspace],
          runtimeDir: path.dirname(process.execPath),
          logger,
        });
      }
      events.emit({ type: 'settings.updated', settings: result });
      return result;
    },
    status() {
      return {
        ok: true,
        node: process.version,
        uptimeSec: Math.round(process.uptime()),
        worker: manager.snapshot(),
        sandbox: sandboxCapabilities(config),
        watchers: watchers.snapshot(),
        memory: {
          embeddingModel: embeddings.model,
          remoteEmbeddings: embeddings.remoteEnabled && !embeddings.remoteBroken,
          dim: embeddings.dim,
        },
        provider: publicConfig(config).provider,
        sessions: store.listSessions(1000).length,
        mas: mas.snapshot(),
        collaboration: collaboration.snapshot(),
      };
    },
    async close() {
      watchdog.stop();
      watchers.stop();
      memory.dispose();
      collaboration.close();
      await mas.close();
      manager.close();
      store.close();
    },
  };
}





