export class EventBus {
  #subscribers = new Set();

  subscribe(listener) {
    this.#subscribers.add(listener);
    return () => this.#subscribers.delete(listener);
  }

  emit(event) {
    const payload = { ...event, ts: event.ts || new Date().toISOString() };
    for (const listener of [...this.#subscribers]) {
      try {
        listener(payload);
      } catch {
        // A broken SSE client must not stop the agent runtime.
      }
    }
    return payload;
  }
}
