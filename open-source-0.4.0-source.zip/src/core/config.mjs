import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, '..', '..');

function readJson(file, fallback = {}) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    if (error.code === 'ENOENT') return fallback;
    throw new Error(`无法读取配置文件 ${file}: ${error.message}`);
  }
}

function deepMerge(base, extra) {
  if (!extra || typeof extra !== 'object' || Array.isArray(extra)) return extra ?? base;
  const out = { ...base };
  for (const [key, value] of Object.entries(extra)) {
    out[key] = value && typeof value === 'object' && !Array.isArray(value)
      ? deepMerge(base?.[key] ?? {}, value)
      : value;
  }
  return out;
}

function envBool(name, fallback) {
  const value = process.env[name];
  if (value == null || value === '') return fallback;
  return ['1', 'true', 'yes', 'on'].includes(String(value).toLowerCase());
}

function envNumber(name, fallback) {
  const value = process.env[name];
  if (value == null || value === '') return fallback;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function pathKey(value) {
  const resolved = path.resolve(value);
  return process.platform === 'win32' ? resolved.toLowerCase() : resolved;
}

function uniquePaths(values) {
  const seen = new Set();
  const result = [];
  for (const value of values || []) {
    if (!value) continue;
    const resolved = path.resolve(value);
    const key = pathKey(resolved);
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(resolved);
  }
  return result;
}

function resolveTaskWorkspace(input, root) {
  const raw = String(input || '').trim();
  if (!raw) throw new Error('任务文件夹不能为空');
  if (!path.isAbsolute(raw)) throw new Error('请选择文件夹的绝对路径');
  let resolved;
  try {
    resolved = fs.realpathSync.native(raw);
    if (!fs.statSync(resolved).isDirectory()) throw new Error('目标不是文件夹');
  } catch (error) {
    if (error.message === '目标不是文件夹') throw error;
    throw new Error(`任务文件夹不存在或无法访问: ${path.resolve(root, raw)}`);
  }
  return resolved;
}

export function loadConfig({ root = projectRoot } = {}) {
  // Shipped defaults always come from the installed project root (where this
  // module lives); `root` only redirects workspace / data / log locations.
  const defaults = readJson(path.join(projectRoot, 'config', 'default.json'));
  const local = readJson(path.join(projectRoot, 'config', 'config.local.json'));
  let config = deepMerge(defaults, local);

  // Data / logs / user settings may live outside the (possibly read-only)
  // install directory. The desktop shell points these at %LOCALAPPDATA%.
  config.dataDir = path.resolve(process.env.AGENT_DATA_DIR || path.resolve(root, config.dataDir || 'data'));
  config.logDir = path.resolve(process.env.AGENT_LOG_DIR || path.resolve(root, config.logDir || 'logs'));
  config.settingsFile = path.join(config.dataDir, 'config.local.json');

  // User-level overrides saved from the UI win over the shipped defaults.
  config = deepMerge(config, readJson(config.settingsFile, {}));

  config.host = process.env.AGENT_HOST || config.host;
  config.port = envNumber('AGENT_PORT', config.port);
  config.workspace = process.env.AGENT_WORKSPACE || config.workspace;
  config.maxWorkers = envNumber('AGENT_MAX_WORKERS', config.maxWorkers);
  config.taskTimeoutMs = envNumber('AGENT_TASK_TIMEOUT_MS', config.taskTimeoutMs);
  config.taskMaxAttempts = Math.max(1, envNumber('AGENT_TASK_MAX_ATTEMPTS', config.taskMaxAttempts));
  config.taskRetryDelayMs = Math.max(0, envNumber('AGENT_TASK_RETRY_DELAY_MS', config.taskRetryDelayMs));
  config.taskHeartbeatMs = Math.max(1000, envNumber('AGENT_TASK_HEARTBEAT_MS', config.taskHeartbeatMs));
  config.watchdogIntervalMs = Math.max(1000, envNumber('AGENT_WATCHDOG_INTERVAL_MS', config.watchdogIntervalMs));
  config.watchdogStallMs = Math.max(5000, envNumber('AGENT_WATCHDOG_STALL_MS', config.watchdogStallMs));
  config.autoApproveWorkspaceWrites = envBool('AGENT_AUTO_APPROVE_WRITES', config.autoApproveWorkspaceWrites);
  config.autoApproveCommands = envBool('AGENT_AUTO_APPROVE_COMMANDS', config.autoApproveCommands);
  config.sandboxMode = process.env.AGENT_SANDBOX_MODE || config.sandboxMode || 'auto';
  config.sandboxMemoryMb = envNumber('AGENT_SANDBOX_MEMORY_MB', config.sandboxMemoryMb);
  config.sandboxAllowChildren = envBool('AGENT_SANDBOX_ALLOW_CHILDREN', config.sandboxAllowChildren !== false);
  config.allowProcessFallback = envBool('AGENT_ALLOW_PROCESS_FALLBACK', config.allowProcessFallback !== false);
  config.provider = {
    ...config.provider,
    baseUrl: process.env.OPENAI_BASE_URL || process.env.DEEPSEEK_BASE_URL || config.provider?.baseUrl,
    model: process.env.OPENAI_MODEL || process.env.DEEPSEEK_MODEL || config.provider?.model,
    routerModel: process.env.AGENT_ROUTER_MODEL || config.provider?.routerModel || config.provider?.model,
    workerModel: process.env.AGENT_WORKER_MODEL || config.provider?.workerModel || config.provider?.model,
    embeddingModel: process.env.AGENT_EMBEDDING_MODEL || config.provider?.embeddingModel || '',
    apiKeyEnv: config.provider?.apiKeyEnv || 'DEEPSEEK_API_KEY',
  };

  const configuredWorkspace = process.env.AGENT_WORKSPACE || config.workspace || '.';
  config.workspace = path.resolve(root, configuredWorkspace);
  // The desktop shell previously forced AGENT_WORKSPACE to the home folder,
  // which silently overrode the folder selected from the UI. When no explicit
  // environment override exists, use the saved workspace. For a fresh desktop
  // install the shipped "." default maps to the user's home, not the read-only
  // install directory.
  if (!process.env.AGENT_WORKSPACE && configuredWorkspace === '.' && process.env.AGENT_SHELL === 'tauri') {
    config.workspace = os.homedir();
  }
  config.dataDir = path.resolve(process.env.AGENT_DATA_DIR || config.dataDir);
  config.logDir = path.resolve(process.env.AGENT_LOG_DIR || config.logDir);
  config.settingsFile = path.join(config.dataDir, 'config.local.json');
  config.allowedRoots = uniquePaths(
    (config.allowedRoots?.length ? config.allowedRoots : [config.workspace])
      .map((entry) => path.resolve(root, entry))
      .concat(config.workspace),
  );

  const secretsFile = path.join(config.dataDir, 'secrets.json');
  const secrets = readJson(secretsFile, {});
  const envKey = process.env[config.provider.apiKeyEnv];
  config.provider.apiKey = envKey || secrets.provider?.apiKey || secrets.apiKey || '';
  config.secretsFile = secretsFile;
  config.projectRoot = root;

  fs.mkdirSync(config.dataDir, { recursive: true });
  fs.mkdirSync(config.logDir, { recursive: true });
  return config;
}

export function publicConfig(config) {
  return {
    host: config.host,
    port: config.port,
    workspace: config.workspace,
    allowedRoots: config.allowedRoots,
    maxWorkers: config.maxWorkers,
    provider: {
      type: config.provider.type,
      baseUrl: config.provider.baseUrl,
      model: config.provider.model,
      routerModel: config.provider.routerModel,
      workerModel: config.provider.workerModel,
      embeddingModel: config.provider.embeddingModel || '',
      hasApiKey: Boolean(config.provider.apiKey),
    },
    autoApproveWorkspaceWrites: config.autoApproveWorkspaceWrites,
    autoApproveCommands: config.autoApproveCommands,
    supervisor: {
      maxAttempts: config.taskMaxAttempts,
      retryDelayMs: config.taskRetryDelayMs,
      heartbeatMs: config.taskHeartbeatMs,
      stallMs: config.watchdogStallMs,
      taskTimeoutMs: config.taskTimeoutMs,
    },
    sandboxMode: config.sandboxMode,
    sandboxMemoryMb: config.sandboxMemoryMb,
    watchers: { enabled: config.watchers?.enabled !== false, debounceMs: config.watchers?.debounceMs || 1200 },
    memory: {
      embeddingDim: config.memory?.embeddingDim || 384,
      topK: config.memory?.topK || 8,
      minScore: Number.isFinite(Number(config.memory?.minScore)) ? Number(config.memory.minScore) : 0.18,
      maxInlineMemories: config.memory?.maxInlineMemories || 12,
      indexMaxLines: config.memory?.indexMaxLines || 200,
      indexMaxBytes: config.memory?.indexMaxBytes || 25600,
      dreaming: {
        enabled: config.memory?.dreaming?.enabled !== false,
        intervalHours: config.memory?.dreaming?.intervalHours || 6,
        startupDelayMs: config.memory?.dreaming?.startupDelayMs || 60000,
        batchSize: config.memory?.dreaming?.batchSize || 24,
        minMemories: config.memory?.dreaming?.minMemories || 8,
        staleDays: config.memory?.dreaming?.staleDays || 30,
        dormantDays: config.memory?.dreaming?.dormantDays || 90,
        decayPerMonth: config.memory?.dreaming?.decayPerMonth ?? 0.08,
      },
    },
    mas: {
      enabled: config.mas?.enabled !== false,
      maxConcurrentRuns: config.mas?.maxConcurrentRuns || 2,
      maxSourcesPerScout: config.mas?.maxSourcesPerScout || 4,
      reportDir: config.mas?.reportDir || '多智能体报告',
    },
  };
}

export function updateLocalSettings(config, patch) {
  const safePatch = {};
  if (typeof patch.workspace === 'string') {
    const workspace = resolveTaskWorkspace(patch.workspace, config.projectRoot || projectRoot);
    safePatch.workspace = workspace;
    // A folder chosen by the user becomes an explicit Worker root. Keep prior
    // roots so a task already running in another folder does not lose access
    // halfway through when the user switches folders.
    safePatch.allowedRoots = uniquePaths([...(config.allowedRoots || []), workspace]);
  }
  if (typeof patch.baseUrl === 'string' && patch.baseUrl.trim()) {
    safePatch.baseUrl = patch.baseUrl.trim().replace(/\/+$/, '');
  }
  if (typeof patch.model === 'string' && patch.model.trim()) safePatch.model = patch.model.trim();
  if (typeof patch.routerModel === 'string' && patch.routerModel.trim()) safePatch.routerModel = patch.routerModel.trim();
  if (typeof patch.workerModel === 'string' && patch.workerModel.trim()) safePatch.workerModel = patch.workerModel.trim();
  if (typeof patch.autoApproveWorkspaceWrites === 'boolean') safePatch.autoApproveWorkspaceWrites = patch.autoApproveWorkspaceWrites;
  if (typeof patch.autoApproveCommands === 'boolean') safePatch.autoApproveCommands = patch.autoApproveCommands;
  if (typeof patch.sandboxMode === 'string' && ['auto', 'job', 'appcontainer', 'off', 'none', 'process'].includes(patch.sandboxMode)) safePatch.sandboxMode = patch.sandboxMode;
  if (typeof patch.embeddingModel === 'string') {
    safePatch.embeddingModel = patch.embeddingModel.trim();
    config.provider.embeddingModel = safePatch.embeddingModel;
  }
  if (patch.memory && typeof patch.memory === 'object') {
    const allowed = ['topK', 'minScore', 'maxInlineMemories', 'embeddingDim', 'indexMaxLines', 'indexMaxBytes'];
    const memoryPatch = {};
    for (const key of allowed) {
      if (typeof patch.memory[key] === 'number' && Number.isFinite(patch.memory[key])) memoryPatch[key] = patch.memory[key];
    }
    if (patch.memory.dreaming && typeof patch.memory.dreaming === 'object') {
      const dreaming = {};
      for (const key of ['intervalHours', 'startupDelayMs', 'batchSize', 'minMemories', 'staleDays', 'dormantDays', 'decayPerMonth']) {
        if (typeof patch.memory.dreaming[key] === 'number' && Number.isFinite(patch.memory.dreaming[key])) dreaming[key] = patch.memory.dreaming[key];
      }
      if (typeof patch.memory.dreaming.enabled === 'boolean') dreaming.enabled = patch.memory.dreaming.enabled;
      if (Object.keys(dreaming).length) memoryPatch.dreaming = dreaming;
    }
    if (Object.keys(memoryPatch).length) safePatch.memory = memoryPatch;
  }

  if (Object.keys(safePatch).length) {
    const file = config.settingsFile || path.join(config.dataDir, 'config.local.json');
    const current = readJson(file, {});
    const providerPatch = {};
    const rootPatch = {};
    for (const [key, value] of Object.entries(safePatch)) {
      if (['baseUrl', 'model', 'routerModel', 'workerModel', 'embeddingModel'].includes(key)) providerPatch[key] = value;
      else rootPatch[key] = value;
    }
    fs.writeFileSync(file, JSON.stringify(deepMerge(current, { ...rootPatch, provider: providerPatch }), null, 2), 'utf8');
    if (rootPatch.memory) rootPatch.memory = deepMerge(config.memory || {}, rootPatch.memory);
    if (!rootPatch.memory && current.memory) rootPatch.memory = current.memory;
    Object.assign(config, rootPatch);
    Object.assign(config.provider, providerPatch);
    if (providerPatch.routerModel && !providerPatch.model) config.provider.model = providerPatch.routerModel;
  }

  if (typeof patch.apiKey === 'string' && patch.apiKey.trim()) {
    const secrets = readJson(config.secretsFile, {});
    secrets.provider = { ...(secrets.provider || {}), apiKey: patch.apiKey.trim() };
    fs.writeFileSync(config.secretsFile, JSON.stringify(secrets, null, 2), { encoding: 'utf8', mode: 0o600 });
    config.provider.apiKey = patch.apiKey.trim();
  }
  return publicConfig(config);
}

export { projectRoot };





