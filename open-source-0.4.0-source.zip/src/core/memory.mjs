import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';

const VALID_SCOPES = new Set(['session', 'project', 'global']);
const VALID_STATUSES = new Set(['active', 'dormant', 'archived', 'superseded']);
const VALID_KINDS = new Set(['fact', 'decision', 'preference', 'task_result', 'failure', 'note', 'skill']);

const clamp = (value, min = 0, max = 1) => Math.max(min, Math.min(max, Number(value) || 0));
const nowMs = () => Date.now();
const fingerprintOf = (content) => createHash('sha256').update(normalizeText(content)).digest('hex');

function normalizeText(value) {
  return String(value || '').toLowerCase().replace(/\s+/g, ' ').trim();
}

function ageDays(value) {
  const time = Date.parse(value || '');
  return Number.isFinite(time) ? Math.max(0, (nowMs() - time) / 86400000) : 999;
}

function recencyScore(value, halfLifeDays = 30) {
  return 1 / (1 + ageDays(value) / Math.max(1, halfLifeDays));
}

function keywordScore(query, text) {
  const q = normalizeText(query);
  const haystack = normalizeText(text);
  if (!q || !haystack) return 0;
  const tokens = new Set();
  const words = q.match(/[a-z0-9_]{2,}|[\u4e00-\u9fff]{2,}/g) || [];
  for (const word of words) {
    if (/^[\u4e00-\u9fff]+$/.test(word)) {
      for (let index = 0; index < word.length - 1; index += 1) tokens.add(word.slice(index, index + 2));
    } else tokens.add(word);
  }
  for (let index = 0; index < q.length - 1; index += 1) {
    const pair = q.slice(index, index + 2);
    if (/^[\u4e00-\u9fff]{2}$/.test(pair)) tokens.add(pair);
  }
  if (!tokens.size) return 0;
  let hits = 0;
  for (const token of tokens) if (haystack.includes(token)) hits += 1;
  return clamp(hits / tokens.size);
}

function sameIdea(a, b) {
  const left = normalizeText(a);
  const right = normalizeText(b);
  if (!left || !right) return false;
  if (left === right) return true;
  if (left.length > 80 && right.length > 80 && (left.includes(right) || right.includes(left))) return true;
  const leftWords = new Set(left.match(/[a-z0-9_]{2,}|[\u4e00-\u9fff]{2,}/g) || []);
  const rightWords = new Set(right.match(/[a-z0-9_]{2,}|[\u4e00-\u9fff]{2,}/g) || []);
  if (!leftWords.size || !rightWords.size) return false;
  let overlap = 0;
  for (const word of leftWords) if (rightWords.has(word)) overlap += 1;
  return overlap / Math.min(leftWords.size, rightWords.size) >= 0.86;
}

function slugify(value) {
  const text = String(value || '').trim().toLowerCase()
    .replace(/[^\w\u4e00-\u9fff]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48);
  return text || `page-${createHash('sha1').update(String(value || 'page')).digest('hex').slice(0, 8)}`;
}

function safeWorkspaceKey(workspace) {
  const absolute = path.resolve(workspace || '.');
  const base = path.basename(absolute).replace(/[^\w\u4e00-\u9fff.-]+/g, '-').slice(0, 48) || 'workspace';
  const hash = createHash('sha1').update(absolute.toLowerCase()).digest('hex').slice(0, 12);
  return `${base}-${hash}`;
}

function trimUtf8(text, maxBytes) {
  if (Buffer.byteLength(text, 'utf8') <= maxBytes) return text;
  let value = text;
  while (value && Buffer.byteLength(value, 'utf8') > maxBytes) value = value.slice(0, -1);
  return value;
}

function fitLines(lines, maxLines, maxBytes) {
  const selected = [];
  let bytes = 0;
  for (const line of lines) {
    if (selected.length >= maxLines) break;
    const candidate = `${line}\n`;
    const next = Buffer.byteLength(candidate, 'utf8');
    if (bytes + next > maxBytes) {
      const remaining = maxBytes - bytes;
      if (remaining > 4) selected.push(trimUtf8(candidate, remaining));
      break;
    }
    selected.push(line);
    bytes += next;
  }
  return { content: selected.join('\n') + (selected.length ? '\n' : ''), lines: selected.length, bytes };
}

export class MemoryService {
  constructor(store, llm, logger, embeddings = null, options = {}) {
    this.store = store;
    this.llm = llm;
    this.logger = logger;
    this.embeddings = embeddings;
    this.config = options.config || {};
    this.events = options.events || null;
    this.dataDir = this.config.dataDir || options.dataDir || null;
    this.workspace = this.config.workspace || options.workspace || process.cwd();
    this.closed = false;
    this.backfillRunning = false;
    this.dreaming = false;
    this.dreamTimer = null;
    this.dreamIntervalTimer = null;
    this.nextDreamAt = null;
    this.indexSyncTimer = null;
    this.indexSyncWorkspace = null;
    this.indexLock = Promise.resolve();
    this.configure(this.config.memory || options.memory || {});
  }

  configure(memoryConfig = {}) {
    const cfg = memoryConfig || {};
    const number = (key, fallback) => Number.isFinite(Number(cfg[key])) ? Number(cfg[key]) : fallback;
    this.recallConfig = {
      topK: Math.max(1, Math.min(50, number('topK', 8))),
      minScore: clamp(number('minScore', 0.18), 0, 1),
      maxInline: Math.max(1, Math.min(40, number('maxInlineMemories', 12))),
      indexMaxLines: Math.max(20, Math.min(1000, number('indexMaxLines', 200))),
      indexMaxBytes: Math.max(4096, Math.min(1024 * 1024, number('indexMaxBytes', 25600))),
    };
    const d = cfg.dreaming || {};
    this.dreamingConfig = {
      enabled: d.enabled !== false,
      intervalHours: Math.max(0.1, Number(d.intervalHours) || 6),
      startupDelayMs: Math.max(5000, Number(d.startupDelayMs) || 60000),
      batchSize: Math.max(1, Math.min(200, Number(d.batchSize) || 24)),
      minMemories: Math.max(1, Math.min(5000, Number(d.minMemories) || 8)),
      staleDays: Math.max(1, Number(d.staleDays) || 30),
      dormantDays: Math.max(1, Number(d.dormantDays) || 90),
      decayPerMonth: clamp(Number(d.decayPerMonth) || 0.08, 0, 0.5),
    };
  }

  setWorkspace(workspace) {
    if (workspace) this.workspace = path.resolve(workspace);
    return this.workspace;
  }

  queueIndexSync(workspace = this.recallWorkspace) {
    if (this.closed || this.store.closed) return;
    this.indexSyncWorkspace = workspace;
    if (this.indexSyncTimer) clearTimeout(this.indexSyncTimer);
    this.indexSyncTimer = setTimeout(() => {
      this.indexSyncTimer = null;
      const target = this.indexSyncWorkspace;
      this.indexSyncWorkspace = null;
      if (this.closed || this.store.closed) return;
      this.syncIndex(target).catch((error) => {
        if (!this.closed && !this.store.closed) this.logger?.warn('记忆索引同步失败', error.message);
      });
    }, 120);
    this.indexSyncTimer.unref?.();
  }

  dispose() {
    this.closed = true;
    this.stopDreaming();
    if (this.indexSyncTimer) clearTimeout(this.indexSyncTimer);
    this.indexSyncTimer = null;
    this.indexSyncWorkspace = null;
  }

  get recallWorkspace() {
    return this.workspace || null;
  }

  contextFor(sessionId, { workspace = this.recallWorkspace } = {}) {
    const memories = this.store.listMemoryRecords({
      sessionId, workspace, status: 'active', limit: 24,
    }).map((memory) => ({
      id: memory.id, kind: memory.kind, content: memory.content, importance: memory.importance,
      confidence: memory.confidence, scope: memory.scope, pinned: memory.pinned,
    }));
    return {
      recentMessages: this.store.recentMessages(sessionId, 14).map((message) => ({ role: message.role, content: message.content })),
      memories,
      openTasks: this.store.listTasks({ sessionId, limit: 30 })
        .filter((task) => ['queued', 'running', 'waiting_approval'].includes(task.status))
        .map((task) => ({ id: task.id, title: task.title, status: task.status, progress: task.progress })),
    };
  }

  captureTranscript({ sessionId, taskId = null, source = 'worker', content, metadata = {}, workspace = this.recallWorkspace }) {
    try {
      return this.store.addTranscript({ sessionId, taskId, source, content, metadata, workspace });
    } catch (error) {
      this.logger?.warn(`原始流水写入失败: ${error.message}`);
      return null;
    }
  }

  async remember({
    sessionId, kind = 'fact', content, importance = 2, scope = 'project',
    workspace = this.recallWorkspace, topic = null, sourceType = 'manual', source = {},
    confidence = 0.66, pinned = false, fingerprint = null, supersedes = [],
    validUntil = null, dedupe = true,
  } = {}) {
    const text = String(content || '').trim();
    if (!sessionId) throw new Error('长期记忆需要 sessionId');
    if (!text) throw new Error('记忆内容不能为空');
    const normalizedScope = VALID_SCOPES.has(scope) ? scope : 'session';
    const normalizedKind = VALID_KINDS.has(kind) ? kind : 'fact';
    const normalizedWorkspace = workspace ? path.resolve(workspace) : null;
    const fp = fingerprintOf(text);
    if (dedupe) {
      const existing = this.store.findMemoryByFingerprint(fp, {
        workspace: normalizedWorkspace,
        sessionId: normalizedScope === 'session' ? sessionId : null,
        scope: normalizedScope,
      });
      if (existing && (normalizedScope === 'session' ? existing.session_id === sessionId : true)) {
        const updated = this.store.updateMemory(existing.id, {
          status: 'active',
          confidence: Math.max(Number(existing.confidence) || 0, confidence),
          importance: Math.max(Number(existing.importance) || 1, Number(importance) || 1),
          sourceType,
          source: { ...(existing.source || {}), ...(source || {}), dedupedAt: new Date().toISOString() },
          fingerprint: fp,
        });
        return updated || existing;
      }
    }
    const memory = this.store.addMemory({
      sessionId, kind: normalizedKind, content: text.slice(0, 12000), importance: Math.max(1, Math.min(5, Number(importance) || 2)),
      scope: normalizedScope, workspace: normalizedWorkspace, topic: topic ? String(topic).slice(0, 120) : null,
      status: 'active', confidence: clamp(confidence, 0.01, 1), pinned: Boolean(pinned),
      sourceType, source, fingerprint: fingerprint || fp, supersedes,
      validUntil,
    });
    await this.indexMemory(memory);
    this.queueIndexSync(normalizedWorkspace);
    return memory;
  }

  async rememberMany({ sessionId, items = [], ...defaults } = {}) {
    const results = [];
    for (const item of items) {
      if (!item?.content) continue;
      results.push(await this.remember({ ...defaults, ...item, sessionId: item.sessionId || sessionId }));
    }
    return results;
  }

  async updateMemory(memoryId, patch = {}) {
    const existing = this.store.getMemory(memoryId);
    if (!existing) return null;
    const nextPatch = { ...patch };
    if (patch.scope && !VALID_SCOPES.has(patch.scope)) nextPatch.scope = existing.scope;
    if (patch.status && !VALID_STATUSES.has(patch.status)) nextPatch.status = existing.status;
    if (patch.kind && !VALID_KINDS.has(patch.kind)) nextPatch.kind = existing.kind;
    if (typeof patch.content === 'string' && patch.content.trim()) {
      nextPatch.content = patch.content.trim().slice(0, 12000);
      nextPatch.fingerprint = fingerprintOf(nextPatch.content);
    }
    if (patch.workspace) nextPatch.workspace = path.resolve(patch.workspace);
    if (patch.confidence != null) nextPatch.confidence = clamp(patch.confidence);
    if (patch.importance != null) nextPatch.importance = Math.max(1, Math.min(5, Number(patch.importance) || 1));
    const updated = this.store.updateMemory(memoryId, nextPatch);
    if (updated && (patch.content || patch.kind)) await this.indexMemory(updated);
    this.queueIndexSync(updated?.workspace || this.recallWorkspace);
    return updated;
  }

  archiveMemory(memoryId, reason = 'manual') {
    return this.store.updateMemory(memoryId, {
      status: 'archived',
      source: { reason, archivedAt: new Date().toISOString() },
    });
  }

  deleteMemory(memoryId) {
    const existing = this.store.getMemory(memoryId);
    const deleted = this.store.deleteMemory(memoryId);
    if (deleted) this.queueIndexSync(existing?.workspace || this.recallWorkspace);
    return deleted;
  }

  settleMemoryFeedback(memoryId, { helpful = true, amount = null } = {}) {
    const memory = this.store.getMemory(memoryId);
    if (!memory) return null;
    const delta = amount == null ? NaN : Number(amount);
    const change = Number.isFinite(delta) ? delta : (helpful ? 0.08 : -0.14);
    const confidence = clamp((Number(memory.confidence) || 0.5) + change, 0, 1);
    const updated = this.store.updateMemory(memoryId, {
      confidence,
      status: confidence <= 0.2 ? 'dormant' : 'active',
      source: { ...(memory.source || {}), feedback: helpful ? 'helpful' : 'incorrect', feedbackAt: new Date().toISOString() },
    });
    this.queueIndexSync(updated?.workspace || this.recallWorkspace);
    return updated;
  }

  async recall(sessionId, query, { topK, minScore, scope = null, workspace = this.recallWorkspace } = {}) {
    const explicitTopK = Number.isFinite(Number(topK)) && Number(topK) > 0;
    const limit = Math.max(1, Math.min(50, Number(topK) || this.recallConfig.topK));
    const resultCap = explicitTopK ? limit : Math.min(limit, this.recallConfig.maxInline);
    const floor = Number.isFinite(Number(minScore)) ? Number(minScore) : this.recallConfig.minScore;
    const candidates = this.store.listMemoryRecords({
      sessionId, workspace, status: 'active', scope: scope || 'all', limit: 5000,
    }).filter((memory) => !memory.valid_until || Date.parse(memory.valid_until) > nowMs());

    if (!candidates.length) return [];
    const queryText = String(query || '').trim();
    const ids = candidates.map((memory) => memory.id);
    const best = new Map();
    for (const memory of candidates) best.set(memory.id, { similarity: 0, chunk: null });
    let queryVector = null;
    if (queryText && this.embeddings) {
      try {
        queryVector = await this.embeddings.embed(queryText);
        const chunks = this.store.listMemoryChunksForMemories(ids);
        for (const chunk of chunks) {
          if (!chunk.vector?.length || chunk.vector.length !== queryVector.length) continue;
          const similarity = this.embeddings.similarity(queryVector, chunk.vector);
          const current = best.get(chunk.memory_id);
          if (current && similarity > current.similarity) best.set(chunk.memory_id, { similarity, chunk: chunk.text });
        }
        const vectors = this.store.listMemoryVectorsForMemories(ids);
        for (const entry of vectors) {
          if (!entry.vector?.length || entry.vector.length !== queryVector.length) continue;
          const similarity = this.embeddings.similarity(queryVector, entry.vector);
          const current = best.get(entry.memory_id);
          if (current && similarity > current.similarity) best.set(entry.memory_id, { similarity, chunk: current.chunk });
        }
      } catch (error) {
        this.logger?.warn(`语义召回失败，继续使用关键词与置信度评分: ${error.message}`);
        queryVector = null;
      }
    }

    const now = nowMs();
    const scored = candidates.map((memory) => {
      const match = best.get(memory.id) || { similarity: 0, chunk: null };
      const similarity = clamp(match.similarity, 0, 1);
      const keyword = keywordScore(queryText, `${memory.topic || ''} ${memory.content || ''}`);
      const confidence = clamp(memory.confidence, 0, 1);
      const importance = clamp((Number(memory.importance) || 1) / 5);
      const age = Math.max(0, now - Date.parse(memory.last_accessed_at || memory.updated_at || memory.created_at || '')) / 86400000;
      const freshness = 1 / (1 + age / 30);
      const access = clamp(Math.log10(1 + (Number(memory.access_count) || 0)) / 2);
      const pinned = memory.pinned ? 1 : 0;
      const score = similarity * 0.5 + keyword * 0.15 + confidence * 0.14
        + importance * 0.09 + freshness * 0.07 + access * 0.05 + pinned * 0.04;
      return { ...memory, similarity, keywordScore: keyword, score, matchedChunk: match.chunk, pinned: Boolean(memory.pinned) };
    }).sort((a, b) => b.score - a.score || b.importance - a.importance);

    const keywordFloor = Math.max(0.08, Math.min(0.35, floor));
    let selected = scored.filter((item) => !queryText || item.similarity >= floor || item.keywordScore >= keywordFloor);
    if (!selected.length) selected = scored;
    selected = selected.slice(0, resultCap);
    const protectedMemories = scored.filter((item) => item.pinned || item.importance >= 4).slice(0, 2);
    for (const item of protectedMemories) {
      if (!selected.some((candidate) => candidate.id === item.id)) selected.push(item);
    }
    selected = selected.slice(0, resultCap);

    for (const item of selected) {
      try {
        this.store.logMemoryAccess({
          memoryId: item.id, sessionId, taskId: item.source_task_id || null,
          query: queryText, score: item.score,
        });
      } catch { /* access logging must never break recall */ }
    }
    return selected;
  }

  async indexMemory(memory) {
    if (!this.embeddings || !memory?.id || !memory.content) return null;
    try {
      const vector = await this.embeddings.embed(memory.content);
      this.store.upsertMemoryVector({
        memoryId: memory.id, sessionId: memory.session_id, vector, model: this.embeddings.model,
      });
      const texts = chunkText(memory.content);
      const chunks = [];
      for (const text of texts) chunks.push({ text, vector: await this.embeddings.embed(text) });
      this.store.replaceMemoryChunks({
        memoryId: memory.id, sessionId: memory.session_id, chunks, model: this.embeddings.model,
      });
      return vector;
    } catch (error) {
      this.logger?.warn(`记忆向量化失败: ${error.message}`);
      return null;
    }
  }

  async backfill(sessionId = null, { workspace = this.recallWorkspace } = {}) {
    if (!this.embeddings || this.backfillRunning) return 0;
    this.backfillRunning = true;
    let count = 0;
    try {
      const records = this.store.listMemoryRecords({
        sessionId, workspace, status: 'all', limit: 10000,
      });
      const ids = [...new Set(records.map((memory) => memory.id))];
      const indexed = new Set(this.store.listMemoryVectorsForMemories(ids).map((entry) => entry.memory_id));
      const chunked = new Set(this.store.listMemoryChunksForMemories(ids).map((entry) => entry.memory_id));
      for (const memory of records) {
        if (indexed.has(memory.id) && chunked.has(memory.id)) continue;
        await this.indexMemory(memory);
        count += 1;
      }
    } catch (error) {
      this.logger?.warn(`记忆向量回填失败: ${error.message}`);
    } finally {
      this.backfillRunning = false;
    }
    return count;
  }

  async recordTaskResult(task) {
    if (!task?.sessionId) return null;
    const fallback = `${task.title}: ${String(task.result || task.error || '').replace(/\s+/g, ' ').slice(0, 1200)}`;
    let content = fallback;
    let kind = task.status === 'completed' ? 'task_result' : 'failure';
    let importance = task.status === 'completed' ? 2 : 3;
    let topic = task.title || null;
    if (this.llm?.available && task.result) {
      try {
        const response = await this.llm.chatJson([
          { role: 'system', content: `你是长期记忆整理器。只提取值得跨会话保留的事实、决定、路径、偏好和未完成事项；不要复述过程。返回 JSON: {"memory":"...", "kind":"fact|decision|preference|task_result|failure","importance":1,"topic":"..."}` },
          { role: 'user', content: JSON.stringify({ title: task.title, prompt: task.prompt, result: String(task.result).slice(0, 12000), status: task.status }) },
        ], { model: this.llm.config?.routerModel, temperature: 0 });
        if (response.json?.memory) {
          content = String(response.json.memory).slice(0, 4000);
          kind = VALID_KINDS.has(response.json.kind) ? response.json.kind : kind;
          importance = Math.max(1, Math.min(5, Number(response.json.importance) || importance));
          topic = response.json.topic ? String(response.json.topic).slice(0, 120) : topic;
        }
      } catch (error) {
        this.logger?.warn('任务记忆整理失败，使用回退摘要', error.message);
      }
    }
    if (!String(content || '').trim()) return null;
    return await this.remember({
      sessionId: task.sessionId, kind, content, importance, topic,
      scope: 'project', workspace: task.workspace || this.recallWorkspace,
      sourceType: 'worker', source: { taskId: task.id, status: task.status },
      confidence: task.status === 'completed' ? 0.78 : 0.58,
    });
  }

  stats(sessionId) {
    const records = this.store.listMemoryRecords({ sessionId, workspace: this.recallWorkspace, status: 'all', limit: 10000 });
    const ids = records.map((memory) => memory.id);
    const indexed = this.store.listMemoryVectorsForMemories(ids).length;
    const chunks = this.store.listMemoryChunksForMemories(ids).length;
    return {
      total: records.length,
      active: records.filter((memory) => memory.status === 'active').length,
      dormant: records.filter((memory) => memory.status === 'dormant').length,
      archived: records.filter((memory) => ['archived', 'superseded'].includes(memory.status)).length,
      indexed,
      chunks,
      pending: Math.max(0, records.length - indexed),
      model: this.embeddings?.model || null,
    };
  }

  memoryRoot(workspace = this.recallWorkspace) {
    if (!this.dataDir) return null;
    return path.join(path.resolve(this.dataDir), 'memory', 'workspaces', safeWorkspaceKey(workspace));
  }

  async buildPromptIndex(workspace = this.recallWorkspace, options = {}) {
    return await this.#withIndexLock(async () => this.#buildPromptIndexUnlocked(workspace, options));
  }

  async #withIndexLock(task) {
    const previous = this.indexLock;
    let release;
    this.indexLock = new Promise((resolve) => { release = resolve; });
    await previous.catch(() => {});
    try { return await task(); }
    finally { release(); }
  }

  async #buildPromptIndexUnlocked(workspace = this.recallWorkspace, { write = true } = {}) {
    const records = this.store.listMemoryRecords({ workspace, status: 'active', limit: 5000 });
    const pages = workspace ? this.store.listMemoryPages(workspace, { status: 'active', limit: 300 }) : [];
    const lines = [
      '# Long-term Memory Index',
      `workspace: ${workspace || '未绑定'}`,
      'policy: 只注入轻量索引；细节按需通过 memory_search / memory_read_page 检索。',
      '',
      '## Memory Notes',
    ];
    for (const memory of records) {
      const content = String(memory.content || '').replace(/\s+/g, ' ').trim();
      const prefix = memory.pinned ? '[pinned] ' : '';
      lines.push(`- ${prefix}[${memory.kind}/${memory.scope} c=${Number(memory.confidence || 0).toFixed(2)}] ${content.slice(0, 220)}`);
    }
    if (!records.length) lines.push('- 暂无记忆笔记');
    if (pages.length) {
      lines.push('', '## Wiki');
      for (const page of pages) lines.push(`- [${page.slug}] ${String(page.title || '').slice(0, 100)} — ${String(page.summary || '').replace(/\s+/g, ' ').slice(0, 160)}`);
    }
    const fitted = fitLines(lines, this.recallConfig.indexMaxLines, this.recallConfig.indexMaxBytes);
    const result = {
      workspace, path: this.memoryRoot(workspace) ? path.join(this.memoryRoot(workspace), 'MEMORY.md') : null,
      content: fitted.content, lineCount: fitted.lines, bytes: Buffer.byteLength(fitted.content, 'utf8'),
      memoryCount: records.length, pageCount: pages.length,
      truncated: fitted.lines < lines.length, maxLines: this.recallConfig.indexMaxLines, maxBytes: this.recallConfig.indexMaxBytes,
    };
    if (write && result.path) {
      await fs.mkdir(path.dirname(result.path), { recursive: true });
      await fs.writeFile(result.path, result.content, 'utf8');
    }
    return result;
  }

  async syncIndex(workspace = this.recallWorkspace) {
    const index = await this.buildPromptIndex(workspace, { write: true });
    const root = this.memoryRoot(workspace);
    if (!root) return index;
    const wikiDir = path.join(root, 'wiki');
    await fs.mkdir(wikiDir, { recursive: true });
    const pages = workspace ? this.store.listMemoryPages(workspace, { status: 'active', limit: 300, withContent: true }) : [];
    for (const page of pages) {
      const file = path.join(wikiDir, `${page.slug}.md`);
      await fs.writeFile(file, `${page.content_md || ''}\n`, 'utf8');
      if (page.file_path !== file) this.store.upsertMemoryPage({
        workspace, slug: page.slug, title: page.title, summary: page.summary,
        contentMd: page.content_md || '', links: page.links || [], sourceMemoryIds: page.sourceMemoryIds || [],
        confidence: page.confidence, status: page.status, filePath: file,
      });
    }
    return { ...index, wikiDir };
  }

  async listPages(workspace = this.recallWorkspace, options = {}) {
    return this.store.listMemoryPages(workspace, { status: 'all', limit: 300, ...options });
  }

  async readPage(idOrSlug, workspace = this.recallWorkspace) {
    if (!idOrSlug) return null;
    return this.store.getMemoryPage(idOrSlug) || this.store.getMemoryPageBySlug(workspace, idOrSlug);
  }

  listRecords({ sessionId = null, workspace = this.recallWorkspace, status = 'all', query = '', limit = 200 } = {}) {
    return this.store.listMemoryRecords({ sessionId, workspace, status, query, limit });
  }

  listTranscripts({ sessionId = null, taskId = null, workspace = null, query = '', limit = 200 } = {}) {
    return this.store.listTranscripts({ sessionId, taskId, workspace, query, limit });
  }

  async workerSearch(query, { sessionId = null, workspace = this.recallWorkspace, topK = 6 } = {}) {
    const records = await this.recall(sessionId, query, { topK, workspace });
    return records.map((memory) => ({
      id: memory.id, kind: memory.kind, scope: memory.scope, content: memory.content,
      importance: memory.importance, confidence: memory.confidence,
      score: Number(memory.score || 0), matchedChunk: memory.matchedChunk || null,
    }));
  }

  async overview(workspace = this.recallWorkspace, sessionId = null) {
    const records = this.listRecords({ sessionId, workspace, status: 'all', limit: 10000 });
    const pages = await this.listPages(workspace, { status: 'all', withContent: false });
    const transcripts = this.store.countTranscripts(workspace);
    const runs = this.store.listMemoryRuns({ workspace, limit: 8 });
    const index = await this.buildPromptIndex(workspace, { write: false });
    return {
      workspace,
      counts: {
        total: records.length,
        active: records.filter((memory) => memory.status === 'active').length,
        dormant: records.filter((memory) => memory.status === 'dormant').length,
        archived: records.filter((memory) => ['archived', 'superseded'].includes(memory.status)).length,
        pinned: records.filter((memory) => memory.pinned).length,
        pages: pages.length,
        transcripts,
      },
      scopes: {
        session: records.filter((memory) => memory.scope === 'session').length,
        project: records.filter((memory) => memory.scope === 'project').length,
        global: records.filter((memory) => memory.scope === 'global').length,
      },
      index: { ...index, content: undefined },
      dreaming: {
        enabled: this.dreamingConfig.enabled,
        running: this.dreaming,
        lastRuns: runs,
        nextRunAt: this.dreamingConfig.enabled ? this.#nextDreamAt() : null,
      },
      transcripts: transcripts,
    };
  }

  async summaryForPrompt(sessionId, query = '') {
    const context = this.contextFor(sessionId);
    const index = await this.buildPromptIndex(this.recallWorkspace, { write: false });
    const recalled = await this.recall(sessionId, query || context.recentMessages.at(-1)?.content || '');
    const memoryText = recalled.length
      ? recalled.map((memory) => `- [${memory.kind}/${memory.scope} c=${Number(memory.confidence || 0).toFixed(2)}] ${String(memory.content).slice(0, 800)}`).join('\n')
      : '- 暂无相关长期记忆';
    const taskText = context.openTasks.length
      ? context.openTasks.map((task) => `- ${task.id} [${task.status}] ${task.title}${task.progress ? ` (${task.progress})` : ''}`).join('\n')
      : '- 无未完成任务';
    return `轻量长期记忆索引:\n${index.content}\n\n本次相关召回:\n${memoryText}\n\n未完成任务:\n${taskText}`;
  }

  #nextDreamAt() {
    if (!this.dreamingConfig.enabled) return null;
    return this.nextDreamAt || new Date(nowMs() + this.dreamingConfig.intervalHours * 3600000).toISOString();
  }

  startDream(workspace = this.recallWorkspace, trigger = 'manual') {
    const run = this.store.createMemoryRun({ workspace: workspace || this.recallWorkspace || 'unscoped', trigger });
    if (this.dreaming) return run;
    this.dream({ runId: run.id, workspace, trigger }).catch((error) => {
      this.logger?.warn('Dreaming 后台运行失败', error.message);
    });
    return run;
  }

  async dream({ runId = null, workspace = this.recallWorkspace, trigger = 'manual' } = {}) {
    let run = runId ? this.store.getMemoryRun(runId) : null;
    if (!run) run = this.store.createMemoryRun({ workspace: workspace || this.recallWorkspace || 'unscoped', trigger });
    if (this.dreaming) return run;
    this.dreaming = true;
    const startedAt = new Date().toISOString();
    this.store.updateMemoryRun(run.id, { status: 'running', startedAt });
    this.events?.emit({ type: 'memory.dream.started', runId: run.id, workspace, trigger });
    const stats = { examined: 0, updated: 0, merged: 0, decayed: 0, archived: 0, pages: 0, operations: 0 };
    try {
      const records = this.store.listMemoryRecords({ workspace, status: 'all', limit: 1000 });
      stats.examined = records.length;
      const transcripts = this.store.listTranscripts({ workspace, query: '', limit: this.dreamingConfig.batchSize });
      let operations = [];
      let generatedPages = [];
      if (this.llm?.available && records.length) {
        try {
          const response = await this.llm.chatJson([
            { role: 'system', content: `你是长期记忆的离线整理器 Dreaming。目标：对照原始流水纠错、去重、合并、修补知识拓扑，并让长期记忆更简洁。只能返回 JSON：{"operations":[{"type":"keep|update|archive|merge","memoryId":"可选","ids":["可选"],"content":"可选","kind":"可选","importance":1,"confidence":0.8,"topic":"可选","reason":"可选"}],"pages":[{"slug":"...","title":"...","summary":"...","contentMd":"...","memoryIds":["..."]}]}。不要删除原始流水；不要编造事实；没有依据时只做衰减和去重。` },
            { role: 'user', content: JSON.stringify({
              workspace,
              memories: records.slice(0, this.dreamingConfig.batchSize).map((memory) => ({ id: memory.id, kind: memory.kind, content: memory.content, importance: memory.importance, confidence: memory.confidence, status: memory.status, updated_at: memory.updated_at })),
              transcripts: transcripts.map((item) => ({ source: item.source, taskId: item.task_id, content: String(item.content || '').slice(0, 1800), created_at: item.created_at })),
            }).slice(0, 30000) },
          ], { model: this.llm.config?.routerModel, temperature: 0 });
          operations = Array.isArray(response.json?.operations) ? response.json.operations : [];
          generatedPages = Array.isArray(response.json?.pages) ? response.json.pages : [];
          stats.operations = operations.length;
          await this.#applyDreamOperations(records, operations, stats);
        } catch (error) {
          this.logger?.warn('Dreaming LLM 整理失败，执行确定性修复', error.message);
        }
      }
      const refreshed = this.store.listMemoryRecords({ workspace, status: 'all', limit: 5000 });
      await this.#deterministicDream(refreshed, stats);
      const deduped = this.store.listMemoryRecords({ workspace, status: 'all', limit: 5000 });
      await this.#decayMemories(deduped, stats);
      const finalRecords = this.store.listMemoryRecords({ workspace, status: 'all', limit: 5000 });
      await this.#writeDreamPages(workspace, generatedPages, finalRecords, stats);
      const index = await this.syncIndex(workspace);
      const finalStats = { ...stats, indexLines: index.lineCount, indexBytes: index.bytes };
      const finishedAt = new Date().toISOString();
      const completed = this.store.updateMemoryRun(run.id, { status: 'completed', stats: finalStats, finishedAt });
      this.events?.emit({ type: 'memory.dream.completed', runId: run.id, workspace, trigger, stats: finalStats });
      return completed;
    } catch (error) {
      const failed = this.store.updateMemoryRun(run.id, {
        status: 'failed', stats, error: error.message, finishedAt: new Date().toISOString(),
      });
      this.events?.emit({ type: 'memory.dream.failed', runId: run.id, workspace, trigger, error: error.message });
      throw error;
    } finally {
      this.dreaming = false;
    }
  }

  async #applyDreamOperations(records, operations, stats) {
    const byId = new Map(records.map((memory) => [memory.id, memory]));
    for (const operation of operations.slice(0, 200)) {
      const type = String(operation?.type || '').toLowerCase();
      if (type === 'keep') continue;
      if (type === 'archive') {
        const memory = byId.get(operation.memoryId) || records.find((item) => item.id === operation.memoryId);
        if (!memory || memory.pinned) continue;
        await this.updateMemory(memory.id, { status: 'archived', source: { ...(memory.source || {}), dreamReason: operation.reason || 'archive' } });
        stats.archived += 1;
        continue;
      }
      if (type === 'update') {
        const memory = byId.get(operation.memoryId);
        if (!memory) continue;
        const patch = {};
        if (operation.content) patch.content = String(operation.content).slice(0, 12000);
        if (operation.kind && VALID_KINDS.has(operation.kind)) patch.kind = operation.kind;
        if (operation.importance != null) patch.importance = operation.importance;
        if (operation.confidence != null) patch.confidence = operation.confidence;
        if (operation.topic) patch.topic = operation.topic;
        if (Object.keys(patch).length) {
          await this.updateMemory(memory.id, patch);
          stats.updated += 1;
        }
        continue;
      }
      if (type === 'merge') {
        const ids = [...new Set(operation.ids || [])];
        const members = ids.map((memoryId) => byId.get(memoryId)).filter(Boolean);
        if (members.length < 2) continue;
        const keep = members.slice().sort((a, b) => (Number(b.pinned) - Number(a.pinned)) || (Number(b.importance) - Number(a.importance)) || (Number(b.confidence) - Number(a.confidence)))[0];
        const mergedContent = operation.content
          ? String(operation.content).slice(0, 12000)
          : [...new Set(members.map((memory) => memory.content))].join('\n');
        await this.updateMemory(keep.id, {
          content: mergedContent, confidence: Math.max(...members.map((memory) => Number(memory.confidence) || 0)),
          importance: Math.max(...members.map((memory) => Number(memory.importance) || 1)),
          supersedes: [...new Set([...(keep.supersedes || []), ...members.filter((memory) => memory.id !== keep.id).map((memory) => memory.id)])],
          source: { ...(keep.source || {}), dreamMergedAt: new Date().toISOString() },
        });
        for (const memory of members) {
          if (memory.id === keep.id) continue;
          await this.updateMemory(memory.id, { status: 'superseded' });
          stats.merged += 1;
        }
        stats.updated += 1;
      }
    }
  }

  async #deterministicDream(records, stats) {
    const active = records.filter((memory) => memory.status === 'active' || memory.status === 'dormant');
    const seen = new Map();
    for (const memory of active.sort((a, b) => (Number(b.pinned) - Number(a.pinned)) || (Number(b.importance) - Number(a.importance)))) {
      const key = normalizeText(memory.content);
      const duplicate = [...seen.entries()].find(([candidate]) => sameIdea(candidate, key));
      if (duplicate) {
        const keep = duplicate[1];
        await this.updateMemory(keep.id, {
          confidence: Math.min(1, Math.max(Number(keep.confidence) || 0, Number(memory.confidence) || 0) + 0.04),
          supersedes: [...new Set([...(keep.supersedes || []), memory.id])],
          source: { ...(keep.source || {}), dreamDedupedAt: new Date().toISOString() },
        });
        await this.updateMemory(memory.id, { status: 'superseded' });
        stats.merged += 1;
        continue;
      }
      seen.set(key, memory);
    }
  }

  async #decayMemories(records, stats) {
    for (const memory of records.filter((item) => item.status === 'active' || item.status === 'dormant')) {
      if (memory.pinned) continue;
      const age = ageDays(memory.last_accessed_at || memory.created_at);
      const months = age / 30;
      const decay = Math.max(0, months * this.dreamingConfig.decayPerMonth);
      const confidence = clamp((Number(memory.confidence) || 0.6) - decay, 0, 1);
      if (confidence < (Number(memory.confidence) || 0.6) - 0.001) stats.decayed += 1;
      const status = !memory.pinned && age >= this.dreamingConfig.dormantDays ? 'dormant' : 'active';
      if (status !== memory.status || confidence !== Number(memory.confidence)) {
        await this.updateMemory(memory.id, { status, confidence });
        stats.updated += 1;
      }
    }
  }

  async #writeDreamPages(workspace, requestedPages, records, stats) {
    if (!workspace) return [];
    const active = records.filter((memory) => memory.status === 'active');
    const candidates = [];
    if (Array.isArray(requestedPages) && requestedPages.length) {
      for (const page of requestedPages.slice(0, 40)) {
        if (!page?.title || !page?.contentMd) continue;
        candidates.push({
          slug: slugify(page.slug || page.title), title: String(page.title).slice(0, 120),
          summary: String(page.summary || '').slice(0, 240), contentMd: String(page.contentMd).slice(0, 50000),
          memoryIds: Array.isArray(page.memoryIds) ? page.memoryIds : [],
        });
      }
    }
    if (!candidates.length) {
      const groups = new Map();
      for (const memory of active) {
        const key = memory.topic || memory.kind || 'general';
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(memory);
      }
      for (const [topic, group] of groups) {
        const title = String(topic).slice(0, 100);
        const contentMd = [`# ${title}`, '', ...group.slice(0, 80).map((memory) => `- ${memory.content}`)].join('\n');
        candidates.push({
          slug: slugify(topic), title, summary: group.slice(0, 3).map((memory) => memory.content).join('；').slice(0, 220),
          contentMd, memoryIds: group.map((memory) => memory.id),
        });
      }
    }
    if (!candidates.length) return [];
    const saved = [];
    for (const page of candidates) {
      const savedPage = this.store.upsertMemoryPage({
        workspace, slug: page.slug, title: page.title, summary: page.summary, contentMd: page.contentMd,
        links: [], sourceMemoryIds: page.memoryIds,
        confidence: active.length ? active.reduce((sum, memory) => sum + (Number(memory.confidence) || 0), 0) / active.length : 0.6,
        status: 'active',
      });
      saved.push(savedPage);
    }
    this.store.deleteMemoryPagesNotIn(workspace, saved.map((page) => page.slug));
    stats.pages = saved.length;
    return saved;
  }

  scheduleDreaming() {
    this.stopDreaming();
    if (!this.dreamingConfig.enabled) {
      this.nextDreamAt = null;
      return;
    }
    const intervalMs = this.dreamingConfig.intervalHours * 3600000;
    const run = () => {
      if (this.dreaming) return;
      const active = this.store.listMemoryRecords({ workspace: this.recallWorkspace, status: 'active', limit: this.dreamingConfig.minMemories });
      if (active.length < this.dreamingConfig.minMemories) return;
      this.startDream(this.recallWorkspace, 'scheduled');
    };
    this.nextDreamAt = new Date(Date.now() + this.dreamingConfig.startupDelayMs).toISOString();
    this.dreamTimer = setTimeout(() => {
      this.nextDreamAt = new Date(Date.now() + intervalMs).toISOString();
      run();
      this.dreamIntervalTimer = setInterval(run, intervalMs);
      this.dreamIntervalTimer.unref?.();
    }, this.dreamingConfig.startupDelayMs);
    this.dreamTimer.unref?.();
  }

  stopDreaming() {
    if (this.dreamTimer) clearTimeout(this.dreamTimer);
    if (this.dreamIntervalTimer) clearInterval(this.dreamIntervalTimer);
    this.dreamTimer = null;
    this.dreamIntervalTimer = null;
    this.nextDreamAt = null;
  }
}

export function chunkText(text, { maxChars = 240, minChars = 8 } = {}) {
  const value = String(text || '').replace(/\r\n/g, '\n').trim();
  if (!value) return [];
  const lines = value.split('\n').map((line) => line.trim()).filter(Boolean);
  const parts = [];
  for (const line of lines) {
    if (line.length <= maxChars) { parts.push(line); continue; }
    const sentences = line.split(/(?<=[。！？!?；;])\s*|(?<=\.)\s+/).map((sentence) => sentence.trim()).filter(Boolean);
    if (sentences.length <= 1) {
      for (let index = 0; index < line.length; index += maxChars) parts.push(line.slice(index, index + maxChars));
      continue;
    }
    let buffer = '';
    for (const sentence of sentences) {
      if (sentence.length > maxChars) {
        if (buffer) { parts.push(buffer); buffer = ''; }
        for (let index = 0; index < sentence.length; index += maxChars) parts.push(sentence.slice(index, index + maxChars));
        continue;
      }
      if ((buffer + sentence).length > maxChars && buffer) { parts.push(buffer); buffer = sentence; }
      else buffer += sentence;
    }
    if (buffer) parts.push(buffer);
  }
  const deduped = [];
  for (const part of parts) {
    const trimmed = part.trim();
    if (trimmed.length < minChars) continue;
    if (deduped.at(-1) === trimmed) continue;
    deduped.push(trimmed);
  }
  return deduped.length ? deduped : (value.length ? [value.slice(0, maxChars)] : []);
}
