import fs from 'node:fs';
import path from 'node:path';

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };

export function createLogger({ logDir, level = 'info', name = 'agent' } = {}) {
  if (logDir) fs.mkdirSync(logDir, { recursive: true });
  const file = logDir ? path.join(logDir, `${name}.log`) : null;
  const threshold = LEVELS[level] ?? LEVELS.info;

  function write(levelName, args) {
    if ((LEVELS[levelName] ?? 99) < threshold) return;
    const line = JSON.stringify({
      ts: new Date().toISOString(),
      level: levelName,
      scope: name,
      message: args.map((value) => value instanceof Error ? value.stack : value).join(' '),
    });
    if (file) fs.appendFileSync(file, `${line}\n`, 'utf8');
    const stream = levelName === 'error' ? process.stderr : process.stdout;
    if (process.env.NODE_ENV !== 'test') stream.write(`${line}\n`);
  }

  return {
    debug: (...args) => write('debug', args),
    info: (...args) => write('info', args),
    warn: (...args) => write('warn', args),
    error: (...args) => write('error', args),
    child(scope) {
      return createLogger({ logDir, level, name: `${name}.${scope}` });
    },
  };
}
