import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

// Resolves how a Worker process should be launched.
//
// Isolation tiers:
//   process            plain child_process.spawn  (portable fallback)
//   jobobject          WindowsSandboxHost.exe confines the whole tree in a Job
//                      Object; the tree is reclaimed when the host exits
//   appcontainer       WindowsSandboxHost.exe + AppContainer profile, so the
//                      Worker runs with a restricted token and packages ACLs
//
// The host executable is compiled from sandbox/windows/WindowsSandboxHost.cs
// by scripts/build-sandbox.ps1 and cached in native/.
export function resolveSandbox(config = {}, { logger } = {}) {
  const requested = String(config.sandboxMode || 'auto').toLowerCase();
  const always = requested === 'always';
  const disabled = requested === 'off' || requested === 'none' || requested === 'process';
  if (disabled) return { tier: 'process', host: null, reason: 'sandbox disabled by configuration' };

  if (process.platform !== 'win32') {
    return {
      tier: config.allowProcessFallback === false ? 'unavailable' : 'process',
      host: null,
      reason: `Job Object 仅支持 Windows，当前平台为 ${process.platform}`,
    };
  }

  const host = findHost(config.projectRoot);
  if (!host) {
    const reason = '未找到 native/WindowsSandboxHost.exe，请先运行 scripts/build-sandbox.ps1';
    logger?.warn(reason);
    return { tier: config.allowProcessFallback === false ? 'unavailable' : 'process', host: null, reason };
  }

  // AppContainer is opt-in only. It requires granting the package SID read
  // access to the Node runtime and the workspace, which is a heavyweight and
  // sometimes slow operation, so `auto` never selects it silently.
  const wantAppContainer = config.sandboxMode === 'appcontainer';

  const probe = probeHost(host, wantAppContainer ? 'appcontainer' : 'job');
  if (!probe.ok) {
    const reason = `沙箱宿主探测失败: ${probe.error}`;
    logger?.warn(reason);
    return { tier: config.allowProcessFallback === false ? 'unavailable' : 'process', host: null, reason };
  }

  if (wantAppContainer) {
    return { tier: 'appcontainer', host, always, mode: 'appcontainer', reason: null };
  }
  return { tier: 'jobobject', host, always, mode: 'job', reason: null };
}

export function findHost(projectRoot) {
  const candidates = [
    path.join(projectRoot, 'native', 'WindowsSandboxHost.exe'),
    path.join(projectRoot, 'resources', 'native', 'WindowsSandboxHost.exe'),
  ];
  for (const candidate of candidates) {
    try { if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate; } catch {}
  }
  return null;
}

export function probeHost(host, mode = 'job') {
  try {
    const result = spawnSync(host, ['--probe'], {
      windowsHide: true,
      timeout: 8000,
      encoding: 'utf8',
      env: { ...process.env, SANDBOX_MODE: mode },
    });
    if (result.status !== 0) return { ok: false, error: `退出码 ${result.status}` };
    const payload = JSON.parse(String(result.stdout || '').trim() || '{}');
    return { ok: Boolean(payload.ok), mode: payload.mode || mode, host: payload.host };
  } catch (error) {
    return { ok: false, error: error.message };
  }
}

export function buildSandboxCommand({ sandbox, execPath, runnerPath, tier }) {
  const command = execPath;
  const args = [runnerPath];

  if (sandbox.tier === 'process' || sandbox.tier === 'unavailable' || !sandbox.host) {
    return { command, args, sandboxed: false, tier: 'process', env: {} };
  }

  const useAppContainer = sandbox.mode === 'appcontainer';
  const env = {
    SANDBOX_MODE: useAppContainer ? 'appcontainer' : 'job',
    SANDBOX_ALLOW_CHILDREN: '1',
    SANDBOX_ALLOW_BREAKAWAY: '0',
  };
  return {
    command: sandbox.host,
    args: ['--', command, ...args],
    sandboxed: true,
    tier: useAppContainer ? 'appcontainer' : 'jobobject',
    env,
  };
}

export function provisionAppContainer({ host, readPaths = [], timeoutMs = 60000, recursive = false } = {}) {
  if (!host) return { ok: false, error: '没有可用的沙箱宿主' };
  const args = ['--prepare-appcontainer'];
  const target = readPaths[0];
  if (target) args.push(target, target, recursive ? 'recursive' : 'shallow');
  const result = spawnSync(host, args, { windowsHide: true, timeout: timeoutMs, killSignal: 'SIGKILL', encoding: 'utf8' });
  if (result.error || result.signal) {
    return { ok: false, error: result.error ? result.error.message : `超时/被终止 (${result.signal})`, status: result.status };
  }
  let payload = {};
  try { payload = JSON.parse(String(result.stdout || '').trim() || '{}'); } catch {}
  return { ok: result.status === 0 && payload.ok !== false, sid: payload.sid || null, status: result.status };
}

// Grants the AppContainer package SID read access to every path the Worker
// needs (the Node runtime, the project, the workspace). Without this the
// restricted token cannot even load node.exe.
// Grants the AppContainer package SID read access to the specific paths the
// Worker needs. Kept deliberately narrow: no recursive sweep of the whole
// project, and a hard timeout so a slow ACL walk can never wedge startup.
export function ensureAppContainerAccess({ host, roots = [], runtimeDir = null, logger, timeoutMs = 60000 } = {}) {
  const targets = [...new Set([runtimeDir, ...roots].filter(Boolean))];
  if (!host || !targets.length) return { ok: false, error: '缺少宿主或路径' };
  const results = [];
  for (const target of targets) {
    const result = provisionAppContainer({ host, readPaths: [target], timeoutMs, recursive: false });
    results.push({ target, ...result });
    if (!result.ok) logger?.warn(`AppContainer 授权失败: ${target}`);
  }
  return { ok: results.every((item) => item.ok), results };
}

export function sandboxCapabilities(config = {}) {
  const sandbox = resolveSandbox(config);
  return {
    tier: sandbox.tier,
    host: sandbox.host ? path.basename(sandbox.host) : null,
    mode: sandbox.mode || null,
    reason: sandbox.reason || null,
    platform: process.platform,
  };
}


