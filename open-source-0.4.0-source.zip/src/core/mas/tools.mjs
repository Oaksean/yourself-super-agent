/**
 * 检索 Agent 的联网工具层：搜索 → 抓页面 → 摘证据。
 *
 * 只用 Node 内置 fetch，不引入 SDK，也不依赖任何搜索 API Key。后端按实测结果选择：
 *   - 中文查询走百度（HTML 结果可解析，跳转链接可还原为原始 URL）；
 *   - 英文/拉丁查询走 Bing（中文首词查询会被 Bing 劫持成词典页，因此显式分流）；
 *   - 学术与代码类补充后端直接走官方 API（arXiv Atom、GitHub REST）。
 * 所有出网请求都有超时、体积上限与 URL 白名单（只允许 http/https）。
 */

const DEFAULT_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';
const MAX_PAGE_CHARS = 12_000;
const MAX_PAGE_BYTES = 3_000_000;

const cache = new Map();
const CACHE_TTL_MS = 30 * 60 * 1000;
const CACHE_LIMIT = 400;

function cacheGet(key) {
  const hit = cache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.at > CACHE_TTL_MS) {
    cache.delete(key);
    return null;
  }
  return hit.value;
}

function cacheSet(key, value) {
  if (cache.size >= CACHE_LIMIT) {
    const oldest = cache.keys().next().value;
    if (oldest !== undefined) cache.delete(oldest);
  }
  cache.set(key, { at: Date.now(), value });
  return value;
}

export function decodeEntities(text) {
  return String(text || '')
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCodePoint(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_, dec) => String.fromCodePoint(Number(dec)))
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'");
}

export function htmlToText(html) {
  return decodeEntities(
    String(html || '')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
      .replace(/<!--[\s\S]*?-->/g, ' ')
      .replace(/<(br|\/p|\/div|\/li|\/h[1-6]|\/tr)[^>]*>/gi, '\n')
      .replace(/<[^>]+>/g, ' ')
  )
    .replace(/\r/g, '')
    .replace(/[ \t\u00a0]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function absoluteUrl(raw, base) {
  try {
    return new URL(decodeEntities(String(raw).trim()), base).toString();
  } catch {
    return null;
  }
}

function isHttpUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch {
    return false;
  }
}

const ENGINE_HOSTS = [
  'bing.com', 'microsoft.com', 'google.com', 'gstatic.com', 'googleusercontent.com',
  'duckduckgo.com', 'baidu.com', 'so.com', 'sogou.com', 'zhihu.com/search',
];

function isEngineUrl(url) {
  try {
    const host = new URL(url).hostname.toLowerCase();
    return ENGINE_HOSTS.some((item) => host === item || host.endsWith(`.${item}`));
  } catch {
    return true;
  }
}

function hasCjk(text) {
  return /[\u4e00-\u9fa5]/.test(String(text || ''));
}

function leadingCharIsCjk(query) {
  return /^[\u4e00-\u9fa5]/.test(String(query || '').trim());
}

async function request(url, { signal, timeoutMs = 15_000, headers = {}, redirect = 'follow' } = {}) {
  const controller = new AbortController();
  const onAbort = () => controller.abort();
  signal?.addEventListener?.('abort', onAbort, { once: true });
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      redirect,
      signal: controller.signal,
      headers: {
        'user-agent': DEFAULT_UA,
        'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8',
        accept: 'text/html,application/xhtml+xml,application/json,application/xml,text/plain;q=0.9,*/*;q=0.6',
        ...headers,
      },
    });
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener?.('abort', onAbort);
  }
}

/** 搜索引擎的跳转链接（百度 /link?url=、360 /link?m=）还原为原始地址。 */
export async function resolveRedirect(url, { signal, depth = 3 } = {}) {
  const cacheKey = `resolve:${url}`;
  const cached = cacheGet(cacheKey);
  if (cached) return cached;
  let current = url;
  for (let hop = 0; hop < depth; hop += 1) {
    const response = await request(current, { signal, redirect: 'manual', timeoutMs: 12_000 });
    const location = response.headers.get('location');
    if (response.status >= 300 && response.status < 400 && location) {
      current = absoluteUrl(location, current) || current;
      continue;
    }
    const type = (response.headers.get('content-type') || '').toLowerCase();
    if (!type.includes('html')) return cacheSet(cacheKey, current);
    const html = await response.text();
    const meta = html.match(/http-equiv=["']?refresh["']?[^>]+url=([^"'>]+)/i)
      || html.match(/location\.(?:replace|assign|href)\s*=\s*["']([^"']+)["']/i);
    if (meta) {
      current = absoluteUrl(meta[1].replace(/&amp;/g, '&'), current) || current;
      continue;
    }
    return cacheSet(cacheKey, current);
  }
  return cacheSet(cacheKey, current);
}

/* ------------------------------------------------------------------ 解析 */

function parseBaidu(html, limit) {
  const results = [];
  const blocks = String(html).split(/<div[^>]+class="[^"]*(?:result|result-op)[^"]*"[^>]*>/i).slice(1);
  for (const block of blocks) {
    const anchor = block.match(/<h3[^>]*>[\s\S]*?<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i)
      || block.match(/<a[^>]+href="(http[^"]+)"[^>]*>([\s\S]{3,200}?)<\/a>/i);
    if (!anchor) continue;
    const url = absoluteUrl(anchor[1], 'https://www.baidu.com');
    if (!url || !isHttpUrl(url)) continue;
    const title = htmlToText(anchor[2]).slice(0, 180);
    if (!title) continue;
    const snippetMatch = block.match(/<div[^>]+class="[^"]*c-abstract[^"]*"[^>]*>([\s\S]*?)<\/div>/i)
      || block.match(/<span[^>]+class="[^"]*content-right[^"]*"[^>]*>([\s\S]*?)<\/span>/i);
    const snippet = snippetMatch ? htmlToText(snippetMatch[1]).slice(0, 400) : '';
    results.push({ title, url, snippet, backend: 'baidu', needsResolve: /baidu\.com\/link/.test(url) });
    if (results.length >= limit * 2) break;
  }
  return results;
}

function parseBing(html, limit) {
  const results = [];
  const blocks = String(html).split(/<li class="b_algo"/i).slice(1);
  for (const block of blocks) {
    const anchor = block.match(/<h2[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i)
      || block.match(/<a[^>]+href="(http[^"]+)"[^>]*>([\s\S]*?)<\/a>/i);
    if (!anchor) continue;
    const url = absoluteUrl(anchor[1], 'https://www.bing.com');
    if (!url || !isHttpUrl(url) || isEngineUrl(url)) continue;
    const title = htmlToText(anchor[2]).slice(0, 180);
    if (!title) continue;
    const snippetMatch = block.match(/<p class="b_lineclamp[^"]*"[^>]*>([\s\S]*?)<\/p>/i)
      || block.match(/<div class="b_caption"[^>]*>[\s\S]*?<p[^>]*>([\s\S]*?)<\/p>/i);
    results.push({
      title,
      url,
      snippet: snippetMatch ? htmlToText(snippetMatch[1]).slice(0, 400) : '',
      backend: 'bing',
      needsResolve: false,
    });
    if (results.length >= limit * 2) break;
  }
  return results;
}

/* ------------------------------------------------------------- 相关性过滤 */

const STOPWORDS = ['的', '了', '和', '与', '在', '是', '有', '及', '或', '对', '为', 'the', 'and', 'for', 'with', 'that', 'this', 'are', 'from', 'not'];

function queryTokens(query) {
  return String(query || '')
    .split(/[^\p{L}\p{N}]+/u)
    .map((token) => token.trim().toLowerCase())
    .filter((token) => token.length > 1 && !STOPWORDS.includes(token));
}

function matchesToken(haystack, token) {
  if (haystack.includes(token)) return true;
  // 中文长词放宽到前 4 个字符，兼容“多智能体协同 / 多智能体协作”这类近义表述
  if (token.length >= 5 && hasCjk(token) && haystack.includes(token.slice(0, 4))) return true;
  if (token.length >= 8 && !hasCjk(token) && haystack.includes(token.slice(0, 5))) return true;
  return false;
}

function isRelevant(item, tokens) {
  if (!tokens.length) return true;
  const haystack = `${item.title} ${item.snippet}`.toLowerCase();
  const hits = tokens.filter((token) => matchesToken(haystack, token)).length;
  return hits >= Math.min(2, tokens.length);
}

/* -------------------------------------------------------------- 搜索后端 */

async function searchBaidu(query, { limit, signal, timeoutMs }) {
  const url = `https://www.baidu.com/s?wd=${encodeURIComponent(query)}&rn=${Math.min(limit + 5, 20)}`;
  const response = await request(url, { signal, timeoutMs });
  if (!response.ok) throw new Error(`百度 ${response.status}`);
  const html = await response.text();
  return parseBaidu(html, limit);
}

async function searchBing(query, { limit, signal, timeoutMs }) {
  const url = `https://www.bing.com/search?q=${encodeURIComponent(query)}&count=${Math.min(limit + 5, 30)}`;
  const response = await request(url, { signal, timeoutMs });
  if (!response.ok) throw new Error(`Bing ${response.status}`);
  const html = await response.text();
  return parseBing(html, limit);
}

async function searchArxiv(query, { limit, signal, timeoutMs }) {
  const url = `https://export.arxiv.org/api/query?search_query=${encodeURIComponent(`all:${query}`)}&start=0&max_results=${limit}`;
  const response = await request(url, { signal, timeoutMs, headers: { accept: 'application/atom+xml' } });
  if (!response.ok) throw new Error(`arXiv ${response.status}`);
  const xml = await response.text();
  return xml.split('<entry>').slice(1).map((entry) => {
    const rawId = entry.match(/<id>([^<]+)<\/id>/)?.[1] || '';
    const title = htmlToText(entry.match(/<title>([\s\S]*?)<\/title>/)?.[1] || '').replace(/\s+/g, ' ').trim();
    const summary = htmlToText(entry.match(/<summary>([\s\S]*?)<\/summary>/)?.[1] || '').replace(/\s+/g, ' ').trim();
    const abs = rawId.replace('http://arxiv.org/abs/', 'https://arxiv.org/abs/').trim();
    return { title: title.slice(0, 180), url: abs, snippet: summary.slice(0, 400), backend: 'arxiv', needsResolve: false };
  }).filter((item) => item.url && isHttpUrl(item.url));
}

async function searchGithub(query, { limit, signal, timeoutMs }) {
  const url = `https://api.github.com/search/repositories?q=${encodeURIComponent(query)}&per_page=${Math.min(limit, 10)}`;
  const response = await request(url, { signal, timeoutMs, headers: { accept: 'application/vnd.github+json' } });
  if (!response.ok) throw new Error(`GitHub ${response.status}`);
  const data = await response.json();
  return (data.items || []).map((item) => ({
    title: `${item.full_name} — ${item.description || ''}`.slice(0, 180),
    url: item.html_url,
    snippet: `${item.description || ''} · ★${item.stargazers_count} · ${item.language || 'n/a'}`.slice(0, 400),
    backend: 'github',
    needsResolve: false,
  }));
}

const BACKENDS = { baidu: searchBaidu, bing: searchBing, arxiv: searchArxiv, github: searchGithub };

function pickBackends(query, explicit) {
  if (explicit?.length) return explicit;
  // Bing 对“首词为中文”的查询会返回汉字词典页，因此中文查询不打 Bing。
  return leadingCharIsCjk(query) ? ['baidu'] : ['bing', 'baidu'];
}

/**
 * 搜索并返回经过相关性过滤、URL 还原与去重后的结果。
 * @returns {Promise<{results:Array, backend:string, errors:Array}>}
 */
export async function searchWeb(query, { limit = 6, backends = null, signal, timeoutMs = 18_000, relevance = true } = {}) {
  const chain = pickBackends(query, backends);
  const cacheKey = `search:${query}:${chain.join(',')}:${limit}`;
  const cached = cacheGet(cacheKey);
  if (cached) return cached;
  const errors = [];
  const tokens = queryTokens(query);

  for (const backend of chain) {
    const fn = BACKENDS[backend];
    if (!fn) continue;
    let raw;
    try {
      raw = await fn(query, { limit, signal, timeoutMs });
    } catch (error) {
      errors.push({ backend, error: error.message });
      continue;
    }
    if (!raw.length) {
      errors.push({ backend, error: '无结果' });
      continue;
    }
    let candidates = relevance ? raw.filter((item) => isRelevant(item, tokens)) : raw;
    if (!candidates.length) {
      errors.push({ backend, error: `结果相关性不足（原始 ${raw.length} 条）` });
      continue;
    }

    // 跳转链接还原为原始 URL，否则引用无法校验
    const resolved = [];
    for (const item of candidates.slice(0, limit + 2)) {
      let url = item.url;
      if (item.needsResolve) {
        try {
          url = await resolveRedirect(item.url, { signal });
        } catch (error) {
          errors.push({ backend, error: `解析跳转失败: ${error.message}` });
        }
      }
      if (!url || !isHttpUrl(url) || isEngineUrl(url)) continue;
      resolved.push({ title: item.title, url, snippet: item.snippet, backend });
    }

    const deduped = [];
    const seen = new Set();
    for (const item of resolved) {
      const key = item.url.replace(/[#?].*$/, '').replace(/\/+$/, '').toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      deduped.push(item);
    }
    if (deduped.length) {
      return cacheSet(cacheKey, { results: deduped.slice(0, limit), backend, errors, query });
    }
    errors.push({ backend, error: '无可用链接' });
  }
  return cacheSet(cacheKey, { results: [], backend: null, errors, query });
}

/* -------------------------------------------------------------- 抓页面 */

export async function fetchPage(url, { signal, timeoutMs = 15_000, maxChars = MAX_PAGE_CHARS } = {}) {
  if (!isHttpUrl(url)) throw new Error('只允许抓取 http/https 链接');
  const cacheKey = `page:${url}`;
  const cached = cacheGet(cacheKey);
  if (cached) return cached;
  let response;
  try {
    response = await request(url, { signal, timeoutMs, headers: { referer: 'https://www.baidu.com/' } });
  } catch (error) {
    return cacheSet(cacheKey, { ok: false, status: 0, url, title: '', text: '', note: `请求失败: ${error.message}` });
  }
  if (!response.ok) {
    return cacheSet(cacheKey, { ok: false, status: response.status, url, title: '', text: '', note: `HTTP ${response.status}` });
  }
  const type = (response.headers.get('content-type') || '').toLowerCase();
  const finalUrl = response.url || url;
  if (!/text\/html|text\/plain|application\/xhtml|application\/json|application\/xml|text\/xml|application\/rss/.test(type)) {
    return cacheSet(cacheKey, { ok: false, status: response.status, url: finalUrl, title: '', text: '', note: `不支持的内容类型: ${type || '未知'}` });
  }
  const buffer = await response.arrayBuffer();
  if (buffer.byteLength > MAX_PAGE_BYTES) {
    return cacheSet(cacheKey, { ok: false, status: response.status, url: finalUrl, title: '', text: '', note: '页面体积超过 3MB 上限' });
  }
  const html = new TextDecoder('utf-8', { fatal: false }).decode(buffer);
  const rawTitle = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || '';
  const title = htmlToText(rawTitle).slice(0, 200);
  const text = htmlToText(html).slice(0, maxChars);
  return cacheSet(cacheKey, { ok: true, status: response.status, url: finalUrl, title, text, chars: text.length, note: null });
}

/** 把长文切成便于引用的句子片段。 */
export function splitSentences(text, { minLen = 24, maxLen = 240, limit = 40 } = {}) {
  return String(text || '')
    .split(/(?<=[。！？!?.])\s|\n+/)
    .map((item) => item.replace(/\s+/g, ' ').trim())
    .filter((item) => item.length >= minLen && item.length <= maxLen)
    .slice(0, limit);
}

function tokens(text) {
  return String(text || '').toLowerCase().split(/[^\p{L}\p{N}]+/u).filter((token) => token && token.length > 1 && !STOPWORDS.includes(token));
}

/**
 * 引用校验：判断 quote 是否真的出现在页面正文中。
 * 不要求逐字一致（模型会做省略与改写），以词覆盖率和原文命中判断。
 */
export function quoteMatches(text, quote, { threshold = 0.75 } = {}) {
  const quoteTokens = tokens(quote);
  if (!quoteTokens.length) return { ok: false, overlap: 0, reason: '空引用' };
  const flatHay = String(text || '').toLowerCase().replace(/\s+/g, ' ');
  const flatQuote = String(quote || '').toLowerCase().replace(/\s+/g, ' ').trim();
  if (flatQuote.length > 16 && flatHay.includes(flatQuote)) return { ok: true, overlap: 1, reason: '原文命中' };
  const hayTokens = new Set(tokens(text));
  const overlap = quoteTokens.filter((token) => hayTokens.has(token)).length / quoteTokens.length;
  const ok = overlap >= threshold;
  return {
    ok,
    overlap: Number(overlap.toFixed(3)),
    reason: ok ? '页面词覆盖达标' : '页面中未找到足够重合的原文',
  };
}

export function clearToolCache() {
  cache.clear();
}
