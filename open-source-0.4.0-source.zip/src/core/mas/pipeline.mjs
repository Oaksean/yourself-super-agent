/**
 * 多智能体协同 · 调研报告流水线
 *
 * 架构：中心化编排（Orchestrator-Centric），与 IC Memo 的 POC 结论一致：
 *   Coordinator 负责目标分析与任务拆解，专家 Agent 并行执行，Verifier 独立校验证据，
 *   Reviewer / Arbiter 形成“写作—审校—仲裁”的收敛闭环，Archivist 归档落盘。
 *
 * 每轮是一张 DAG；返工通过“按轮重建图”实现，图内不成环，便于审计与复现。
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import { nowIso } from '../ids.mjs';
import { StateGraph } from './graph.mjs';
import { searchWeb, fetchPage, quoteMatches } from './tools.mjs';
import {
  briefMessages, planMessages, scoutMessages, writerMessages,
  reviewerMessages, arbiterMessages, ROLE_LABELS,
} from './prompts.mjs';
import { resolveSafePath } from '../security.mjs';

const MAX_TOPIC_LENGTH = 200;

export const TEMPLATES = [
  {
    id: 'research',
    name: '调研报告流水线',
    architecture: '中心化编排（Orchestrator-Centric）',
    description: '目标分析 → 任务拆解 → 并行检索 → 引用校验 → 撰写 → 审校 → 仲裁 → 归档。检索 Agent 真实联网取证据，每条论断回抓原文校验。',
    defaults: { depth: 2, maxRevisions: 1 },
    limits: { depth: [1, 3], maxRevisions: [0, 3] },
    roles: ['coordinator', 'researcher', 'verifier', 'writer', 'reviewer', 'arbiter', 'archivist'],
  },
];

class CancelledError extends Error {
  constructor(message = '运行已取消') {
    super(message);
    this.name = 'CancelledError';
  }
}

function clamp(value, min, max, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(max, Math.max(min, Math.round(number)));
}

function cleanMarkdown(content) {
  let text = String(content || '').trim();
  const fenced = text.match(/^```(?:markdown|md)?\s*([\s\S]*?)\s*```$/i);
  if (fenced) text = fenced[1].trim();
  return text;
}

function slugify(topic) {
  const cleaned = String(topic || '')
    .replace(/[\\/:*?"<>|\s]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48);
  return cleaned || 'report';
}

function asArray(value) {
  if (Array.isArray(value)) return value;
  if (value == null) return [];
  return [value];
}

// 模型偶尔把检索词写成一条长字符串（用空格或分号连接），这里拆回数组并限长，
// 避免把整段话当成一个 query 丢给搜索引擎。
function asQueries(value) {
  const raw = Array.isArray(value) ? value : [value];
  const pieces = [];
  for (const item of raw) {
    const text = safeString(item);
    if (!text) continue;
    const split = text.split(/[\n|；;]+/).map((part) => part.trim()).filter(Boolean);
    pieces.push(...(split.length > 1 ? split : [text]));
  }
  return pieces.map((query) => query.slice(0, 80)).filter(Boolean);
}

function safeString(value, fallback = '') {
  if (typeof value === 'string') return value.trim();
  if (value == null) return fallback;
  return String(value);
}

export class MasService {
  constructor({ config, store, llm, events, logger, memory = null, toolset = {} }) {
    this.config = config;
    this.store = store;
    this.llm = llm;
    this.events = events;
    this.logger = logger;
    this.memory = memory;
    this.search = toolset.searchWeb || searchWeb;
    this.fetchPage = toolset.fetchPage || fetchPage;
    this.quoteMatches = toolset.quoteMatches || quoteMatches;
    this.controllers = new Map();
    this.executions = new Map();
    this.queue = [];
    this.active = 0;
    this.closing = false;
    this.maxConcurrent = Number(config.mas?.maxConcurrentRuns) || 2;
    this.model = config.provider?.workerModel || config.provider?.model;
    this.defaultSessionId = null;
  }

  templates() {
    return TEMPLATES;
  }

  snapshot() {
    return {
      active: this.active,
      queued: this.queue.length,
      maxConcurrent: this.maxConcurrent,
      templates: TEMPLATES.map((item) => ({ id: item.id, name: item.name, architecture: item.architecture, defaults: item.defaults, limits: item.limits })),
    };
  }

  #ensureSession() {
    if (this.defaultSessionId) return this.defaultSessionId;
    const existing = this.store.listSessions(200).find((session) => session.title === '多智能体协同');
    const session = existing || this.store.createSession('多智能体协同');
    this.defaultSessionId = session.id;
    return session.id;
  }

  createRun(payload = {}) {
    const template = TEMPLATES.find((item) => item.id === (payload.template || 'research'));
    if (!template) throw new Error(`未知的协同模板: ${payload.template}`);
    const topic = safeString(payload.topic);
    if (topic.length < 2) throw new Error('请填写调研主题（至少 2 个字）');
    if (topic.length > MAX_TOPIC_LENGTH) throw new Error(`调研主题过长（上限 ${MAX_TOPIC_LENGTH} 字）`);
    const params = {
      depth: clamp(payload.depth ?? template.defaults.depth, ...template.limits.depth, template.defaults.depth),
      maxRevisions: clamp(payload.maxRevisions ?? template.defaults.maxRevisions, ...template.limits.maxRevisions, template.defaults.maxRevisions),
      notes: safeString(payload.notes).slice(0, 300),
      scoutCount: clamp(payload.depth ?? template.defaults.depth, ...template.limits.depth, template.defaults.depth) + 1,
      autoStart: payload.autoStart !== false,
    };
    const run = this.store.createMasRun({
      sessionId: this.#ensureSession(),
      template: template.id,
      topic,
      params,
    });
    this.#emit({ type: 'mas.run.queued', runId: run.id, topic, params });
    if (params.autoStart) {
      this.queue.push(run.id);
      this.#drain();
    }
    return run;
  }

  #drain() {
    if (this.closing) return;
    while (this.active < this.maxConcurrent && this.queue.length) {
      const runId = this.queue.shift();
      const run = this.store.getMasRun(runId);
      if (!run || run.status === 'cancelled') continue;
      this.active += 1;
      const execution = this.#execute(runId)
        .catch((error) => this.logger.error('协同运行异常', error))
        .finally(() => {
          this.active -= 1;
          this.executions.delete(runId);
          this.#drain();
        });
      this.executions.set(runId, execution);
    }
  }

  async close() {
    this.closing = true;
    this.queue.length = 0;
    for (const controller of this.controllers.values()) controller.abort();
    await Promise.allSettled([...this.executions.values()]);
  }

  cancel(runId) {
    const run = this.store.getMasRun(runId);
    if (!run) return null;
    const controller = this.controllers.get(runId);
    if (controller) controller.abort();
    const queued = this.queue.indexOf(runId);
    if (queued >= 0) this.queue.splice(queued, 1);
    if (['queued', 'running'].includes(run.status)) {
      const updated = this.store.updateMasRun(runId, { status: 'cancelled', finished_at: nowIso(), error: '用户取消' });
      this.#emit({ type: 'mas.run.cancelled', runId });
      return updated;
    }
    return run;
  }

  retry(runId) {
    const run = this.store.getMasRun(runId);
    if (!run) return null;
    return this.createRun({ topic: run.topic, ...run.params, template: run.template });
  }

  resumePendingRuns() {
    const pending = this.store.listMasRuns({ limit: 500 })
      .filter((run) => ['queued', 'running'].includes(run.status));
    for (const run of pending) {
      if (run.status === 'running') {
        this.store.updateMasRun(run.id, {
          status: 'queued', started_at: null, finished_at: null,
          error: null,
        });
      }
      if (!this.queue.includes(run.id)) this.queue.push(run.id);
      this.#emit({ type: 'mas.run.recovered', runId: run.id, topic: run.topic });
    }
    if (pending.length) this.#drain();
    return pending.length;
  }

  detail(runId) {
    const run = this.store.getMasRun(runId);
    if (!run) return null;
    return {
      run,
      steps: this.store.listMasSteps(runId),
      artifacts: this.store.listMasArtifacts(runId),
    };
  }

  report(runId) {
    const artifacts = this.store.listMasArtifacts(runId);
    const reportArtifact = artifacts.find((item) => item.kind === 'report');
    if (!reportArtifact) return null;
    const artifact = this.store.getMasArtifact(reportArtifact.id);
    return { name: artifact.name, path: artifact.path, content: artifact.content, createdAt: artifact.createdAt };
  }

  /* ------------------------------------------------------------ 执行主体 */

  async #execute(runId) {
    const run = this.store.getMasRun(runId);
    if (!run) return;
    const controller = new AbortController();
    this.controllers.set(runId, controller);
    const startedAt = Date.now();
    this.store.updateMasRun(runId, { status: 'running', started_at: nowIso(), error: null });
    this.#emit({ type: 'mas.run.started', runId, topic: run.topic });

    const params = run.params;
    let state = {
      runId,
      topic: run.topic,
      notes: params.notes || '',
      depth: params.depth,
      scoutCount: params.scoutCount,
      maxRevisions: params.maxRevisions,
      round: 1,
      brief: null,
      plan: null,
      evidence: {},
      claims: [],
      verification: null,
      draft: null,
      review: null,
      arbitration: null,
      report: null,
      messages: [],
      priorKnowledge: [],
      metrics: { llmCalls: 0, tokens: 0, searchCalls: 0, pages: 0, sources: 0, arbitrations: 0 },
    };

    try {
      state.priorKnowledge = await this.#recallPrior(run);
      const rounds = params.maxRevisions + 1;

      for (let round = 1; round <= rounds; round += 1) {
        if (controller.signal.aborted) throw new CancelledError();
        state.round = round;
        // 返工轮不再重跑检索：证据集已固定在 state.claims 上
        const runner = this.#buildGraph(round, { isLastRound: round === rounds, scoutCount: params.scoutCount })
          .compile({
            runId,
            round,
            onEvent: (event) => this.#onGraphEvent(runId, event),
            log: (...args) => this.logger.info('[mas]', ...args),
          });
        const result = await runner.run(state, { signal: controller.signal });
        state = result.state;
        this.store.updateMasRun(runId, { state: this.#publicState(state), metrics: this.#metrics(state, startedAt) });

        if (result.status === 'cancelled') throw new CancelledError();
        if (result.status === 'failed') throw result.error || new Error('协同编排失败');
        if (state.arbitration?.decision === 'ship') break;
      }

      const metrics = this.#metrics(state, startedAt);
      const finished = this.store.updateMasRun(runId, {
        status: 'completed',
        finished_at: nowIso(),
        state: this.#publicState(state),
        metrics,
        error: null,
      });
      await this.#remember(run, state);
      const message = this.#recordRunMessage(finished, state);
      this.#emit({ type: 'mas.run.completed', runId, topic: run.topic, metrics, decision: state.arbitration?.decision || 'ship', message });
      return finished;
    } catch (error) {
      const cancelled = error instanceof CancelledError || controller.signal.aborted;
      const metrics = this.#metrics(state, startedAt);
      const finished = this.store.updateMasRun(runId, {
        status: cancelled ? 'cancelled' : 'failed',
        finished_at: nowIso(),
        state: this.#publicState(state),
        metrics,
        error: error.message,
      });
      const message = this.#recordRunMessage(finished, state, error.message);
      this.#emit({
        type: cancelled ? 'mas.run.cancelled' : 'mas.run.failed',
        runId, topic: run.topic, error: error.message, message,
      });
      if (!cancelled) this.logger.warn('协同运行失败', error.message);
    } finally {
      this.controllers.delete(runId);
    }
  }

  #recordRunMessage(run, state, error = null) {
    if (!run?.sessionId) return null;
    const report = this.report(run.id);
    const reportPath = report?.path ? `\n\n产物路径：${report.path}` : '';
    let content;
    if (run.status === 'completed') {
      content = [
        `多智能体专项调研已完成：${run.topic}`,
        `协作方式：中心化编排 · ${state.scoutCount || 0} 个检索 Agent + 独立校验/审校/仲裁`,
        `证据校验：${state.verification?.passed || 0}/${state.verification?.total || 0} 通过；审校评分：${state.review?.score ?? '未知'}；仲裁：${state.arbitration?.decision || 'ship'}`,
        '',
        report?.content ? String(report.content).slice(0, 18000) : '报告已生成，但未返回正文。',
        reportPath,
      ].filter(Boolean).join('\n');
    } else if (run.status === 'cancelled') {
      content = `多智能体专项调研已取消：${run.topic}${error ? `\n\n原因：${error}` : ''}`;
    } else {
      content = `多智能体专项调研未完成：${run.topic}\n\n${error || run.error || '协同运行失败'}`;
    }
    const message = this.store.addMessage({
      sessionId: run.sessionId,
      role: 'assistant',
      content: content.slice(0, 30000),
      metadata: {
        kind: 'mas_report', runId: run.id, status: run.status,
        reportPath: report?.path || null, metrics: run.metrics,
      },
    });
    return message;
  }
  #publicState(state) {
    return {
      brief: state.brief,
      plan: state.plan,
      evidence: Object.fromEntries(Object.entries(state.evidence || {}).map(([key, value]) => [key, {
        subtask: value.subtask,
        queries: value.queries,
        sources: value.sources,
        gaps: value.gaps,
        claimCount: value.claims.length,
      }])),
      claims: state.claims,
      verification: state.verification,
      draft: state.draft,
      review: state.review,
      arbitration: state.arbitration,
      report: state.report,
      messages: state.messages,
      round: state.round,
      priorKnowledge: state.priorKnowledge,
    };
  }

  #metrics(state, startedAt) {
    const m = state.metrics || {};
    return {
      durationMs: Date.now() - startedAt,
      llmCalls: m.llmCalls || 0,
      tokens: m.tokens || 0,
      searchCalls: m.searchCalls || 0,
      pages: m.pages || 0,
      sources: m.sources || (state.claims ? new Set(state.claims.map((claim) => claim.url)).size : 0),
      claims: (state.claims || []).length,
      verified: (state.claims || []).filter((claim) => claim.verified?.ok).length,
      passRate: state.verification?.passRate ?? null,
      arbitrations: m.arbitrations || 0,
      rounds: state.round,
      decision: state.arbitration?.decision || null,
      score: state.review?.score ?? null,
    };
  }

  #emit(event) {
    try {
      this.events?.emit(event);
    } catch { /* SSE 失败不影响运行 */ }
  }

  #onGraphEvent(runId, event) {
    const base = {
      runId,
      round: event.round,
      nodeId: event.nodeId,
      label: event.label,
      role: event.role,
      kind: event.kind,
    };
    if (event.type === 'mas.node.started') {
      this.store.upsertMasStep({ runId, nodeId: event.nodeId, round: event.round, label: event.label, role: event.role, status: 'running', startedAt: nowIso() });
      this.#emit({ type: 'mas.node.started', ...base });
    } else if (event.type === 'mas.node.completed') {
      this.store.upsertMasStep({
        runId, nodeId: event.nodeId, round: event.round, label: event.label, role: event.role,
        status: 'completed', durationMs: event.durationMs, summary: event.summary,
        output: event.output || null, finishedAt: nowIso(),
      });
      this.#emit({ type: 'mas.node.completed', ...base, durationMs: event.durationMs, summary: event.summary });
    } else if (event.type === 'mas.node.failed') {
      this.store.upsertMasStep({ runId, nodeId: event.nodeId, round: event.round, label: event.label, role: event.role, status: 'failed', error: event.error, finishedAt: nowIso() });
      this.#emit({ type: 'mas.node.failed', ...base, error: event.error });
    } else if (event.type === 'mas.node.skipped') {
      this.store.upsertMasStep({ runId, nodeId: event.nodeId, round: event.round, label: event.label, role: event.role, status: 'skipped', summary: event.reason, finishedAt: nowIso() });
      this.#emit({ type: 'mas.node.skipped', ...base, reason: event.reason });
    }
  }

  /* --------------------------------------------------------------- LLM */

  async #chatJson(nodeLabel, messages, { signal, temperature = 0.2, retries = 1, metrics } = {}) {
    let lastError;
    for (let attempt = 0; attempt <= retries; attempt += 1) {
      try {
        const response = await this.llm.chatJson(messages, { model: this.model, temperature, signal });
        this.#trackUsage(metrics, response.usage);
        return response.json;
      } catch (error) {
        lastError = error;
        this.logger.warn(`[mas] ${nodeLabel} 结构化输出失败（第 ${attempt + 1} 次）`, error.message);
      }
    }
    throw new Error(`${nodeLabel} 未能返回可解析的 JSON：${lastError?.message || '未知错误'}`);
  }

  async #chatText(nodeLabel, messages, { signal, temperature = 0.35, metrics } = {}) {
    const response = await this.llm.chat(messages, { model: this.model, temperature, signal });
    this.#trackUsage(metrics, response.usage);
    return response.content;
  }

  #trackUsage(metrics, usage) {
    if (!metrics) return;
    metrics.llmCalls = (metrics.llmCalls || 0) + 1;
    metrics.tokens = (metrics.tokens || 0) + (Number(usage?.total_tokens) || 0);
  }

  /* --------------------------------------------------------------- 记忆 */

  async #recallPrior(run) {
    if (!this.memory) return [];
    try {
      const items = await this.memory.recall(run.sessionId, run.topic, { topK: 3 });
      return (items || []).slice(0, 3).map((item) => ({ content: String(item.content || '').slice(0, 400), score: item.score ?? null }));
    } catch (error) {
      this.logger.warn('[mas] 长期记忆召回失败', error.message);
      return [];
    }
  }

  async #remember(run, state) {
    if (!this.store) return;
    try {
      const summary = `调研主题《${run.topic}》：${state.brief?.question || ''}｜结论：${state.arbitration?.reason || '按证据交付'}｜引用通过率 ${state.verification ? (state.verification.passRate * 100).toFixed(0) + '%' : '未校验'}｜报告：${state.report?.name || '未落盘'}`;
      const stored = this.store.addMemory({ sessionId: run.sessionId, kind: 'mas_run', content: summary.slice(0, 2000), importance: 3 });
      this.memory?.indexMemory?.(stored).catch(() => {});
    } catch (error) {
      this.logger.warn('[mas] 写入长期记忆失败', error.message);
    }
  }

  /* ------------------------------------------------------------ 图定义 */

  #buildGraph(round, { isLastRound, scoutCount }) {
    const service = this;
    const graph = new StateGraph({ name: `research-r${round}`, concurrency: 3 });
    const first = round === 1;
    const scoutIds = Array.from({ length: scoutCount }, (_, index) => `scout_${index + 1}`);

    if (first) {
      graph.addNode('brief', {
        label: ROLE_LABELS.brief.label, role: ROLE_LABELS.brief.role, kind: 'agent', retries: 1,
        run: async (state, ctx) => {
          const json = await service.#chatJson('目标分析', briefMessages(state), { signal: ctx.signal, metrics: state.metrics });
          const brief = service.#normalizeBrief(json, state);
          state.messages.push({ from: 'coordinator', to: 'team', kind: 'brief', text: `研究问题：${brief.question}`, at: nowIso() });
          return { brief, $step: { title: '目标分析', summary: brief.question, detail: brief } };
        },
      });

      graph.addNode('plan', {
        label: ROLE_LABELS.plan.label, role: ROLE_LABELS.plan.role, kind: 'agent', deps: ['brief'], retries: 1,
        run: async (state, ctx) => {
          const json = await service.#chatJson('任务拆解', planMessages(state), { signal: ctx.signal, metrics: state.metrics });
          const plan = service.#normalizePlan(json, state);
          state.messages.push({ from: 'coordinator', to: 'researchers', kind: 'dispatch', text: `拆解为 ${plan.subtasks.length} 个子任务：${plan.subtasks.map((item) => item.title).join(' / ')}`, at: nowIso() });
          return { plan, $step: { title: '任务拆解', summary: plan.subtasks.map((item) => item.title).join('、'), detail: plan } };
        },
      });

      scoutIds.forEach((nodeId, index) => {
        graph.addNode(nodeId, {
          label: `检索 Agent ${index + 1}`,
          role: ROLE_LABELS.scout.role,
          kind: 'agent',
          retries: 1,
          deps: ['plan'],
          run: async (state, ctx) => {
            const subtask = (state.plan?.subtasks || [])[index];
            if (!subtask) return { $step: { title: nodeId, summary: '子任务未分配' } };
            return service.#runScout(state, subtask, index, { signal: ctx.signal, round: state.round });
          },
        });
      });

      graph.addNode('verify', {
        label: ROLE_LABELS.verify.label, role: ROLE_LABELS.verify.role, kind: 'checker',
        deps: scoutIds.map((nodeId) => ({ id: nodeId, optional: true })),
        run: async (state, ctx) => service.#runVerify(state, { signal: ctx.signal }),
      });
    }

    graph.addNode('write', {
      label: ROLE_LABELS.write.label, role: ROLE_LABELS.write.role, kind: 'agent', retries: 1,
      deps: first ? ['verify'] : [],
      run: async (state, ctx) => {
        const content = await service.#chatText('报告撰写', writerMessages(state, state.round), { signal: ctx.signal, temperature: 0.4, metrics: state.metrics });
        const markdown = cleanMarkdown(content);
        if (markdown.length < 200) throw new Error('撰写 Agent 返回内容过短，判定为无效草稿');
        state.messages.push({ from: 'writer', to: 'reviewer', kind: 'draft', text: `草稿完成，${markdown.length} 字，第 ${state.round} 轮`, at: nowIso() });
        return {
          draft: { markdown, wordCount: markdown.length, round: state.round, createdAt: nowIso() },
          $step: { title: `报告草稿（第 ${state.round} 轮）`, summary: `${markdown.length} 字`, detail: { wordCount: markdown.length } },
        };
      },
    });

    graph.addNode('review', {
      label: ROLE_LABELS.review.label, role: ROLE_LABELS.review.role, kind: 'agent', deps: ['write'], retries: 1,
      run: async (state, ctx) => {
        const json = await service.#chatJson('审校', reviewerMessages(state), { signal: ctx.signal, metrics: state.metrics });
        const review = service.#normalizeReview(json);
        state.messages.push({ from: 'reviewer', to: 'arbiter', kind: 'review', text: `评分 ${review.score}，结论 ${review.verdict}，高优问题 ${review.issues.filter((issue) => issue.severity === 'high').length} 条`, at: nowIso() });
        return { review, $step: { title: `审校（第 ${state.round} 轮）`, summary: `${review.score} 分 · ${review.verdict}`, detail: { issues: review.issues.length } } };
      },
    });

    graph.addNode('arbitrate', {
      label: ROLE_LABELS.arbitrate.label, role: ROLE_LABELS.arbitrate.role, kind: 'agent', deps: ['review'], retries: 1,
      run: async (state, ctx) => {
        const json = await service.#chatJson('仲裁', arbiterMessages(state), { signal: ctx.signal, metrics: state.metrics });
        const arbitration = service.#normalizeArbitration(json, state, isLastRound);
        state.messages.push({ from: 'arbiter', to: 'coordinator', kind: 'decision', text: `${arbitration.decision}：${arbitration.reason}`, at: nowIso() });
        return { arbitration, $step: { title: `仲裁（第 ${state.round} 轮）`, summary: `${arbitration.decision} · ${arbitration.reason}`, detail: { decision: arbitration.decision } } };
      },
    });

    graph.addNode('finalize', {
      label: ROLE_LABELS.finalize.label, role: ROLE_LABELS.finalize.role, kind: 'archivist',
      deps: [{
        id: 'arbitrate',
        label: '交付判定',
        when: (state) => Boolean(state.arbitration) && (state.arbitration.decision === 'ship' || state.round >= state.maxRevisions + 1),
      }],
      run: async (state, ctx) => service.#finalize(state, { signal: ctx.signal }),
    });

    return graph;
  }

  /* ------------------------------------------------------------ 各节点实现 */

  #normalizeBrief(json, state) {
    const brief = json && typeof json === 'object' ? json : {};
    const outline = asArray(brief.outline).map((item) => safeString(item)).filter(Boolean).slice(0, 8);
    return {
      question: safeString(brief.question, `围绕「${state.topic}」的现状、对比与落地路径`).slice(0, 200),
      boundary: safeString(brief.boundary).slice(0, 300),
      deliverable: safeString(brief.deliverable, '可直接交付的技术调研报告').slice(0, 200),
      audiences: asArray(brief.audiences).map((item) => safeString(item)).filter(Boolean).slice(0, 4),
      outline: outline.length ? outline : ['结论与判断', '技术现状', '框架对比', '风险与边界', '落地建议'],
      subQuestions: asArray(brief.subQuestions).filter((item) => item && typeof item === 'object'),
    };
  }

  #normalizePlan(json, state) {
    const wanted = state.scoutCount;
    const raw = asArray(json?.subtasks).length ? asArray(json.subtasks) : asArray(state.brief?.subQuestions);
    const subtasks = [];
    for (let index = 0; index < wanted; index += 1) {
      const item = raw[index] || {};
      const fallbackTopics = state.brief?.outline || [];
      subtasks.push({
        id: `t${index + 1}`,
        title: safeString(item.title, fallbackTopics[index] || `子问题 ${index + 1}`).slice(0, 60),
        focus: safeString(item.focus || item.title, `围绕「${state.topic}」的第 ${index + 1} 个方面`).slice(0, 120),
        queries: asQueries(item.queries).slice(0, 3),
      });
    }
    // 关键词兜底：模型没给检索词时，用子任务标题与主题拼一条
    for (const subtask of subtasks) {
      if (!subtask.queries.length) subtask.queries = [`${state.topic} ${subtask.title}`.trim()];
    }
    return { subtasks, generatedAt: nowIso() };
  }

  async #runScout(state, subtask, index, { signal }) {
    const nodeId = `scout_${index + 1}`;
    const queries = subtask.queries.slice(0, 3);
    const collected = [];
    const errors = [];
    const seen = new Set();

    for (const query of queries) {
      if (signal?.aborted) throw new CancelledError();
      try {
        const result = await this.search(query, { limit: 4, signal });
        state.metrics.searchCalls += 1;
        for (const item of result.results) {
          const key = item.url.replace(/[#?].*$/, '').replace(/\/+$/, '').toLowerCase();
          if (seen.has(key)) continue;
          seen.add(key);
          collected.push({ ...item, query });
        }
        for (const failure of result.errors || []) errors.push(`${failure.backend}: ${failure.error}`);
      } catch (error) {
        errors.push(`搜索失败: ${error.message}`);
      }
    }

    const maxSources = Number(this.config.mas?.maxSourcesPerScout) || 4;
    const pages = [];
    for (const item of collected.slice(0, maxSources + 2)) {
      if (pages.length >= maxSources) break;
      if (signal?.aborted) throw new CancelledError();
      try {
        const page = await this.fetchPage(item.url, { signal, maxChars: 8000 });
        state.metrics.pages += 1;
        if (page.ok && page.text && page.text.length > 80) {
          pages.push({
            title: page.title || item.title,
            url: item.url,
            text: page.text,
            backend: item.backend,
            query: item.query,
          });
        } else if (page.note) {
          errors.push(`${item.url}: ${page.note}`);
        }
      } catch (error) {
        errors.push(`${item.url}: ${error.message}`);
      }
    }

    if (!pages.length) {
      const gap = { subtask: subtask.title, queries, sources: [], claims: [], gaps: ['本轮没有抓到可用页面'], notes: errors.slice(0, 4) };
      state.evidence[nodeId] = gap;
      return {
        $step: { title: subtask.title, summary: `检索 ${queries.length} 次，无可用正文`, detail: { queries, errors: errors.slice(0, 6) } },
      };
    }

    const json = await this.#chatJson(`检索分析 ${index + 1}`, scoutMessages(state, subtask, pages), { signal, temperature: 0.15, metrics: state.metrics });
    const claims = asArray(json?.claims).map((claim) => {
      const sourceIndex = Number(String(safeString(claim.sourceId)).replace(/[^0-9]/g, '')) - 1;
      const source = pages[sourceIndex] || pages[0];
      return {
        id: null,
        subtask: subtask.title,
        text: safeString(claim.text).slice(0, 200),
        quote: safeString(claim.quote).slice(0, 400),
        url: source?.url || '',
        sourceTitle: source?.title || '',
        confidence: ['high', 'medium', 'low'].includes(safeString(claim.confidence)) ? claim.confidence : 'medium',
        verified: null,
      };
    }).filter((claim) => claim.text && claim.quote && claim.url).slice(0, 6);

    const gaps = asArray(json?.gaps).map((gap) => safeString(gap)).filter(Boolean).slice(0, 4);
    state.evidence[nodeId] = {
      subtask: { title: subtask.title, focus: subtask.focus },
      queries,
      sources: pages.map((page) => ({ title: page.title, url: page.url, chars: page.text.length, backend: page.backend })),
      claims,
      gaps,
      notes: safeString(json?.notes).slice(0, 200),
      errors: errors.slice(0, 6),
    };
    state.messages.push({
      from: nodeId, to: 'verifier', kind: 'findings',
      text: `${subtask.title}：${claims.length} 条论断，${pages.length} 篇来源${gaps.length ? `，${gaps.length} 个证据缺口` : ''}`,
      at: nowIso(),
    });

    return {
      $step: {
        title: subtask.title,
        summary: `${claims.length} 条论断 / ${pages.length} 篇来源`,
        detail: { queries, sources: pages.map((page) => page.url), gaps },
      },
    };
  }

  async #runVerify(state, { signal }) {
    const claims = [];
    for (const [nodeId, bucket] of Object.entries(state.evidence || {})) {
      for (const claim of bucket.claims || []) claims.push({ ...claim, scout: nodeId });
    }
    claims.forEach((claim, index) => { claim.id = index + 1; });

    const pageCache = new Map();
    const details = [];
    let passed = 0;
    for (const claim of claims) {
      if (signal?.aborted) throw new CancelledError();
      let page = pageCache.get(claim.url);
      if (!page) {
        page = await this.fetchPage(claim.url, { signal, maxChars: 12000 });
        pageCache.set(claim.url, page);
      }
      let verdict;
      if (!page.ok) {
        verdict = { ok: false, overlap: 0, reason: page.note || '页面无法回抓' };
      } else {
        verdict = this.quoteMatches(page.text, claim.quote);
      }
      claim.verified = { ok: Boolean(verdict.ok), overlap: verdict.overlap ?? 0, reason: verdict.reason };
      if (claim.verified.ok) passed += 1;
      details.push({
        id: claim.id,
        text: claim.text.slice(0, 120),
        url: claim.url,
        ok: claim.verified.ok,
        overlap: claim.verified.overlap,
        reason: claim.verified.reason,
      });
    }

    const total = claims.length;
    const verification = {
      total, passed, failed: total - passed,
      passRate: total ? Number((passed / total).toFixed(3)) : 0,
      failedIds: details.filter((item) => !item.ok).map((item) => item.id),
      details,
      checkedAt: nowIso(),
    };
    state.messages.push({
      from: 'verifier', to: 'writer', kind: 'verification',
      text: `引用校验：${passed}/${total} 通过（${(verification.passRate * 100).toFixed(0)}%）`,
      at: nowIso(),
    });
    return {
      claims, verification,
      $step: {
        title: '引用回抓校验',
        summary: `${passed}/${total} 条通过（${(verification.passRate * 100).toFixed(0)}%）`,
        detail: { failedIds: verification.failedIds, sources: new Set(claims.map((claim) => claim.url)).size },
      },
    };
  }

  #normalizeReview(json) {
    const raw = json && typeof json === 'object' ? json : {};
    const issues = asArray(raw.issues).map((issue) => ({
      severity: ['high', 'medium', 'low'].includes(safeString(issue?.severity)) ? issue.severity : 'medium',
      where: safeString(issue?.where, '未定位').slice(0, 120),
      problem: safeString(issue?.problem).slice(0, 240),
      fix: safeString(issue?.fix).slice(0, 240),
    })).filter((issue) => issue.problem).slice(0, 8);
    const score = Math.max(0, Math.min(100, Math.round(Number(raw.score) || 0)));
    const hasHigh = issues.some((issue) => issue.severity === 'high');
    const verdict = safeString(raw.verdict) === 'pass' && !hasHigh ? 'pass' : 'revise';
    return {
      score, verdict, issues,
      unsupportedClaims: asArray(raw.unsupportedClaims).map((item) => safeString(item)).filter(Boolean).slice(0, 6),
      summary: safeString(raw.summary).slice(0, 240),
      reviewedAt: nowIso(),
    };
  }

  #normalizeArbitration(json, state, isLastRound) {
    const raw = json && typeof json === 'object' ? json : {};
    const review = state.review || { issues: [] };
    const verification = state.verification || { total: 0, passRate: 0 };
    let decision = safeString(raw.decision) === 'ship' ? 'ship' : 'revise';
    // 硬性闸门只在“确实有论断可校验”时生效；一条证据都没有属于另一种失败形态，交由风险披露
    if (verification.total > 0 && verification.passRate < 0.6) decision = 'revise';
    if (isLastRound) decision = 'ship';
    const openRisks = asArray(raw.openRisks).map((item) => safeString(item)).filter(Boolean).slice(0, 4);
    if (verification.total === 0) openRisks.unshift('本轮未取得可校验的证据，报告结论需人工复核');
    if (isLastRound && review.issues?.some((issue) => issue.severity === 'high')) {
      openRisks.push('部分高优先级审校问题在轮次上限内未解决');
    }
    state.metrics.arbitrations = (state.metrics.arbitrations || 0) + 1;
    const fallbackReason = verification.total === 0
      ? '未取得可校验证据，仅能交付带风险披露的版本'
      : decision === 'ship' ? '证据与审校均达标' : '存在未解决的高优先级问题或证据不足';
    return {
      decision,
      reason: safeString(raw.reason, fallbackReason).slice(0, 240),
      mustFix: asArray(raw.mustFix).map((item) => safeString(item)).filter(Boolean).slice(0, 3),
      openRisks: openRisks.slice(0, 5),
      round: state.round,
      decidedAt: nowIso(),
    };
  }

  async #finalize(state, { signal }) {
    const draft = state.draft?.markdown || '';
    const body = draft.replace(/^#\s+.+\n+/, '');
    const claims = state.claims || [];
    const verification = state.verification || { total: 0, passed: 0, passRate: 0, details: [] };

    const header = [
      `# ${state.topic}`,
      '',
      `> **研究问题**：${state.brief?.question || state.topic}`,
      `> **协同架构**：中心化编排 · ${state.scoutCount} 个检索 Agent 并行 + 校验/审校/仲裁 分工`,
      `> **证据规模**：${claims.length} 条论断 · ${new Set(claims.map((claim) => claim.url)).size} 篇来源 · 引用回抓通过率 ${(verification.passRate * 100).toFixed(0)}%（${verification.passed}/${verification.total}）`,
      `> **收敛过程**：共 ${state.round} 轮（写作上限 ${state.maxRevisions + 1} 轮），仲裁结论 ${state.arbitration?.decision || 'ship'} —— ${state.arbitration?.reason || '按证据交付'}`,
      `> **生成时间**：${new Date().toLocaleString('zh-CN', { hour12: false })}`,
      '',
    ].join('\n');

    const evidenceAppendix = [
      '',
      '---',
      '',
      '## 附录 A · 证据清单与校验结果',
      '',
      '| # | 论断 | 来源 | 校验 |',
      '| --- | --- | --- | --- |',
      ...claims.map((claim) => `| [${claim.id}] | ${claim.text.replace(/\|/g, '\\|')} | ${claim.url} | ${claim.verified?.ok ? '通过' : `未通过（${claim.verified?.reason || '未校验'}）`} |`),
      '',
      '## 附录 B · 过程记录',
      '',
      `- 子问题：${(state.plan?.subtasks || []).map((item) => item.title).join('；') || '无'}`,
      `- 检索次数：${state.metrics.searchCalls} 次；抓取页面：${state.metrics.pages} 个`,
      `- 审校评分：${state.review?.score ?? '未知'}（${state.review?.verdict || '未知'}）`,
      ...(state.review?.issues || []).map((issue) => `- [${issue.severity}] ${issue.where}：${issue.problem} → ${issue.fix}`),
      ...(state.arbitration?.openRisks || []).map((risk) => `- 遗留风险：${risk}`),
      ...(state.arbitration?.mustFix || []).map((item) => `- 未处理项：${item}`),
    ].join('\n');

    const markdown = `${header}${body}${evidenceAppendix}\n`;
    state.report = {
      markdown,
      name: null,
      path: null,
      writeError: null,
      writeStatus: 'not-written',
      createdAt: nowIso(),
    };

    try {
      const workspace = this.config.workspace;
      const dir = path.join(workspace, this.config.mas?.reportDir || '多智能体报告');
      await fs.mkdir(dir, { recursive: true });
      const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
      const fileName = `${slugify(state.topic)}-${stamp}.md`;
      const filePath = resolveSafePath(path.join(dir, fileName), [workspace]);
      await fs.writeFile(filePath, markdown, 'utf8');
      const verifyPath = filePath.replace(/\.md$/, '.verify.json');
      await fs.writeFile(verifyPath, JSON.stringify({
        topic: state.topic,
        metrics: state.metrics,
        verification,
        review: state.review,
        arbitration: state.arbitration,
        steps: Object.keys(state.nodes || {}),
        generatedAt: nowIso(),
      }, null, 2), 'utf8');
      state.report.path = filePath;
      state.report.name = fileName;
      state.report.verifyPath = verifyPath;
      state.report.writeStatus = 'written';
    } catch (error) {
      state.report.writeError = error.message;
      state.report.writeStatus = 'db-only';
      this.logger.warn('[mas] 报告落盘失败，仅保存到数据库', error.message);
    }

    this.store.addMasArtifact({
      runId: state.runId, kind: 'report',
      name: state.report.name || `${slugify(state.topic)}.md`,
      path: state.report.path, content: markdown,
    });
    this.store.addMasArtifact({
      runId: state.runId, kind: 'verification',
      name: (state.report.name || `${slugify(state.topic)}.md`).replace(/\.md$/, '.verify.json'),
      path: state.report.verifyPath || null,
      content: JSON.stringify({ verification, review: state.review, arbitration: state.arbitration }, null, 2),
    });

    return {
      $step: {
        title: '归档',
        summary: state.report.writeStatus === 'written' ? `已写入 ${state.report.name}` : '已保存到数据库（磁盘写入失败）',
        detail: { name: state.report.name, path: state.report.path, writeError: state.report.writeError },
      },
    };
  }
}

export function createMasService(options) {
  return new MasService(options);
}


