/**
 * 调研报告流水线中各 Agent 的提示词。
 *
 * 共同约束（对应 IC Memo 的风险治理条款）：
 *   - 只允许使用“已抓取到的事实”下结论，未取得证据的内容必须显式标注；
 *   - 输出结构化 JSON 时，除 JSON 之外不要输出任何解释性文字；
 *   - 引用必须原标题、原链接、原引文三者对应，不得拼接或改写引文。
 */

const COMMON_RULES = `硬性约束：
1. 只依据给定材料写作，不得凭印象补充事实；没有材料支撑的结论必须标注「（待核实，无检索证据）」。
2. 引用编号只能用材料里已经给出的编号，不得新造编号，不得把两段材料的原话拼成一句。
3. 中文输出，术语保留英文原名（如 LangGraph、A2A、MCP）。
4. 需要 JSON 时只输出一个 JSON 对象，不要包裹代码块以外的解释文字。`;

export function briefMessages(state) {
  const system = `你是多智能体协同流水线中的「目标分析 Agent」。你的唯一职责是把用户给的主题，转成一份可执行的调研任务书。
${COMMON_RULES}`;
  const user = `用户主题：${state.topic}
额外要求：${state.notes || '无'}

请输出 JSON：
{
  "question": "一句话的核心研究问题（不超过 60 字）",
  "boundary": "明确纳入/排除的范围（不超过 80 字）",
  "deliverable": "最终交付物的形态与深度（不超过 50 字）",
  "audiences": ["读者画像，1-3 条"],
  "outline": ["报告的一级章节标题，4-6 条"],
  "subQuestions": [
    {"id": "q1", "title": "子问题标题", "focus": "这个子问题要回答什么（不超过 40 字）", "queries": ["检索词，2-4 条；中文主题给中文词，技术主题同时给 1 条英文词"]}
  ]
}
子问题数量固定 ${state.scoutCount} 条，彼此不重叠，合起来覆盖 outline。检索词要具体到能被搜索引擎理解，不要整句提问。`;
  return [{ role: 'system', content: system }, { role: 'user', content: user }];
}

export function planMessages(state) {
  const system = `你是多智能体协同流水线中的「任务拆解 Agent」。你要把调研任务书拆成彼此不重叠、可并行执行的检索子任务，分派给 ${state.scoutCount} 个检索 Agent。
${COMMON_RULES}`;
  const brief = state.brief || {};
  const user = `研究问题：${brief.question || state.topic}
范围边界：${brief.boundary || '未限定'}
交付物：${brief.deliverable || '技术调研报告'}
建议章节：${(brief.outline || []).join(' / ')}
已有子问题草稿：
${(brief.subQuestions || []).map((item, index) => `${index + 1}. ${item.title}｜${item.focus || ''}`).join('\n') || '（无，请自行拆分）'}

请输出 JSON：
{
  "subtasks": [
    {
      "id": "t1",
      "title": "子任务标题（不超过 12 字）",
      "focus": "这个子任务要回答的具体问题（不超过 40 字）",
      "queries": ["1-3 条可直接投喂搜索引擎的检索词；中文主题用中文，技术主题附 1 条英文"]
    }
  ]
}
子任务数量固定 ${state.scoutCount} 条。检索词要短、要具体（例如“LangGraph StateGraph 原理”），不要写疑问句。`;
  return [{ role: 'system', content: system }, { role: 'user', content: user }];
}

export function scoutMessages(state, subtask, evidencePack) {
  const system = `你是调研团队中的「检索分析 Agent」，角色：${subtask.title}。
你拿到的是真实抓取的网页正文节选。你的任务是抽取可被引用的论断，而不是写综述。
${COMMON_RULES}`;
  const sources = evidencePack.map((source, index) => {
    const excerpt = source.text.slice(0, 2400);
    return `[S${index + 1}] 标题：${source.title}\nURL：${source.url}\n正文节选：\n${excerpt}`;
  }).join('\n\n---\n\n');

  const user = `研究问题：${state.brief?.question || state.topic}
你的子问题：${subtask.focus}

可引用的材料如下（共 ${evidencePack.length} 篇）：
${sources || '（本轮没有抓到可用页面）'}

请输出 JSON：
{
  "claims": [
    {
      "text": "一条可独立成立的论断（不超过 60 字）",
      "quote": "支撑它的原文片段（必须逐字来自上面某篇正文，20-120 字）",
      "sourceId": "S1",
      "confidence": "high | medium | low"
    }
  ],
  "gaps": ["没有找到证据、但对结论很关键的信息点"],
  "notes": "一句话说明本子问题的证据强度"
}
要求：claims 3-6 条，每条都必须能在给定正文里找到对应原句；找不到就写进 gaps，不要编。`;
  return [{ role: 'system', content: system }, { role: 'user', content: user }];
}

export function writerMessages(state, round) {
  const system = `你是调研团队中的「撰写 Agent」。你要把多名检索 Agent 交来的证据，写成一份可以直接交付的技术调研报告。
${COMMON_RULES}
额外要求：
- 用 Markdown，标题层级清晰，正文用中文，术语保留英文原名。
- 每个关键论断后面必须带引用编号，例如 [3]；同一句可以用多个编号。
- 证据不足的地方写明「证据不足」，不要用推测填空。
- 不要写“本文将”“综上所述”这类空话，直接给信息。`;

  const claims = (state.claims || []).map((claim, index) => `[${index + 1}] ${claim.text}\n   出处：${claim.url}\n   原句：${claim.quote}`).join('\n');
  const verify = state.verification;
  const verifyNote = verify
    ? `\n引用校验结果：共 ${verify.total} 条，逐条回抓通过 ${verify.passed} 条（通过率 ${(verify.passRate * 100).toFixed(0)}%）。未通过的编号：${verify.failedIds.join('、') || '无'}。未通过的编号不得作为核心论据，只能标注为待核实。`
    : '';

  const revision = round > 1 && state.review
    ? `\n这是第 ${round} 轮修订。上一轮评审意见（必须逐条处理）：\n${(state.review.issues || []).map((issue, index) => `${index + 1}. [${issue.severity}] ${issue.where}：${issue.problem} → 建议：${issue.fix}`).join('\n')}\n仲裁意见：${state.arbitration?.reason || '无'}`
    : '';

  const outline = (state.brief?.outline || []).join(' / ');
  const user = `报告主题：${state.topic}
核心研究问题：${state.brief?.question || state.topic}
目标读者：${(state.brief?.audiences || []).join('、') || '技术决策者'}
建议章节：${outline || '自由组织，但需包含：结论先行、技术现状、对比分析、风险与边界、落地建议'}
${verifyNote}${revision}

带编号的证据清单（只能引用这些编号）：
${claims || '（无可用证据，请如实说明证据缺失并给出调研建议）'}

直接输出报告 Markdown 正文，第一行用「# 」作为标题。不要输出解释、不要用代码块包裹整篇。`;
  return [{ role: 'system', content: system }, { role: 'user', content: user }];
}

export function reviewerMessages(state) {
  const system = `你是调研团队中的「审校 Agent」。你的职责是挑错，不是夸奖。
${COMMON_RULES}
重点检查四类问题：
1. 事实问题：论断与原文不符，或原文并未支持该论断；
2. 引用问题：编号缺失、编号指向的证据不支持该句、把弱证据当强结论；
3. 结构问题：结论不先行、章节之间重复、缺少对比或缺少边界说明；
4. 表达问题：空话、模板句式、术语不一致。`;

  const claims = (state.claims || []).map((claim, index) => `[${index + 1}] ${claim.text}（${claim.url}）`).join('\n');
  const user = `报告正文：
${(state.draft?.markdown || '').slice(0, 6000)}

可引用证据清单：
${claims || '（无）'}

输出 JSON：
{
  "score": 0-100 的整数,
  "verdict": "pass | revise",
  "issues": [{"severity":"high|medium|low","where":"章节或原句定位","problem":"问题是什么","fix":"怎么改"}],
  "unsupportedClaims": ["报告中缺少证据支撑的句子"],
  "summary": "一句话评审结论"
}
判定标准：存在 high 级问题（事实错误 / 引用不成立 / 关键结论无证据）时必须给 revise。issues 最多 8 条，按严重度排序。`;
  return [{ role: 'system', content: system }, { role: 'user', content: user }];
}

export function arbiterMessages(state) {
  const system = `你是调研团队中的「仲裁 Agent」。检索、撰写、审校三方意见可能冲突，你负责给出终局判断，并说明理由。
${COMMON_RULES}
判断原则：
- 优先保证“不出现无证据的断言”，其次才是文采与篇幅；
- 若引用通过率低于 60%，即使审校认为可交付，也应要求返工；
- 返工轮次已到上限时，只能接受并明确标注未解决项。`;
  const user = `当前轮次：第 ${state.round} 轮（上限 ${state.maxRevisions + 1} 轮）
引用校验通过率：${state.verification ? `${(state.verification.passRate * 100).toFixed(0)}%（${state.verification.passed}/${state.verification.total}）` : '未执行'}
审校评分：${state.review?.score ?? '未知'}，结论：${state.review?.verdict || '未知'}
未解决的高优先级问题：${(state.review?.issues || []).filter((issue) => issue.severity === 'high').map((issue) => issue.problem).join('；') || '无'}

输出 JSON：
{
  "decision": "ship | revise",
  "reason": "一句话说明依据",
  "mustFix": ["下一轮必须处理的具体问题，最多 3 条"],
  "openRisks": ["即使交付也需要向读者披露的遗留风险"]
}`;
  return [{ role: 'system', content: system }, { role: 'user', content: user }];
}

export const ROLE_LABELS = {
  brief: { label: '目标分析', role: 'coordinator' },
  plan: { label: '任务拆解', role: 'coordinator' },
  scout: { label: '检索分析', role: 'researcher' },
  verify: { label: '引用校验', role: 'verifier' },
  write: { label: '报告撰写', role: 'writer' },
  review: { label: '审校', role: 'reviewer' },
  arbitrate: { label: '仲裁', role: 'arbiter' },
  finalize: { label: '归档', role: 'archivist' },
};
