/**
 * StateGraph —— 多智能体协同的最小编排引擎。
 *
 * 对齐 LangGraph 的核心抽象，但不引入任何外部依赖：
 *   - 节点 = 一个 Agent（或纯函数步骤），输入是共享 State，输出是 State 的增量补丁；
 *   - 边   = 依赖关系；带 `when` 条件即为条件路由；
 *   - 扇出 = 同层多个节点无依赖时并发执行（受并发上限约束）；
 *   - 汇合 = 下游节点声明多个依赖，全部进入终态后才可调度；
 *   - 轮次 = 循环（“评审不通过 → 返工”）由上层按轮驱动，图内不成环，保证可审计。
 *
 * 引擎只负责调度、超时、重试、状态合并与事件埋点，不理解任何业务语义。
 */

const DEFAULT_TIMEOUT_MS = 180_000;
const DEFAULT_CONCURRENCY = 3;

export class GraphError extends Error {
  constructor(message, details = {}) {
    super(message);
    this.name = 'GraphError';
    this.details = details;
  }
}

function sleep(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(new GraphError('运行已取消'));
    const timer = setTimeout(() => {
      signal?.removeEventListener?.('abort', onAbort);
      resolve();
    }, ms);
    function onAbort() {
      clearTimeout(timer);
      reject(new GraphError('运行已取消'));
    }
    signal?.addEventListener?.('abort', onAbort, { once: true });
  });
}

function normalizeDep(dep) {
  if (typeof dep === 'string') return { id: dep, optional: false, when: null, label: dep };
  return {
    id: dep.id,
    optional: Boolean(dep.optional),
    when: typeof dep.when === 'function' ? dep.when : null,
    label: dep.label || dep.id,
  };
}

export class StateGraph {
  constructor({ name = 'graph', concurrency = DEFAULT_CONCURRENCY } = {}) {
    this.name = name;
    this.concurrency = Math.max(1, Number(concurrency) || DEFAULT_CONCURRENCY);
    this.nodes = new Map();
  }

  /**
   * @param {string} id 节点 id（同时是它在 state.nodes 里的键）
   * @param {{label?:string, role?:string, kind?:string, deps?:Array, run:Function,
   *          timeoutMs?:number, retries?:number, failurePolicy?:'abort'|'continue'}} spec
   */
  addNode(id, spec = {}) {
    if (!id || typeof id !== 'string') throw new GraphError('节点 id 必须是非空字符串');
    if (this.nodes.has(id)) throw new GraphError(`节点重复: ${id}`);
    if (typeof spec.run !== 'function') throw new GraphError(`节点 ${id} 缺少 run 实现`);
    this.nodes.set(id, {
      id,
      label: spec.label || id,
      role: spec.role || 'agent',
      kind: spec.kind || 'agent',
      deps: (spec.deps || []).map(normalizeDep),
      run: spec.run,
      timeoutMs: Number(spec.timeoutMs) || DEFAULT_TIMEOUT_MS,
      retries: Math.max(0, Number(spec.retries) || 0),
      failurePolicy: spec.failurePolicy === 'continue' ? 'continue' : 'abort',
    });
    return this;
  }

  addEdge(from, to, options = {}) {
    const target = this.nodes.get(to);
    if (!target) throw new GraphError(`边指向未知节点: ${to}`);
    if (!this.nodes.has(from)) throw new GraphError(`边起点未知: ${from}`);
    const hasPlainDep = target.deps.some((dep) => dep.id === from && !dep.when);
    if (!hasPlainDep) {
      target.deps.push(normalizeDep({ id: from, when: options.when, optional: options.optional, label: options.label }));
    }
    return this;
  }

  validate() {
    for (const node of this.nodes.values()) {
      for (const dep of node.deps) {
        if (!this.nodes.has(dep.id)) throw new GraphError(`节点 ${node.id} 依赖未知节点 ${dep.id}`);
        if (dep.id === node.id) throw new GraphError(`节点 ${node.id} 不能依赖自身`);
      }
    }
    const visiting = new Set();
    const done = new Set();
    const visit = (nodeId, stack) => {
      if (done.has(nodeId)) return;
      if (visiting.has(nodeId)) throw new GraphError(`图存在环: ${[...stack, nodeId].join(' → ')}`);
      visiting.add(nodeId);
      for (const dep of this.nodes.get(nodeId).deps) {
        if (dep.when) continue; // 条件边是软依赖，不参与强依赖环检测
        visit(dep.id, [...stack, nodeId]);
      }
      visiting.delete(nodeId);
      done.add(nodeId);
    };
    for (const nodeId of this.nodes.keys()) visit(nodeId, []);
    return true;
  }

  compile({ onEvent = null, runId = null, round = 1, log = () => {} } = {}) {
    this.validate();
    const graph = this;

    async function executeNode(node, state, ctx) {
      let attempt = 0;
      let lastError = null;
      while (attempt <= node.retries) {
        attempt += 1;
        if (ctx.signal?.aborted) throw new GraphError('运行已取消');
        const attemptController = new AbortController();
        const onOuterAbort = () => attemptController.abort();
        ctx.signal?.addEventListener?.('abort', onOuterAbort, { once: true });
        let timedOut = false;
        const timer = setTimeout(() => {
          timedOut = true;
          attemptController.abort();
        }, node.timeoutMs);
        const startedAt = Date.now();
        try {
          const patch = await node.run(state, {
            ...ctx,
            nodeId: node.id,
            signal: attemptController.signal,
            attempt,
          });
          if (timedOut) throw new GraphError(`节点 ${node.label} 超时（${node.timeoutMs}ms）`, { nodeId: node.id });
          return {
            patch: patch && typeof patch === 'object' ? patch : {},
            attempts: attempt,
            startedAt,
          };
        } catch (error) {
          lastError = timedOut
            ? new GraphError(`节点 ${node.label} 超时（${node.timeoutMs}ms）`, { nodeId: node.id })
            : error;
          ctx.log(`节点 ${node.label} 第 ${attempt} 次执行失败: ${lastError.message}`);
          if (attempt <= node.retries && !ctx.signal?.aborted) await sleep(300 * attempt, ctx.signal);
        } finally {
          clearTimeout(timer);
          ctx.signal?.removeEventListener?.('abort', onOuterAbort);
        }
      }
      throw lastError;
    }

    async function run(initialState = {}, options = {}) {
      const status = new Map([...graph.nodes.keys()].map((nodeId) => [nodeId, 'pending']));
      const steps = [];
      const state = { ...initialState };
      const running = new Map();
      const failure = { error: null };
      const signal = options.signal || null;

      const ctx = {
        graphName: graph.name,
        runId,
        round,
        signal,
        log: (...args) => log(...args),
      };
      const emit = (type, payload) => {
        if (!onEvent) return;
        try {
          onEvent({ type, runId, round, graph: graph.name, ...payload });
        } catch { /* 事件订阅失败不能中断编排 */ }
      };

      const terminal = (nodeId) => ['completed', 'failed', 'skipped', 'cancelled'].includes(status.get(nodeId));
      const busy = () => [...status.values()].some((value) => value === 'pending' || value === 'ready' || value === 'running');

      const recordSkip = (node, reason) => {
        status.set(node.id, 'skipped');
        steps.push({
          nodeId: node.id, label: node.label, role: node.role, kind: node.kind,
          status: 'skipped', reason, round, attempts: 0,
          endedAt: new Date().toISOString(), durationMs: 0,
        });
        emit('mas.node.skipped', { nodeId: node.id, label: node.label, role: node.role, reason });
      };

      while (busy()) {
        // 1) 依赖全部终态的节点：判定跳过或就绪（级联处理，直到稳定）
        let changed = true;
        while (changed) {
          changed = false;
          for (const node of graph.nodes.values()) {
            if (status.get(node.id) !== 'pending') continue;
            if (!node.deps.every((dep) => terminal(dep.id))) continue;
            changed = true;

            if (failure.error) {
              recordSkip(node, `运行已失败：${failure.error.message}`);
              continue;
            }
            let skipReason = null;
            for (const dep of node.deps) {
              const depStatus = status.get(dep.id);
              if (depStatus === 'completed') {
                if (dep.when && !dep.when(state, { nodeId: node.id })) {
                  skipReason = `条件不满足（${dep.label}）`;
                  break;
                }
              } else if (!dep.optional) {
                skipReason = `依赖 ${dep.label} ${depStatus === 'failed' ? '失败' : '被跳过'}`;
                break;
              }
            }
            if (skipReason) {
              recordSkip(node, skipReason);
              continue;
            }
            status.set(node.id, 'ready');
          }
        }

        // 2) 在并发上限内启动就绪节点
        for (const node of graph.nodes.values()) {
          if (status.get(node.id) !== 'ready') continue;
          if (running.size >= graph.concurrency) break;
          status.set(node.id, 'running');
          emit('mas.node.started', { nodeId: node.id, label: node.label, role: node.role, kind: node.kind });
          const promise = (async () => {
            const startedAt = Date.now();
            try {
              if (signal?.aborted) throw new GraphError('运行已取消');
              const outcome = await executeNode(node, state, ctx);
              const { $step, ...patch } = outcome.patch;
              Object.assign(state, patch);
              state.nodes = { ...(state.nodes || {}), [node.id]: $step || { label: node.label, role: node.role } };
              status.set(node.id, 'completed');
              const step = {
                nodeId: node.id, label: node.label, role: node.role, kind: node.kind,
                status: 'completed', round, attempts: outcome.attempts,
                startedAt: new Date(outcome.startedAt).toISOString(),
                endedAt: new Date().toISOString(), durationMs: Date.now() - outcome.startedAt,
                summary: ($step && ($step.summary || $step.title)) || null,
                output: $step || null,
              };
              steps.push(step);
              emit('mas.node.completed', {
                nodeId: node.id, label: node.label, role: node.role,
                durationMs: step.durationMs, summary: step.summary, output: step.output,
              });
            } catch (error) {
              const cancelled = Boolean(signal?.aborted) || error?.name === 'GraphError' && /取消/.test(error.message);
              status.set(node.id, cancelled ? 'cancelled' : 'failed');
              steps.push({
                nodeId: node.id, label: node.label, role: node.role, kind: node.kind,
                status: cancelled ? 'cancelled' : 'failed', round,
                endedAt: new Date().toISOString(), durationMs: Date.now() - startedAt,
                error: error.message,
              });
              emit('mas.node.failed', { nodeId: node.id, label: node.label, role: node.role, error: error.message });
              if (node.failurePolicy === 'abort' && !failure.error && !cancelled) {
                failure.error = new GraphError(`节点 ${node.label} 失败：${error.message}`, { nodeId: node.id, cause: error });
              }
            } finally {
              running.delete(node.id);
            }
          })();
          running.set(node.id, promise);
        }

        // 3) 等任意一个节点结束，再回到调度
        if (running.size) {
          await Promise.race([...running.values()]);
          continue;
        }
        if (![...status.values()].some((value) => value === 'ready')) {
          for (const [nodeId, value] of status) {
            if (value === 'pending') recordSkip(graph.nodes.get(nodeId), '依赖条件互锁，无法调度');
          }
        }
      }

      const cancelled = Boolean(signal?.aborted);
      const failed = Boolean(failure.error) && !cancelled;
      return {
        state,
        steps,
        status: cancelled ? 'cancelled' : failed ? 'failed' : 'completed',
        error: cancelled ? new GraphError('运行已取消') : failure.error,
        nodes: Object.fromEntries([...status.entries()]),
      };
    }

    return {
      name: graph.name,
      nodes: graph.nodes,
      validate: () => graph.validate(),
      run,
    };
  }
}

export function createGraph(options) {
  return new StateGraph(options);
}
