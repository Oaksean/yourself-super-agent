import crypto from 'node:crypto';

export function id(prefix = 'id') {
  return `${prefix}_${crypto.randomUUID().replaceAll('-', '').slice(0, 20)}`;
}

export function nowIso() {
  return new Date().toISOString();
}
