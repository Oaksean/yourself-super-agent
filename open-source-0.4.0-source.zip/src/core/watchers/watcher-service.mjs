import fs from 'node:fs';
import path from 'node:path';
import { EventEmitter } from 'node:events';
import { resolveSafePath } from '../security.mjs';
import { id } from '../ids.mjs';

// Watches the workspace and turns filesystem changes into Trigger objects.
//
// A watcher is a persisted subscription row (session + path + optional
// glob/regex). When a change is observed, WatcherService debounces it, applies
// ignore patterns, records an event, and emits `trigger` with source "file".
// The Router then either matches an existing Thread Subscription (direct route)
// or performs a normal routing decision.
export class WatcherService extends EventEmitter {
  constructor({ config, store, allowRoots, logger }) {
    super();
    this.config = config;
    this.store = store;
    this.allowRoots = allowRoots || config.allowedRoots;
    this.logger = logger;
    this.handles = new Map();
    this.pending = new Map();
    this.debounceMs = Number(config.watchers?.debounceMs) || 1200;
    this.enabled = config.watchers?.enabled !== false;
    this.ignore = (config.watchers?.ignorePatterns || []).map((pattern) => {
      try { return new RegExp(pattern); } catch { return null; }
    }).filter(Boolean);
  }

  start() {
    if (!this.enabled) {
      this.logger?.info('文件监听已禁用');
      return;
    }
    for (const watcher of this.store.listWatchers({ activeOnly: true })) this.attach(watcher);
    this.logger?.info(`文件监听已启动，活动监听 ${this.handles.size} 个`);
    this.reloadTimer = setInterval(() => this.reconcile(), 15000);
    this.reloadTimer.unref?.();
  }

  reconcile() {
    const active = this.store.listWatchers({ activeOnly: true });
    const known = new Set(active.map((watcher) => watcher.id));
    for (const [watcherId] of this.handles) {
      if (!known.has(watcherId)) this.detach(watcherId);
    }
    for (const watcher of active) if (!this.handles.has(watcher.id)) this.attach(watcher);
  }

  register(input) {
    const safePath = resolveSafePath(input.path || this.config.workspace, this.allowRoots, { mustExist: true });
    const stat = fs.statSync(safePath);
    if (!stat.isDirectory()) throw new Error('监听目标必须是目录');
    const watcher = this.store.createWatcher({
      sessionId: input.sessionId,
      path: safePath,
      pattern: input.pattern || null,
      events: Array.isArray(input.events) && input.events.length ? input.events : ['add', 'change'],
      recursive: input.recursive !== false,
    });
    this.attach(watcher);
    return watcher;
  }

  unregister(watcherId) {
    this.detach(watcherId);
    return this.store.deactivateWatcher(watcherId);
  }

  attach(watcher) {
    if (this.handles.has(watcher.id)) return;
    let handle;
    try {
      handle = fs.watch(watcher.path, { recursive: Boolean(watcher.recursive), persistent: true }, (eventType, filename) => {
        this.#onRawEvent(watcher, eventType, filename);
      });
    } catch (error) {
      this.logger?.warn(`无法监听 ${watcher.path}: ${error.message}`);
      return;
    }
    handle.on('error', (error) => this.logger?.warn(`监听 ${watcher.path} 出错: ${error.message}`));
    this.handles.set(watcher.id, { handle, watcher });
  }

  detach(watcherId) {
    const entry = this.handles.get(watcherId);
    if (!entry) return;
    try { entry.handle.close(); } catch {}
    this.handles.delete(watcherId);
  }

  #onRawEvent(watcher, eventType, filename) {
    const relative = filename ? String(filename) : '';
    const normalized = relative.split(path.sep).join('/');
    if (this.#ignored(normalized)) return;
    if (watcher.pattern) {
      let regex;
      try { regex = new RegExp(watcher.pattern); } catch { regex = null; }
      if (regex && !regex.test(normalized)) return;
    }
    const mapped = eventType === 'rename' ? 'add' : 'change';
    if (Array.isArray(watcher.events) && watcher.events.length && !watcher.events.includes(mapped) && !watcher.events.includes('all')) return;

    const key = `${watcher.id}:${normalized}`;
    const existing = this.pending.get(key);
    if (existing) clearTimeout(existing.timer);
    const timer = setTimeout(() => {
      this.pending.delete(key);
      this.#emitTrigger(watcher, mapped, normalized);
    }, this.debounceMs);
    timer.unref?.();
    this.pending.set(key, { timer, eventType: mapped });
  }

  #ignored(relative) {
    if (!relative) return false;
    return this.ignore.some((regex) => regex.test(relative)) || this.ignore.some((regex) => regex.test(relative.replace(/\\/g, '/')));
  }

  #emitTrigger(watcher, eventType, relative) {
    const absolute = path.join(watcher.path, relative);
    const event = {
      id: id('wevt'),
      watcherId: watcher.id,
      sessionId: watcher.session_id,
      path: absolute,
      relative,
      eventType,
      payload: { path: absolute, relative, eventType, watcherId: watcher.id },
    };
    this.store.addWatcherEvent({ subscriptionId: watcher.id, path: absolute, eventType, payload: event.payload });
    this.emit('trigger', {
      type: 'file',
      source: 'file',
      sessionId: watcher.session_id,
      text: `文件${eventType === 'add' ? '新增' : '变更'}: ${relative || absolute}`,
      metadata: { path: absolute, relative, eventType, watcherId: watcher.id },
    });
  }

  stop() {
    if (this.reloadTimer) clearInterval(this.reloadTimer);
    this.reloadTimer = null;
    for (const key of this.pending.keys()) {
      const entry = this.pending.get(key);
      if (entry) clearTimeout(entry.timer);
    }
    this.pending.clear();
    for (const [watcherId] of this.handles) this.detach(watcherId);
  }

  snapshot() {
    return {
      enabled: this.enabled,
      active: this.handles.size,
      debounceMs: this.debounceMs,
      watchers: this.store.listWatchers({ activeOnly: true }).map((watcher) => ({ id: watcher.id, path: watcher.path, pattern: watcher.pattern, events: watcher.events })),
    };
  }
}
