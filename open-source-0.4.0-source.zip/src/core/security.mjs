import fs from 'node:fs';
import path from 'node:path';

function isInside(candidate, root) {
  const relative = path.relative(root, candidate);
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative));
}

export function normalizeRoots(roots) {
  return roots.map((root) => path.resolve(root)).map((root) => {
    try { return fs.realpathSync.native(root); } catch { return root; }
  });
}

export function resolveSafePath(inputPath, roots, { mustExist = false } = {}) {
  if (typeof inputPath !== 'string' || !inputPath.trim()) throw new Error('路径不能为空');
  const candidate = path.resolve(inputPath);
  let resolved = candidate;
  try {
    if (fs.existsSync(candidate)) resolved = fs.realpathSync.native(candidate);
    else {
      const parent = path.dirname(candidate);
      const realParent = fs.existsSync(parent) ? fs.realpathSync.native(parent) : parent;
      resolved = path.join(realParent, path.basename(candidate));
    }
  } catch (error) {
    throw new Error(`无法解析路径: ${error.message}`);
  }
  if (!normalizeRoots(roots).some((root) => isInside(resolved, root))) {
    throw new Error(`路径越界，不在允许的工作区中: ${resolved}`);
  }
  if (mustExist && !fs.existsSync(resolved)) throw new Error(`文件不存在: ${resolved}`);
  return resolved;
}

export function assertNoSecretFile(file) {
  const normalized = path.basename(file).toLowerCase();
  if (normalized === '.env' || normalized === 'secrets.json' || normalized.endsWith('.pem')) {
    throw new Error('该文件属于敏感配置，Worker 无权访问');
  }
}
