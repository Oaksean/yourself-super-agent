import { embedText, cosineSimilarity, EMBEDDING_DIM, isLocalEmbedder } from './local-embedder.mjs';

const MODEL_LOCAL = 'local-hash-384';

// EmbeddingService decides between a remote OpenAI-compatible embeddings
// endpoint (when one is configured) and the deterministic local embedder.
// Either way, every memory that enters the store is indexed so recall can be
// semantic instead of "most recent N".
export class EmbeddingService {
  constructor({ provider = {}, config = {}, logger } = {}) {
    this.provider = provider;
    this.config = config;
    this.logger = logger;
    this.dim = Number(config.memory?.embeddingDim) || EMBEDDING_DIM;
    this.remoteEnabled = Boolean(provider.apiKey && provider.embeddingModel && provider.baseUrl);
    this.remoteBroken = false;
  }

  get model() {
    return this.remoteEnabled && !this.remoteBroken ? `remote:${this.provider.embeddingModel}` : MODEL_LOCAL;
  }

  async embed(text) {
    if (this.remoteEnabled && !this.remoteBroken) {
      try {
        return await this.#remoteEmbed(text);
      } catch (error) {
        this.remoteBroken = true;
        this.logger?.warn(`向量端点不可用，回退到本地嵌入: ${error.message}`);
      }
    }
    return embedText(text, { dim: this.dim });
  }

  async embedMany(texts) {
    const result = [];
    for (const text of texts) result.push(await this.embed(text));
    return result;
  }

  similarity(a, b) { return cosineSimilarity(a, b); }

  async #remoteEmbed(text) {
    const base = String(this.provider.baseUrl).replace(/\/+$/, '').replace(/\/v\d+$/, '');
    const response = await fetch(`${base}/v1/embeddings`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${this.provider.apiKey}` },
      body: JSON.stringify({ model: this.provider.embeddingModel, input: String(text).slice(0, 8000) }),
    });
    if (!response.ok) throw new Error(`embeddings ${response.status}`);
    const data = await response.json();
    const vector = data.data?.[0]?.embedding;
    if (!Array.isArray(vector) || !vector.length) throw new Error('embeddings 响应缺少向量');
    return vector;
  }
}

export { MODEL_LOCAL, embedText, cosineSimilarity, isLocalEmbedder, EMBEDDING_DIM };
