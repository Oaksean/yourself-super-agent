import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

// Deterministic local embedder.
//
// It does NOT call a remote model. Instead it produces a fixed-dimension
// vector from character n-grams (hashed feature trick) mixed with token
// frequency and character-class weighting. Chinese text is covered by
// bigram/trigram features, so semantic-ish similarity works without a
// downloaded model, and the vectors are reproducible across restarts.
//
// If an embedding endpoint is configured later, EmbeddingService will prefer
// it and this becomes the offline fallback.

export const EMBEDDING_DIM = 384;

const CJK = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/;
const WORD = /[a-z0-9_]+/gi;

function normalize(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

function hashToIndex(token, dim) {
  const digest = createHash('sha1').update(token).digest();
  return digest.readUInt32BE(0) % dim;
}

function signFor(token) {
  const digest = createHash('sha1').update(`s:${token}`).digest();
  return digest[0] % 2 === 0 ? 1 : -1;
}

function addFeature(vector, token, weight) {
  if (!token) return;
  const index = hashToIndex(token, vector.length);
  vector[index] += signFor(token) * weight;
}

export function embedText(text, { dim = EMBEDDING_DIM } = {}) {
  const vector = new Float64Array(dim);
  const value = normalize(text);
  if (!value) return Array.from(vector);

  const words = value.match(WORD) || [];
  for (const word of words) {
    addFeature(vector, `w:${word}`, 1.4);
    if (word.length >= 4) {
      for (let i = 0; i <= word.length - 3; i += 1) addFeature(vector, `g3:${word.slice(i, i + 3)}`, 0.5);
    }
  }

  for (let i = 0; i < value.length; i += 1) {
    const char = value[i];
    if (char.trim() === '') continue;
    addFeature(vector, `c:${char}`, CJK.test(char) ? 0.5 : 0.2);
    if (i + 1 < value.length) {
      const pair = value.slice(i, i + 2);
      addFeature(vector, `b:${pair}`, CJK.test(pair) ? 1.1 : 0.35);
    }
    if (i + 2 < value.length) {
      const triple = value.slice(i, i + 3);
      if (CJK.test(triple)) addFeature(vector, `t:${triple}`, 0.7);
    }
  }

  let norm = 0;
  for (let i = 0; i < vector.length; i += 1) norm += vector[i] * vector[i];
  norm = Math.sqrt(norm);
  if (norm > 0) for (let i = 0; i < vector.length; i += 1) vector[i] /= norm;
  return Array.from(vector);
}

export function cosineSimilarity(a, b) {
  if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return 0;
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < a.length; i += 1) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  if (na === 0 || nb === 0) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

export function isLocalEmbedder() { return true; }
export { normalize };
