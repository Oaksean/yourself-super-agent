import path from 'node:path';
import readline from 'node:readline';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { nowIso } from './ids.mjs';
import { buildSandboxCommand, resolveSandbox } from './sandbox.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const runnerPath = path.resolve(__dirname, '..', 'worker', 'runner.mjs');

export class WorkerManager {
  constructor({ config, store, llm, events, logger, memory }) {
    this.config = config;
    this.store = store;
    this.llm = llm;
    this.events = events;
    this.logger = logger;
    this.memory = memory;
    this.queue = [];
    this.active = new Map();
    this.pendingApprovals = new Map();
    this.retryTimers = new Map();
    this.closed = false;
    this.sandbox = resolveSandbox(config, { logger });
    if (this.sandbox.tier === 'unavailable') {
      throw new Error(`无法启用所需的沙箱隔离: ${this.sandbox.reason}`);
    }
    logger?.info(`Worker 沙箱: ${this.sandbox.tier}${this.sandbox.host ? ` (${this.sandbox.host})` : ''}`);
  }

  enqueue(taskId) {
    const task = this.store.getTask(taskId);
    if (!task || ['completed', 'failed', 'cancelled'].includes(task.status)) return task;
    if (!this.queue.includes(taskId) && !this.active.has(taskId)) this.queue.push(taskId);
    this.events.emit({ type: 'task.queued', sessionId: task.sessionId, taskId: task.id, task });
    this.#drain();
    return task;
  }

  /** Requeue anything that was running or waiting when the Router stopped. */
  resumePendingTasks() {
    const pending = this.store.listTasks({ limit: 10000 })
      .filter((task) => ['queued', 'running', 'waiting_approval'].includes(task.status));
    for (const task of pending) {
      if (task.status === 'waiting_approval') this.store.expirePendingApprovalsForTask(task.id);
      this.store.updateTask(task.id, {
        status: 'queued',
        progress: '应用重启后自动恢复任务',
        error: null,
        worker_pid: null,
        started_at: null,
        finished_at: null,
        supervisor: {
          ...(task.supervisor || {}),
          recoveredAt: nowIso(),
          recoveryReason: 'Router 重启',
        },
      });
      this.store.addEvent({ type: 'task.recovered', sessionId: task.sessionId, taskId: task.id, payload: { reason: 'Router 重启' } });
      this.events.emit({ type: 'task.recovered', sessionId: task.sessionId, taskId: task.id, task: this.store.getTask(task.id) });
      this.enqueue(task.id);
    }
    if (pending.length) this.logger?.info(`已恢复 ${pending.length} 个未完成任务`);
    return pending.length;
  }

  #drain() {
    if (this.closed) return;
    while (this.active.size < this.config.maxWorkers && this.queue.length) {
      const taskId = this.queue.shift();
      this.#dispatch(taskId).catch((error) => this.#failTask(taskId, error));
    }
  }

  #dispatch(taskId) {
    const task = this.store.getTask(taskId);
    if (!task || ['completed', 'failed', 'cancelled'].includes(task.status)) return Promise.resolve();
    const launch = buildSandboxCommand({
      sandbox: this.sandbox,
      execPath: process.execPath,
      runnerPath,
      tier: task.isolation,
    });
    const child = spawn(launch.command, launch.args, {
      cwd: this.config.projectRoot,
      windowsHide: true,
      stdio: ['pipe', 'pipe', 'pipe'],
      env: {
        ...process.env,
        NODE_ENV: process.env.NODE_ENV || 'production',
        ...launch.env,
        SANDBOX_MEMORY_MB: this.config.sandboxMemoryMb ? String(this.config.sandboxMemoryMb) : '',
        SANDBOX_ALLOW_CHILDREN: this.config.sandboxAllowChildren === false ? '0' : '1',
        AGENT_ISOLATION_TIER: task.isolation || 'process-readonly',
        AGENT_TASK_HEARTBEAT_MS: String(this.config.taskHeartbeatMs || 10000),
      },
    });
    const record = {
      task,
      child,
      finished: false,
      lastActivity: Date.now(),
      lastHeartbeatEmitAt: 0,
      lastProgress: '',
      repeatedProgress: 0,
      startedAt: Date.now(),
      usage: { llmCalls: 0, promptTokens: 0, completionTokens: 0, totalTokens: 0 },
    };
    this.active.set(taskId, record);
    const attempt = Number(task.attempt) || 1;
    const maxAttempts = Number(task.maxAttempts || this.config.taskMaxAttempts || 3);
    const launchLabel = launch.sandboxed ? `Worker 已在 ${launch.tier} 沙箱中启动` : 'Worker 已启动（进程隔离）';
    const progressLabel = `第 ${attempt}/${maxAttempts} 次尝试 · ${launchLabel}`;
    this.store.updateTask(taskId, {
      status: 'running',
      started_at: nowIso(),
      last_heartbeat_at: nowIso(),
      worker_pid: child.pid,
      error: null,
      finished_at: null,
      progress: progressLabel,
    });
    this.events.emit({
      type: 'task.started',
      sessionId: task.sessionId,
      taskId,
      pid: child.pid,
      sandbox: launch.tier,
      attempt,
      maxAttempts,
      task: this.store.getTask(taskId),
    });

    const output = readline.createInterface({ input: child.stdout, crlfDelay: Infinity });
    output.on('line', (line) => {
      if (!line.trim()) return;
      record.lastActivity = Date.now();
      let message;
      try { message = JSON.parse(line); } catch (error) {
        this.logger.warn(`Worker ${taskId} 输出非 JSON: ${line.slice(0, 500)}`);
        return;
      }
      this.#handleWorkerMessage(record, message).catch((error) => this.#failTask(taskId, error));
    });
    child.stderr.on('data', (chunk) => this.logger.warn(`worker:${taskId} ${chunk.toString().trim()}`));
    child.on('error', (error) => this.#failTask(taskId, error));
    child.on('exit', (code, signal) => {
      if (record.finished) return;
      this.#failTask(taskId, new Error(`Worker 提前退出 (code=${code}, signal=${signal || 'none'})`));
    });

    const timer = setTimeout(() => {
      this.recover(taskId, `单轮执行超过 ${Math.round((this.config.taskTimeoutMs || 0) / 1000)} 秒`, {
        retryable: true,
        partialResult: record.partialResult || '',
      });
    }, this.config.taskTimeoutMs);
    timer.unref?.();
    record.timer = timer;
    scriptSend(child, {
      type: 'task',
      task,
      workspace: task.workspace || this.config.workspace,
      roots: this.config.allowedRoots,
    });
    return Promise.resolve();
  }

  async #handleWorkerMessage(record, message) {
    const taskId = record.task.id;
    switch (message.type) {
      case 'started':
        record.childPid = message.pid;
        this.store.updateTask(taskId, { worker_pid: message.pid || record.child.pid, last_heartbeat_at: nowIso() });
        break;
      case 'progress': {
        const progress = String(message.progress || '').slice(0, 500);
        if (progress && progress === record.lastProgress) record.repeatedProgress += 1;
        else { record.lastProgress = progress; record.repeatedProgress = 0; }
        record.lastActivity = Date.now();
        this.store.updateTask(taskId, { progress, last_heartbeat_at: nowIso() });
        this.events.emit({ type: 'task.progress', sessionId: record.task.sessionId, taskId, progress, detail: message.detail || '', task: this.store.getTask(taskId) });
        break;
      }
      case 'heartbeat': {
        const now = Date.now();
        record.lastActivity = now;
        if (message.progress) record.lastProgress = String(message.progress).slice(0, 500);
        this.store.updateTask(taskId, { last_heartbeat_at: nowIso() });
        if (now - record.lastHeartbeatEmitAt >= 15000) {
          record.lastHeartbeatEmitAt = now;
          this.events.emit({
            type: 'task.heartbeat',
            sessionId: record.task.sessionId,
            taskId,
            progress: message.progress || record.lastProgress || 'Worker 仍在执行',
            elapsedMs: message.elapsedMs || now - record.startedAt,
            task: this.store.getTask(taskId),
          });
        }
        break;
      }
      case 'llm_request': {
        try {
          const result = await this.llm.chat(message.messages || [], {
            ...(message.options || {}),
            model: message.options?.model || this.config.provider.workerModel,
          });
          record.usage.llmCalls += 1;
          record.usage.promptTokens += Number(result.usage?.prompt_tokens) || 0;
          record.usage.completionTokens += Number(result.usage?.completion_tokens) || 0;
          record.usage.totalTokens += Number(result.usage?.total_tokens) || 0;
          sendWorker(record.child, { type: 'llm_response', requestId: message.requestId, result });
        } catch (error) {
          sendWorker(record.child, { type: 'llm_response', requestId: message.requestId, error: error.message });
        }
        break;
      }
      case 'memory_search': {
        try {
          const result = await this.memory.workerSearch(message.query || '', {
            sessionId: record.task.sessionId,
            workspace: record.task.workspace || this.config.workspace,
            topK: Math.max(1, Math.min(12, Number(message.topK) || 6)),
          });
          sendWorker(record.child, { type: 'memory_response', requestId: message.requestId, result });
        } catch (error) {
          sendWorker(record.child, { type: 'memory_response', requestId: message.requestId, error: error.message });
        }
        break;
      }
      case 'memory_read_page': {
        try {
          const page = await this.memory.readPage(message.id || message.slug, record.task.workspace || this.config.workspace);
          if (!page) throw new Error('记忆 Wiki 页面不存在');
          sendWorker(record.child, { type: 'memory_response', requestId: message.requestId, result: page });
        } catch (error) {
          sendWorker(record.child, { type: 'memory_response', requestId: message.requestId, error: error.message });
        }
        break;
      }
      case 'transcript': {
        this.memory.captureTranscript({
          sessionId: record.task.sessionId,
          taskId: record.task.id,
          source: message.source || 'worker',
          content: message.content || '',
          metadata: message.metadata || {},
          workspace: record.task.workspace || this.config.workspace,
        });
        break;
      }
      case 'approval_request': {
        let approved = false;
        try {
          approved = await this.requestApproval(record.task, message.kind, message.details);
        } catch (error) {
          sendWorker(record.child, { type: 'approval_response', requestId: message.requestId, error: error.message });
          break;
        }
        sendWorker(record.child, { type: 'approval_response', requestId: message.requestId, approved });
        break;
      }
      case 'result':
        await this.#completeTask(taskId, message.result || '', message.metadata || {});
        break;
      case 'error':
        await this.#failTask(taskId, new Error(message.error || 'Worker 返回未知错误'));
        break;
      case 'cancelled':
        record.finished = true;
        break;
      default:
        this.logger.debug(`未处理的 Worker 消息: ${message.type}`);
    }
  }

  async #completeTask(taskId, result, metadata = {}) {
    const record = this.active.get(taskId);
    if (!record || record.finished) return;
    if (metadata.incomplete) {
      record.partialResult = String(result || '').slice(0, 500000);
      await this.recover(taskId, 'Worker 本轮仍未完成，自动续跑', { retryable: true, partialResult: record.partialResult });
      return;
    }
    record.finished = true;
    clearTimeout(record.timer);
    this.active.delete(taskId);
    const task = this.store.updateTask(taskId, {
      status: 'completed',
      result: String(result).slice(0, 500000),
      error: null,
      progress: metadata.fallback ? '完成（本地回退模式）' : '完成',
      last_heartbeat_at: nowIso(),
      finished_at: nowIso(),
      supervisor: {
        ...(record.task.supervisor || {}),
        completedAt: nowIso(),
        completedAttempt: record.task.attempt || 1,
        usage: mergeUsage(record.task.supervisor?.usage, record.usage),
      },
    });
    try { record.child.stdin.end(); } catch {}
    setTimeout(() => { try { record.child.kill(); } catch {} }, 500).unref?.();
    await this.memory.recordTaskResult(task);
    this.store.addEvent({
      type: 'task.completed',
      sessionId: task.sessionId,
      taskId,
      payload: { title: task.title, attempt: task.attempt, metadata },
    });
    this.events.emit({ type: 'task.completed', sessionId: task.sessionId, taskId, task });
    this.#drain();
  }

  async #failTask(taskId, error, options = {}) {
    await this.recover(taskId, error?.message || String(error), {
      retryable: options.retryable !== false,
      partialResult: options.partialResult || '',
    });
  }

  /** Stop one Worker and either queue the next supervised attempt or fail terminally. */
  async recover(taskId, reason, options = {}) {
    const record = this.active.get(taskId);
    if (record) {
      record.finished = true;
      clearTimeout(record.timer);
      this.active.delete(taskId);
      try { sendWorker(record.child, { type: 'cancel' }); } catch {}
      killTree(record.child);
    }
    const existing = this.store.getTask(taskId);
    if (!existing || ['completed', 'failed', 'cancelled'].includes(existing.status)) return existing;

    const reasonText = String(reason || '任务中断').slice(0, 4000);
    const attempt = Number(existing.attempt) || 1;
    const maxAttempts = Number(existing.maxAttempts || this.config.taskMaxAttempts || 3);
    const retryable = options.retryable !== false;
    if (!retryable || attempt >= maxAttempts) {
      const partial = String(options.partialResult || existing.result || '').slice(0, 500000);
      const task = this.store.updateTask(taskId, {
        status: 'failed',
        error: attempt >= maxAttempts ? `${reasonText}（已尝试 ${attempt}/${maxAttempts} 轮）` : reasonText,
        progress: '失败，需要处理',
        result: partial || existing.result,
        last_heartbeat_at: nowIso(),
        finished_at: nowIso(),
        supervisor: {
          ...(existing.supervisor || {}),
          failedAt: nowIso(),
          lastFailure: reasonText,
          exhausted: attempt >= maxAttempts,
          usage: mergeUsage(existing.supervisor?.usage, record?.usage),
        },
      });
      this.store.addEvent({ type: 'task.failed', sessionId: task.sessionId, taskId, payload: { error: task.error, attempt, maxAttempts } });
      this.events.emit({ type: 'task.failed', sessionId: task.sessionId, taskId, error: task.error, task });
      await this.memory.recordTaskResult(task);
      this.#drain();
      return task;
    }

    const nextAttempt = attempt + 1;
    const delayMs = Math.max(0, Number(this.config.taskRetryDelayMs) || 3000);
    const partial = String(options.partialResult || '').slice(0, 500000);
    const task = this.store.updateTask(taskId, {
      status: 'queued',
      attempt: nextAttempt,
      error: null,
      progress: `任务中断，${Math.round(delayMs / 1000)} 秒后自动恢复（第 ${nextAttempt}/${maxAttempts} 轮）`,
      result: partial || existing.result,
      worker_pid: null,
      started_at: null,
      finished_at: null,
      last_heartbeat_at: nowIso(),
      supervisor: {
        ...(existing.supervisor || {}),
        lastFailure: reasonText,
        lastFailureAt: nowIso(),
        nextAttempt,
        partialResult: partial ? partial.slice(0, 12000) : (existing.supervisor?.partialResult || ''),
        usage: mergeUsage(existing.supervisor?.usage, record?.usage),
      },
    });
    this.store.addEvent({ type: 'task.retrying', sessionId: task.sessionId, taskId, payload: { reason: reasonText, nextAttempt, maxAttempts, delayMs } });
    this.events.emit({ type: 'task.retrying', sessionId: task.sessionId, taskId, reason: reasonText, nextAttempt, maxAttempts, delayMs, task });
    this.logger?.warn(`任务 ${taskId} 自动恢复 ${attempt}->${nextAttempt}/${maxAttempts}: ${reasonText}`);

    const oldTimer = this.retryTimers.get(taskId);
    if (oldTimer) clearTimeout(oldTimer);
    const timer = setTimeout(() => {
      this.retryTimers.delete(taskId);
      this.enqueue(taskId);
    }, delayMs);
    timer.unref?.();
    this.retryTimers.set(taskId, timer);
    this.#drain();
    return task;
  }

  async requestApproval(task, kind, details) {
    if (kind === 'file_write' && this.config.autoApproveWorkspaceWrites) return true;
    if (kind === 'run_command' && this.config.autoApproveCommands) return true;
    const approval = this.store.createApproval({ taskId: task.id, sessionId: task.sessionId, kind, details });
    this.store.updateTask(task.id, { status: 'waiting_approval', progress: `等待审批: ${kind}`, last_heartbeat_at: nowIso() });
    this.store.addEvent({ type: 'approval.requested', sessionId: task.sessionId, taskId: task.id, payload: { approvalId: approval.id, kind, details } });
    this.events.emit({ type: 'approval.requested', sessionId: task.sessionId, taskId: task.id, approval, task: this.store.getTask(task.id) });
    return await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pendingApprovals.delete(approval.id);
        this.store.resolveApproval(approval.id, '超时未处理', 'expired');
        this.events.emit({ type: 'approval.expired', sessionId: task.sessionId, taskId: task.id, approvalId: approval.id });
        reject(new Error('审批等待超时'));
      }, 10 * 60 * 1000);
      timeout.unref?.();
      this.pendingApprovals.set(approval.id, { resolve, reject, timeout, taskId: task.id });
    });
  }

  resolveApproval(approvalId, resolution = '本次允许') {
    const pending = this.pendingApprovals.get(approvalId);
    const approval = this.store.getApproval(approvalId);
    if (!approval) return null;
    const normalizedResolution = String(resolution).trim().toLowerCase();
    const approved = !['denied', 'deny', 'reject', 'rejected', '拒绝', '不允许'].includes(normalizedResolution);
    this.store.resolveApproval(approvalId, resolution, approved ? 'approved' : 'denied');
    if (pending) {
      clearTimeout(pending.timeout);
      this.pendingApprovals.delete(approvalId);
      pending.resolve(approved);
      const task = this.store.getTask(approval.task_id);
      if (task && task.status === 'waiting_approval') {
        this.store.updateTask(task.id, { status: 'running', progress: approved ? '审批通过，继续执行' : '审批被拒绝', last_heartbeat_at: nowIso() });
      }
    }
    const updated = this.store.getApproval(approvalId);
    this.events.emit({ type: approved ? 'approval.approved' : 'approval.denied', sessionId: updated.session_id, taskId: updated.task_id, approval: updated });
    return updated;
  }

  retry(taskId, reason = '用户重新执行') {
    const task = this.store.getTask(taskId);
    if (!task) return null;
    if (['queued', 'running', 'waiting_approval'].includes(task.status)) return task;
    const oldTimer = this.retryTimers.get(taskId);
    if (oldTimer) clearTimeout(oldTimer);
    this.retryTimers.delete(taskId);
    const updated = this.store.updateTask(taskId, {
      status: 'queued',
      attempt: 1,
      maxAttempts: Number(task.maxAttempts || this.config.taskMaxAttempts || 3),
      error: null,
      progress: '已重新排队，进入自动监督',
      worker_pid: null,
      started_at: null,
      finished_at: null,
      last_heartbeat_at: nowIso(),
      supervisor: {
        ...(task.supervisor || {}),
        restartedAt: nowIso(),
        restartReason: reason,
        lastFailure: task.error || task.supervisor?.lastFailure || '',
      },
    });
    this.store.addEvent({ type: 'task.restarted', sessionId: task.sessionId, taskId, payload: { reason } });
    this.events.emit({ type: 'task.restarted', sessionId: task.sessionId, taskId, task: updated });
    this.enqueue(taskId);
    return updated;
  }
  cancel(taskId, reason = '用户取消') {
    const record = this.active.get(taskId);
    const task = this.store.getTask(taskId);
    if (!task) return null;
    const retryTimer = this.retryTimers.get(taskId);
    if (retryTimer) clearTimeout(retryTimer);
    this.retryTimers.delete(taskId);
    if (record) {
      sendWorker(record.child, { type: 'cancel' });
      setTimeout(() => killTree(record.child), 1000).unref?.();
      record.finished = true;
      clearTimeout(record.timer);
      this.active.delete(taskId);
    }
    for (const [approvalId, pending] of this.pendingApprovals) {
      if (pending.taskId !== taskId) continue;
      clearTimeout(pending.timeout);
      pending.reject(new Error('任务已取消'));
      this.pendingApprovals.delete(approvalId);
    }
    this.queue = this.queue.filter((id) => id !== taskId);
    const updated = this.store.updateTask(taskId, {
      status: 'cancelled',
      error: reason,
      progress: '已取消',
      worker_pid: null,
      finished_at: nowIso(),
      supervisor: { ...(task.supervisor || {}), cancelledAt: nowIso(), cancelReason: reason },
    });
    this.events.emit({ type: 'task.cancelled', sessionId: task.sessionId, taskId, task: updated });
    this.#drain();
    return updated;
  }

  snapshot() {
    return {
      active: [...this.active.keys()],
      queued: [...this.queue],
      retrying: [...this.retryTimers.keys()],
      pendingApprovals: [...this.pendingApprovals.keys()],
      sandbox: {
        tier: this.sandbox.tier,
        host: this.sandbox.host ? this.sandbox.host.split(/[\\/]/).pop() : null,
        mode: this.sandbox.mode || null,
        reason: this.sandbox.reason || null,
      },
    };
  }

  close() {
    this.closed = true;
    for (const timer of this.retryTimers.values()) clearTimeout(timer);
    this.retryTimers.clear();
    for (const [taskId, record] of this.active) {
      try { sendWorker(record.child, { type: 'cancel' }); } catch {}
      killTree(record.child);
      clearTimeout(record.timer);
      const task = this.store.getTask(taskId);
      if (!task || ['completed', 'failed', 'cancelled'].includes(task.status)) continue;
      this.store.updateTask(taskId, {
        status: 'queued',
        progress: 'Router 关闭，任务将在下次启动时自动恢复',
        worker_pid: null,
        started_at: null,
        last_heartbeat_at: nowIso(),
        supervisor: { ...(task.supervisor || {}), interruptedAt: nowIso(), interruptReason: 'Router 关闭' },
      });
      this.store.addEvent({ type: 'task.interrupted', sessionId: task.sessionId, taskId, payload: { reason: 'Router 关闭' } });
    }
    this.active.clear();
    this.queue = [];
  }
}

function mergeUsage(previous = {}, current = {}) {
  return {
    llmCalls: (Number(previous.llmCalls) || 0) + (Number(current.llmCalls) || 0),
    promptTokens: (Number(previous.promptTokens) || 0) + (Number(current.promptTokens) || 0),
    completionTokens: (Number(previous.completionTokens) || 0) + (Number(current.completionTokens) || 0),
    totalTokens: (Number(previous.totalTokens) || 0) + (Number(current.totalTokens) || 0),
  };
}
function sendWorker(child, message) {
  if (child?.stdin && !child.stdin.destroyed) child.stdin.write(`${JSON.stringify(message)}\n`);
}

function scriptSend(child, message) { sendWorker(child, message); }

function killTree(child) {
  if (!child || child.killed) return;
  if (process.platform === 'win32') {
    const killer = spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
    killer.unref?.();
  } else {
    child.kill('SIGKILL');
  }
}


