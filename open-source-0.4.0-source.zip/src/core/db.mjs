import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { nowIso, id } from './ids.mjs';

const json = (value, fallback = null) => {
  if (value == null) return fallback;
  try { return JSON.stringify(value); } catch { return fallback; }
};

function parse(value, fallback = null) {
  if (value == null || value === '') return fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}

export class AgentStore {
  constructor(file, options = {}) {
    this.file = file;
    this.workspace = options.workspace || null;
    this.closed = false;
    this.db = new DatabaseSync(file);
    this.db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
    this.#migrate();
  }

  #migrate() {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS sessions (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        summary TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS messages (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        metadata_json TEXT,
        created_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, created_at);
      CREATE TABLE IF NOT EXISTS tasks (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
        title TEXT NOT NULL,
        prompt TEXT NOT NULL,
        type TEXT NOT NULL,
        status TEXT NOT NULL,
        capabilities_json TEXT NOT NULL,
        isolation TEXT NOT NULL,
        workspace TEXT,
        expected_output TEXT,
        result TEXT,
        error TEXT,
        progress TEXT,
        worker_pid INTEGER,
        attempt INTEGER NOT NULL DEFAULT 1,
        max_attempts INTEGER NOT NULL DEFAULT 3,
        last_heartbeat_at TEXT,
        notified_at TEXT,
        supervisor_json TEXT NOT NULL DEFAULT '{}',
        run_id TEXT,
        agent_role TEXT,
        depends_on_json TEXT NOT NULL DEFAULT '[]',
        handoff_json TEXT NOT NULL DEFAULT '{}',
        verification_json TEXT NOT NULL DEFAULT '{}',
        collaboration_order INTEGER,
        created_at TEXT NOT NULL,
        started_at TEXT,
        finished_at TEXT
      );
      CREATE INDEX IF NOT EXISTS idx_tasks_session ON tasks(session_id, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status, created_at);
      CREATE TABLE IF NOT EXISTS memories (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
        kind TEXT NOT NULL,
        content TEXT NOT NULL,
        importance INTEGER NOT NULL DEFAULT 1,
        source_task_id TEXT,
        scope TEXT NOT NULL DEFAULT 'session',
        workspace TEXT,
        topic TEXT,
        status TEXT NOT NULL DEFAULT 'active',
        confidence REAL NOT NULL DEFAULT 0.6,
        access_count INTEGER NOT NULL DEFAULT 0,
        last_accessed_at TEXT,
        pinned INTEGER NOT NULL DEFAULT 0,
        source_type TEXT,
        source_json TEXT NOT NULL DEFAULT '{}',
        fingerprint TEXT,
        supersedes_json TEXT NOT NULL DEFAULT '[]',
        valid_until TEXT,
        dreamed_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_memories_session ON memories(session_id, updated_at DESC);
      CREATE TABLE IF NOT EXISTS events (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        session_id TEXT,
        task_id TEXT,
        payload_json TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_events_created ON events(created_at DESC);
      CREATE TABLE IF NOT EXISTS approvals (
        id TEXT PRIMARY KEY,
        task_id TEXT NOT NULL,
        session_id TEXT NOT NULL,
        kind TEXT NOT NULL,
        details_json TEXT NOT NULL,
        status TEXT NOT NULL,
        resolution TEXT,
        created_at TEXT NOT NULL,
        resolved_at TEXT
      );
      CREATE INDEX IF NOT EXISTS idx_approvals_status ON approvals(status, created_at);
      CREATE TABLE IF NOT EXISTS subscriptions (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL,
        task_id TEXT,
        source TEXT NOT NULL,
        matcher_json TEXT NOT NULL,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS memory_vectors (
        memory_id TEXT PRIMARY KEY REFERENCES memories(id) ON DELETE CASCADE,
        session_id TEXT NOT NULL,
        dim INTEGER NOT NULL,
        vector_json TEXT NOT NULL,
        model TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_memory_vectors_session ON memory_vectors(session_id);
      CREATE TABLE IF NOT EXISTS memory_chunks (
        id TEXT PRIMARY KEY,
        memory_id TEXT NOT NULL,
        session_id TEXT NOT NULL,
        chunk_index INTEGER NOT NULL,
        text TEXT NOT NULL,
        dim INTEGER NOT NULL,
        vector_json TEXT NOT NULL,
        model TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_memory_chunks_session ON memory_chunks(session_id);
      CREATE INDEX IF NOT EXISTS idx_memory_chunks_memory ON memory_chunks(memory_id);
      CREATE TABLE IF NOT EXISTS memory_transcripts (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL,
        task_id TEXT,
        source TEXT NOT NULL,
        content TEXT NOT NULL,
        metadata_json TEXT NOT NULL DEFAULT '{}',
        content_hash TEXT,
        workspace TEXT,
        created_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_memory_transcripts_session ON memory_transcripts(session_id, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_memory_transcripts_task ON memory_transcripts(task_id, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_memory_transcripts_hash ON memory_transcripts(content_hash);
      CREATE TABLE IF NOT EXISTS memory_pages (
        id TEXT PRIMARY KEY,
        workspace TEXT NOT NULL,
        slug TEXT NOT NULL,
        title TEXT NOT NULL,
        summary TEXT NOT NULL DEFAULT '',
        content_md TEXT NOT NULL,
        links_json TEXT NOT NULL DEFAULT '[]',
        source_memory_ids_json TEXT NOT NULL DEFAULT '[]',
        confidence REAL NOT NULL DEFAULT 0.6,
        status TEXT NOT NULL DEFAULT 'active',
        revision INTEGER NOT NULL DEFAULT 1,
        file_path TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE(workspace, slug)
      );
      CREATE INDEX IF NOT EXISTS idx_memory_pages_workspace ON memory_pages(workspace, status, updated_at DESC);
      CREATE TABLE IF NOT EXISTS memory_runs (
        id TEXT PRIMARY KEY,
        workspace TEXT NOT NULL,
        trigger TEXT NOT NULL,
        status TEXT NOT NULL,
        stats_json TEXT NOT NULL DEFAULT '{}',
        error TEXT,
        created_at TEXT NOT NULL,
        started_at TEXT,
        finished_at TEXT
      );
      CREATE INDEX IF NOT EXISTS idx_memory_runs_workspace ON memory_runs(workspace, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_memory_runs_status ON memory_runs(status, created_at DESC);
      CREATE TABLE IF NOT EXISTS memory_access_log (
        id TEXT PRIMARY KEY,
        memory_id TEXT NOT NULL,
        session_id TEXT,
        task_id TEXT,
        query TEXT,
        score REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_memory_access_memory ON memory_access_log(memory_id, created_at DESC);
      CREATE TABLE IF NOT EXISTS watcher_subscriptions (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL,
        path TEXT NOT NULL,
        pattern TEXT,
        events_json TEXT NOT NULL,
        recursive INTEGER NOT NULL DEFAULT 1,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS watcher_events (
        id TEXT PRIMARY KEY,
        subscription_id TEXT,
        path TEXT NOT NULL,
        event_type TEXT NOT NULL,
        payload_json TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_watcher_events_created ON watcher_events(created_at DESC);

      CREATE TABLE IF NOT EXISTS mas_runs (
        id TEXT PRIMARY KEY,
        session_id TEXT,
        template TEXT NOT NULL,
        topic TEXT NOT NULL,
        status TEXT NOT NULL,
        params_json TEXT NOT NULL DEFAULT '{}',
        state_json TEXT,
        metrics_json TEXT NOT NULL DEFAULT '{}',
        error TEXT,
        created_at TEXT NOT NULL,
        started_at TEXT,
        finished_at TEXT
      );
      CREATE INDEX IF NOT EXISTS idx_mas_runs_created ON mas_runs(created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_mas_runs_status ON mas_runs(status);
      CREATE TABLE IF NOT EXISTS mas_steps (
        id TEXT PRIMARY KEY,
        run_id TEXT NOT NULL,
        round INTEGER NOT NULL DEFAULT 1,
        node_id TEXT NOT NULL,
        label TEXT,
        role TEXT,
        status TEXT NOT NULL,
        attempts INTEGER,
        duration_ms INTEGER,
        summary TEXT,
        output_json TEXT,
        error TEXT,
        started_at TEXT,
        finished_at TEXT
      );
      CREATE INDEX IF NOT EXISTS idx_mas_steps_run ON mas_steps(run_id, round, started_at);
      CREATE TABLE IF NOT EXISTS mas_artifacts (
        id TEXT PRIMARY KEY,
        run_id TEXT NOT NULL,
        kind TEXT NOT NULL,
        name TEXT NOT NULL,
        path TEXT,
        content TEXT,
        created_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_mas_artifacts_run ON mas_artifacts(run_id, created_at);

      CREATE TABLE IF NOT EXISTS collaboration_runs (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
        title TEXT NOT NULL,
        goal TEXT NOT NULL,
        strategy TEXT NOT NULL DEFAULT 'coordinator',
        status TEXT NOT NULL,
        failure_policy TEXT NOT NULL DEFAULT 'continue',
        max_agents INTEGER NOT NULL DEFAULT 5,
        max_rounds INTEGER NOT NULL DEFAULT 2,
        timeout_ms INTEGER NOT NULL DEFAULT 3600000,
        plan_json TEXT NOT NULL DEFAULT '{}',
        metrics_json TEXT NOT NULL DEFAULT '{}',
        summary TEXT,
        error TEXT,
        created_at TEXT NOT NULL,
        started_at TEXT,
        finished_at TEXT
      );
      CREATE INDEX IF NOT EXISTS idx_collaboration_runs_session ON collaboration_runs(session_id, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_collaboration_runs_status ON collaboration_runs(status, created_at DESC);
    `);
    this.#ensureColumn('tasks', 'attempt', 'INTEGER NOT NULL DEFAULT 1');
    this.#ensureColumn('tasks', 'max_attempts', 'INTEGER NOT NULL DEFAULT 3');
    this.#ensureColumn('tasks', 'last_heartbeat_at', 'TEXT');
    this.#ensureColumn('tasks', 'notified_at', 'TEXT');
    this.#ensureColumn('tasks', 'supervisor_json', "TEXT NOT NULL DEFAULT '{}'");
    this.#ensureColumn('tasks', 'run_id', 'TEXT');
    this.#ensureColumn('tasks', 'agent_role', 'TEXT');
    this.#ensureColumn('tasks', 'depends_on_json', "TEXT NOT NULL DEFAULT '[]'");
    this.#ensureColumn('tasks', 'handoff_json', "TEXT NOT NULL DEFAULT '{}'");
    this.#ensureColumn('tasks', 'verification_json', "TEXT NOT NULL DEFAULT '{}'");
    this.#ensureColumn('tasks', 'collaboration_order', 'INTEGER');
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_tasks_run ON tasks(run_id, collaboration_order);');
    this.#ensureColumn('memories', 'scope', "TEXT NOT NULL DEFAULT 'session'");
    this.#ensureColumn('memories', 'workspace', 'TEXT');
    this.#ensureColumn('memories', 'topic', 'TEXT');
    this.#ensureColumn('memories', 'status', "TEXT NOT NULL DEFAULT 'active'");
    this.#ensureColumn('memories', 'confidence', 'REAL NOT NULL DEFAULT 0.6');
    this.#ensureColumn('memories', 'access_count', 'INTEGER NOT NULL DEFAULT 0');
    this.#ensureColumn('memories', 'last_accessed_at', 'TEXT');
    this.#ensureColumn('memories', 'pinned', 'INTEGER NOT NULL DEFAULT 0');
    this.#ensureColumn('memories', 'source_type', 'TEXT');
    this.#ensureColumn('memories', 'source_json', "TEXT NOT NULL DEFAULT '{}'");
    this.#ensureColumn('memories', 'fingerprint', 'TEXT');
    this.#ensureColumn('memories', 'supersedes_json', "TEXT NOT NULL DEFAULT '[]'");
    this.#ensureColumn('memories', 'valid_until', 'TEXT');
    this.#ensureColumn('memories', 'dreamed_at', 'TEXT');
    this.db.exec("CREATE INDEX IF NOT EXISTS idx_memories_workspace ON memories(workspace, status, updated_at DESC); CREATE INDEX IF NOT EXISTS idx_memories_scope ON memories(scope, status, confidence DESC); CREATE INDEX IF NOT EXISTS idx_memories_fingerprint ON memories(fingerprint);");
  }

  #ensureColumn(table, column, definition) {
    const columns = this.db.prepare(`PRAGMA table_info(${table})`).all();
    if (!columns.some((item) => item.name === column)) {
      this.db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
    }
  }

  createSession(title = '新会话') {
    const ts = nowIso();
    const session = { id: id('ses'), title: title.slice(0, 80), summary: '', created_at: ts, updated_at: ts };
    this.db.prepare('INSERT INTO sessions (id,title,summary,created_at,updated_at) VALUES (?,?,?,?,?)')
      .run(session.id, session.title, session.summary, session.created_at, session.updated_at);
    return session;
  }

  getSession(sessionId) {
    return this.db.prepare('SELECT * FROM sessions WHERE id = ?').get(sessionId) ?? null;
  }

  listSessions(limit = 50) {
    return this.db.prepare('SELECT * FROM sessions ORDER BY updated_at DESC LIMIT ?').all(limit);
  }

  touchSession(sessionId, patch = {}) {
    const current = this.getSession(sessionId);
    if (!current) return null;
    const title = patch.title ?? current.title;
    const summary = patch.summary ?? current.summary;
    this.db.prepare('UPDATE sessions SET title=?,summary=?,updated_at=? WHERE id=?')
      .run(title, summary, nowIso(), sessionId);
    return this.getSession(sessionId);
  }

  addMessage({ sessionId, role, content, metadata = null }) {
    const message = { id: id('msg'), session_id: sessionId, role, content, metadata, created_at: nowIso() };
    this.db.prepare('INSERT INTO messages (id,session_id,role,content,metadata_json,created_at) VALUES (?,?,?,?,?,?)')
      .run(message.id, sessionId, role, content, json(metadata), message.created_at);
    this.addTranscript({
      sessionId,
      source: `message.${role}`,
      content,
      metadata: { messageId: message.id, role, ...(metadata || {}) },
      workspace: this.workspace,
    });
    this.touchSession(sessionId);
    return message;
  }

  listMessages(sessionId, limit = 100) {
    return this.db.prepare('SELECT * FROM messages WHERE session_id=? ORDER BY created_at DESC LIMIT ?').all(sessionId, limit)
      .reverse().map((row) => ({ ...row, metadata: parse(row.metadata_json), metadata_json: undefined }));
  }

  recentMessages(sessionId, limit = 12) {
    return this.listMessages(sessionId, limit);
  }

  createTask(task) {
    const row = {
      id: id('task'),
      session_id: task.sessionId,
      title: task.title || '未命名任务',
      prompt: task.prompt,
      type: task.type || 'general',
      status: task.status || 'queued',
      capabilities: task.capabilities || ['read'],
      isolation: task.isolation || 'process-readonly',
      workspace: task.workspace || null,
      expected_output: task.expectedOutput || '',
      attempt: Number(task.attempt) || 1,
      max_attempts: Number(task.maxAttempts) || 3,
      supervisor: task.supervisor || {},
      run_id: task.runId || null,
      agent_role: task.agentRole || null,
      depends_on: task.dependsOn || [],
      handoff: task.handoff || {},
      verification: task.verification || {},
      collaboration_order: Number.isInteger(task.collaborationOrder) ? task.collaborationOrder : null,
      created_at: nowIso(),
    };
    this.db.prepare(`INSERT INTO tasks
      (id,session_id,title,prompt,type,status,capabilities_json,isolation,workspace,expected_output,attempt,max_attempts,supervisor_json,run_id,agent_role,depends_on_json,handoff_json,verification_json,collaboration_order,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(row.id, row.session_id, row.title, row.prompt, row.type, row.status, json(row.capabilities), row.isolation, row.workspace, row.expected_output, row.attempt, row.max_attempts, json(row.supervisor), row.run_id, row.agent_role, json(row.depends_on, '[]'), json(row.handoff, '{}'), json(row.verification, '{}'), row.collaboration_order, row.created_at);
    return this.getTask(row.id);
  }

  getTask(taskId) {
    const row = this.db.prepare('SELECT * FROM tasks WHERE id=?').get(taskId);
    return row ? this.#task(row) : null;
  }

  listTasks({ sessionId, status, runId, limit = 100 } = {}) {
    let sql = 'SELECT * FROM tasks WHERE 1=1';
    const args = [];
    if (sessionId) { sql += ' AND session_id=?'; args.push(sessionId); }
    if (status) { sql += ' AND status=?'; args.push(status); }
    if (runId) { sql += ' AND run_id=?'; args.push(runId); }
    sql += ' ORDER BY created_at DESC LIMIT ?';
    args.push(limit);
    return this.db.prepare(sql).all(...args).map((row) => this.#task(row));
  }

  listTasksByRun(runId) {
    return this.db.prepare('SELECT * FROM tasks WHERE run_id=? ORDER BY collaboration_order ASC, created_at ASC').all(runId)
      .map((row) => this.#task(row));
  }

  updateTask(taskId, patch) {
    const current = this.getTask(taskId);
    if (!current) return null;
    const merged = { ...current, ...patch };
    this.db.prepare(`UPDATE tasks SET
      title=?,prompt=?,type=?,status=?,capabilities_json=?,isolation=?,workspace=?,expected_output=?,
      result=?,error=?,progress=?,worker_pid=?,attempt=?,max_attempts=?,last_heartbeat_at=?,notified_at=?,supervisor_json=?,
      run_id=?,agent_role=?,depends_on_json=?,handoff_json=?,verification_json=?,collaboration_order=?,
      started_at=?,finished_at=? WHERE id=?`)
      .run(
        merged.title, merged.prompt, merged.type, merged.status, json(merged.capabilities),
        merged.isolation, merged.workspace, merged.expectedOutput, merged.result, merged.error,
        merged.progress, merged.worker_pid, merged.attempt, merged.maxAttempts, merged.last_heartbeat_at,
        merged.notified_at, json(merged.supervisor, '{}'), merged.runId || null, merged.agentRole || null,
        json(merged.dependsOn || [], '[]'), json(merged.handoff || {}, '{}'), json(merged.verification || {}, '{}'),
        Number.isInteger(merged.collaborationOrder) ? merged.collaborationOrder : null,
        merged.started_at, merged.finished_at, taskId,
      );
    return this.getTask(taskId);
  }

  #task(row) {
    return {
      id: row.id,
      sessionId: row.session_id,
      title: row.title,
      prompt: row.prompt,
      type: row.type,
      status: row.status,
      capabilities: parse(row.capabilities_json, []),
      isolation: row.isolation,
      workspace: row.workspace,
      expectedOutput: row.expected_output,
      result: row.result,
      error: row.error,
      progress: row.progress,
      worker_pid: row.worker_pid,
      attempt: row.attempt || 1,
      maxAttempts: row.max_attempts || 3,
      last_heartbeat_at: row.last_heartbeat_at,
      notified_at: row.notified_at,
      supervisor: parse(row.supervisor_json, {}),
      runId: row.run_id,
      agentRole: row.agent_role,
      dependsOn: parse(row.depends_on_json, []),
      handoff: parse(row.handoff_json, {}),
      verification: parse(row.verification_json, {}),
      collaborationOrder: row.collaboration_order,
      created_at: row.created_at,
      started_at: row.started_at,
      finished_at: row.finished_at,
    };
  }

  #mapMemory(row) {
    if (!row) return null;
    return {
      ...row,
      pinned: Boolean(row.pinned),
      source: parse(row.source_json, {}),
      supersedes: parse(row.supersedes_json, []),
      source_json: undefined,
      supersedes_json: undefined,
    };
  }

  addMemory({
    sessionId, kind = 'fact', content, importance = 1, sourceTaskId = null,
    scope = 'session', workspace = null, topic = null, status = 'active',
    confidence = 0.6, pinned = false, sourceType = null, source = {},
    fingerprint = null, supersedes = [], validUntil = null, dreamedAt = null,
  }) {
    const ts = nowIso();
    const row = {
      id: id('mem'), session_id: sessionId, kind, content, importance, source_task_id: sourceTaskId,
      scope, workspace, topic, status, confidence: Math.max(0, Math.min(1, Number(confidence) || 0.6)),
      access_count: 0, last_accessed_at: null, pinned: pinned ? 1 : 0, source_type: sourceType,
      source_json: json(source, '{}'), fingerprint, supersedes_json: json(supersedes, '[]'),
      valid_until: validUntil, dreamed_at: dreamedAt, created_at: ts, updated_at: ts,
    };
    this.db.prepare(`INSERT INTO memories (
      id,session_id,kind,content,importance,source_task_id,scope,workspace,topic,status,confidence,
      access_count,last_accessed_at,pinned,source_type,source_json,fingerprint,supersedes_json,
      valid_until,dreamed_at,created_at,updated_at
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(row.id, row.session_id, row.kind, row.content, row.importance, row.source_task_id, row.scope,
        row.workspace, row.topic, row.status, row.confidence, row.access_count, row.last_accessed_at,
        row.pinned, row.source_type, row.source_json, row.fingerprint, row.supersedes_json,
        row.valid_until, row.dreamed_at, row.created_at, row.updated_at);
    return this.getMemory(row.id);
  }

  getMemory(memoryId) {
    return this.#mapMemory(this.db.prepare('SELECT * FROM memories WHERE id=?').get(memoryId));
  }

  listMemories(sessionId, limit = 20) {
    return this.db.prepare('SELECT * FROM memories WHERE session_id=? ORDER BY importance DESC, updated_at DESC LIMIT ?')
      .all(sessionId, limit).map((row) => this.#mapMemory(row));
  }

  listMemoryRecords({ sessionId = null, workspace = null, status = 'active', scope = null, query = '', limit = 200 } = {}) {
    const clauses = [];
    const params = [];
    if (sessionId && workspace) {
      clauses.push("((scope='session' AND session_id=?) OR (scope IN ('project','global') AND workspace=?))");
      params.push(sessionId, workspace);
    } else if (sessionId) {
      clauses.push("(session_id=? OR scope IN ('project','global'))");
      params.push(sessionId);
    } else if (workspace) {
      clauses.push("workspace=?");
      params.push(workspace);
    }
    if (status && status !== 'all') {
      clauses.push('status=?');
      params.push(status);
    }
    if (scope && scope !== 'all') {
      clauses.push('scope=?');
      params.push(scope);
    }
    if (String(query || '').trim()) {
      const term = `%${String(query).trim().slice(0, 200)}%`;
      clauses.push('(content LIKE ? OR COALESCE(topic, \'\') LIKE ? OR kind LIKE ?)');
      params.push(term, term, term);
    }
    const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
    params.push(Math.max(1, Math.min(5000, Number(limit) || 200)));
    return this.db.prepare(`SELECT * FROM memories ${where}
      ORDER BY pinned DESC, importance DESC, confidence DESC, updated_at DESC LIMIT ?`)
      .all(...params).map((row) => this.#mapMemory(row));
  }

  findMemoryByFingerprint(fingerprint, { workspace = null, sessionId = null, scope = null } = {}) {
    if (!fingerprint) return null;
    const clauses = ['fingerprint=?', "status IN ('active','dormant')"];
    const params = [fingerprint];
    if (workspace) { clauses.push('workspace=?'); params.push(workspace); }
    if (sessionId) { clauses.push('session_id=?'); params.push(sessionId); }
    if (scope) { clauses.push('scope=?'); params.push(scope); }
    return this.#mapMemory(this.db.prepare(`SELECT * FROM memories WHERE ${clauses.join(' AND ')} ORDER BY updated_at DESC LIMIT 1`).get(...params));
  }

  updateMemory(memoryId, patch = {}) {
    const mapping = {
      kind: ['kind', (v) => String(v)],
      content: ['content', (v) => String(v)],
      importance: ['importance', (v) => Math.max(1, Math.min(5, Number(v) || 1))],
      scope: ['scope', (v) => ['session', 'project', 'global'].includes(v) ? v : 'session'],
      workspace: ['workspace', (v) => v || null],
      topic: ['topic', (v) => v ? String(v).slice(0, 120) : null],
      status: ['status', (v) => ['active', 'dormant', 'archived', 'superseded'].includes(v) ? v : 'active'],
      confidence: ['confidence', (v) => Math.max(0, Math.min(1, Number(v) || 0))],
      pinned: ['pinned', (v) => v ? 1 : 0],
      sourceType: ['source_type', (v) => v || null],
      source: ['source_json', (v) => json(v || {}, '{}')],
      fingerprint: ['fingerprint', (v) => v || null],
      supersedes: ['supersedes_json', (v) => json(v || [], '[]')],
      validUntil: ['valid_until', (v) => v || null],
      dreamedAt: ['dreamed_at', (v) => v || null],
      lastAccessedAt: ['last_accessed_at', (v) => v || null],
      accessCount: ['access_count', (v) => Math.max(0, Number(v) || 0)],
    };
    const sets = [];
    const params = [];
    for (const [key, value] of Object.entries(patch)) {
      const entry = mapping[key];
      if (!entry) continue;
      sets.push(`${entry[0]}=?`);
      params.push(entry[1](value));
    }
    if (!sets.length) return this.getMemory(memoryId);
    sets.push('updated_at=?');
    params.push(nowIso(), memoryId);
    this.db.prepare(`UPDATE memories SET ${sets.join(',')} WHERE id=?`).run(...params);
    return this.getMemory(memoryId);
  }

  deleteMemory(memoryId) {
    return this.db.prepare('DELETE FROM memories WHERE id=?').run(memoryId).changes;
  }

  logMemoryAccess({ memoryId, sessionId = null, taskId = null, query = '', score = 0 }) {
    const row = { id: id('mac'), memory_id: memoryId, session_id: sessionId, task_id: taskId, query: String(query || '').slice(0, 1000), score: Number(score) || 0, created_at: nowIso() };
    this.db.prepare('INSERT INTO memory_access_log (id,memory_id,session_id,task_id,query,score,created_at) VALUES (?,?,?,?,?,?,?)')
      .run(row.id, row.memory_id, row.session_id, row.task_id, row.query, row.score, row.created_at);
    this.db.prepare('UPDATE memories SET access_count=access_count+1,last_accessed_at=? WHERE id=?').run(row.created_at, memoryId);
    return row;
  }

  listMemoryChunksForMemories(memoryIds = [], { limit = 20000 } = {}) {
    const ids = [...new Set(memoryIds)].filter(Boolean);
    if (!ids.length) return [];
    const rows = [];
    for (let index = 0; index < ids.length; index += 400) {
      const batch = ids.slice(index, index + 400);
      const marks = batch.map(() => '?').join(',');
      rows.push(...this.db.prepare(`SELECT * FROM memory_chunks WHERE memory_id IN (${marks}) ORDER BY memory_id,chunk_index LIMIT ?`).all(...batch, Math.max(1, limit - rows.length)));
      if (rows.length >= limit) break;
    }
    return rows.map((row) => ({
      id: row.id, memory_id: row.memory_id, session_id: row.session_id, chunk_index: row.chunk_index,
      text: row.text, dim: row.dim, model: row.model, vector: parse(row.vector_json, []),
    }));
  }

  listMemoryVectorsForMemories(memoryIds = [], { limit = 10000 } = {}) {
    const ids = [...new Set(memoryIds)].filter(Boolean);
    if (!ids.length) return [];
    const rows = [];
    for (let index = 0; index < ids.length; index += 400) {
      const batch = ids.slice(index, index + 400);
      const marks = batch.map(() => '?').join(',');
      rows.push(...this.db.prepare(`SELECT * FROM memory_vectors WHERE memory_id IN (${marks}) ORDER BY created_at DESC LIMIT ?`).all(...batch, Math.max(1, limit - rows.length)));
      if (rows.length >= limit) break;
    }
    return rows.map((row) => ({
      memory_id: row.memory_id, session_id: row.session_id, dim: row.dim, model: row.model,
      vector: parse(row.vector_json, []),
    }));
  }

  addTranscript({ sessionId, taskId = null, source, content, metadata = {}, contentHash = null, workspace = null }) {
    const text = String(content || '');
    if (!sessionId || !source || !text.trim()) return null;
    const hash = contentHash || createHash('sha256').update(text).digest('hex');
    const row = {
      id: id('trn'), session_id: sessionId, task_id: taskId, source, content: text.slice(0, 1000000),
      metadata_json: json(metadata, '{}'), content_hash: hash, workspace, created_at: nowIso(),
    };
    this.db.prepare('INSERT INTO memory_transcripts (id,session_id,task_id,source,content,metadata_json,content_hash,workspace,created_at) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(row.id, row.session_id, row.task_id, row.source, row.content, row.metadata_json, row.content_hash, row.workspace, row.created_at);
    return { ...row, metadata: parse(row.metadata_json, {}), metadata_json: undefined };
  }

  listTranscripts({ sessionId = null, taskId = null, workspace = null, query = '', limit = 100 } = {}) {
    const clauses = [];
    const params = [];
    if (sessionId) { clauses.push('session_id=?'); params.push(sessionId); }
    if (taskId) { clauses.push('task_id=?'); params.push(taskId); }
    if (workspace) { clauses.push('workspace=?'); params.push(workspace); }
    if (String(query || '').trim()) { clauses.push('content LIKE ?'); params.push(`%${String(query).trim().slice(0, 200)}%`); }
    params.push(Math.max(1, Math.min(1000, Number(limit) || 100)));
    return this.db.prepare(`SELECT * FROM memory_transcripts ${clauses.length ? `WHERE ${clauses.join(' AND ')}` : ''} ORDER BY created_at DESC LIMIT ?`)
      .all(...params).map((row) => ({ ...row, metadata: parse(row.metadata_json, {}), metadata_json: undefined }));
  }

  countTranscripts(workspace = null) {
    return workspace
      ? this.db.prepare('SELECT COUNT(*) AS c FROM memory_transcripts WHERE workspace=?').get(workspace).c
      : this.db.prepare('SELECT COUNT(*) AS c FROM memory_transcripts').get().c;
  }

  upsertMemoryPage({ workspace, slug, title, summary = '', contentMd, links = [], sourceMemoryIds = [], confidence = 0.6, status = 'active', filePath = null }) {
    const now = nowIso();
    const existing = this.db.prepare('SELECT * FROM memory_pages WHERE workspace=? AND slug=?').get(workspace, slug);
    if (existing) {
      this.db.prepare(`UPDATE memory_pages SET title=?,summary=?,content_md=?,links_json=?,source_memory_ids_json=?,
        confidence=?,status=?,revision=revision+1,file_path=?,updated_at=? WHERE id=?`)
        .run(title, summary, contentMd, json(links, '[]'), json(sourceMemoryIds, '[]'), confidence, status, filePath, now, existing.id);
      return this.getMemoryPage(existing.id);
    }
    const row = {
      id: id('mpg'), workspace, slug, title, summary, content_md: contentMd, links_json: json(links, '[]'),
      source_memory_ids_json: json(sourceMemoryIds, '[]'), confidence, status, revision: 1, file_path: filePath,
      created_at: now, updated_at: now,
    };
    this.db.prepare(`INSERT INTO memory_pages (id,workspace,slug,title,summary,content_md,links_json,
      source_memory_ids_json,confidence,status,revision,file_path,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(row.id, row.workspace, row.slug, row.title, row.summary, row.content_md, row.links_json,
        row.source_memory_ids_json, row.confidence, row.status, row.revision, row.file_path, row.created_at, row.updated_at);
    return this.getMemoryPage(row.id);
  }

  #mapMemoryPage(row) {
    return row ? {
      ...row, links: parse(row.links_json, []), sourceMemoryIds: parse(row.source_memory_ids_json, []),
      links_json: undefined, source_memory_ids_json: undefined,
    } : null;
  }

  getMemoryPage(pageId) {
    return this.#mapMemoryPage(this.db.prepare('SELECT * FROM memory_pages WHERE id=?').get(pageId));
  }

  getMemoryPageBySlug(workspace, slug) {
    return this.#mapMemoryPage(this.db.prepare('SELECT * FROM memory_pages WHERE workspace=? AND slug=?').get(workspace, slug));
  }

  listMemoryPages(workspace, { status = 'active', limit = 200, withContent = false } = {}) {
    const rows = this.db.prepare(`SELECT * FROM memory_pages WHERE workspace=? ${status && status !== 'all' ? 'AND status=?' : ''}
      ORDER BY confidence DESC, updated_at DESC LIMIT ?`).all(workspace, ...(status && status !== 'all' ? [status, limit] : [limit]));
    return rows.map((row) => {
      const page = this.#mapMemoryPage(row);
      if (!withContent) page.content_md = undefined;
      return page;
    });
  }

  deleteMemoryPagesNotIn(workspace, slugs = []) {
    const keep = [...new Set(slugs)];
    if (!keep.length) return this.db.prepare('DELETE FROM memory_pages WHERE workspace=?').run(workspace).changes;
    const marks = keep.map(() => '?').join(',');
    return this.db.prepare(`DELETE FROM memory_pages WHERE workspace=? AND slug NOT IN (${marks})`).run(workspace, ...keep).changes;
  }

  createMemoryRun({ workspace, trigger = 'manual' }) {
    const row = { id: id('mrun'), workspace, trigger, status: 'queued', stats_json: '{}', error: null, created_at: nowIso(), started_at: null, finished_at: null };
    this.db.prepare('INSERT INTO memory_runs (id,workspace,trigger,status,stats_json,error,created_at,started_at,finished_at) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(row.id, row.workspace, row.trigger, row.status, row.stats_json, row.error, row.created_at, row.started_at, row.finished_at);
    return this.getMemoryRun(row.id);
  }

  getMemoryRun(runId) {
    const row = this.db.prepare('SELECT * FROM memory_runs WHERE id=?').get(runId);
    return row ? { ...row, stats: parse(row.stats_json, {}), stats_json: undefined } : null;
  }

  updateMemoryRun(runId, patch = {}) {
    const mapping = {
      status: ['status', (v) => String(v)],
      stats: ['stats_json', (v) => json(v || {}, '{}')],
      error: ['error', (v) => v || null],
      startedAt: ['started_at', (v) => v || null],
      finishedAt: ['finished_at', (v) => v || null],
    };
    const sets = [];
    const params = [];
    for (const [key, value] of Object.entries(patch)) {
      const entry = mapping[key];
      if (!entry) continue;
      sets.push(`${entry[0]}=?`);
      params.push(entry[1](value));
    }
    if (sets.length) this.db.prepare(`UPDATE memory_runs SET ${sets.join(',')} WHERE id=?`).run(...params, runId);
    return this.getMemoryRun(runId);
  }

  listMemoryRuns({ workspace = null, limit = 30 } = {}) {
    const rows = workspace
      ? this.db.prepare('SELECT * FROM memory_runs WHERE workspace=? ORDER BY created_at DESC LIMIT ?').all(workspace, limit)
      : this.db.prepare('SELECT * FROM memory_runs ORDER BY created_at DESC LIMIT ?').all(limit);
    return rows.map((row) => ({ ...row, stats: parse(row.stats_json, {}), stats_json: undefined }));
  }

  addEvent({ type, sessionId = null, taskId = null, payload = {} }) {
    const row = { id: id('evt'), type, session_id: sessionId, task_id: taskId, payload, created_at: nowIso() };
    this.db.prepare('INSERT INTO events (id,type,session_id,task_id,payload_json,created_at) VALUES (?,?,?,?,?,?)')
      .run(row.id, type, sessionId, taskId, json(payload), row.created_at);
    return row;
  }

  listEvents(limit = 100) {
    return this.db.prepare('SELECT * FROM events ORDER BY created_at DESC LIMIT ?').all(limit)
      .map((row) => ({ ...row, payload: parse(row.payload_json, {}), payload_json: undefined }));
  }

  createApproval({ taskId, sessionId, kind, details }) {
    const row = { id: id('apv'), task_id: taskId, session_id: sessionId, kind, details, status: 'pending', created_at: nowIso() };
    this.db.prepare('INSERT INTO approvals (id,task_id,session_id,kind,details_json,status,created_at) VALUES (?,?,?,?,?,?,?)')
      .run(row.id, row.task_id, row.session_id, row.kind, json(row.details), row.status, row.created_at);
    return row;
  }

  getApproval(approvalId) {
    const row = this.db.prepare('SELECT * FROM approvals WHERE id=?').get(approvalId);
    return row ? { ...row, details: parse(row.details_json, {}), details_json: undefined } : null;
  }

  listApprovals({ status, limit = 100 } = {}) {
    const sql = status
      ? 'SELECT * FROM approvals WHERE status=? ORDER BY created_at DESC LIMIT ?'
      : 'SELECT * FROM approvals ORDER BY created_at DESC LIMIT ?';
    const rows = status ? this.db.prepare(sql).all(status, limit) : this.db.prepare(sql).all(limit);
    return rows.map((row) => ({ ...row, details: parse(row.details_json, {}), details_json: undefined }));
  }

  resolveApproval(approvalId, resolution, status = 'approved') {
    this.db.prepare('UPDATE approvals SET status=?,resolution=?,resolved_at=? WHERE id=?').run(status, resolution || null, nowIso(), approvalId);
    return this.getApproval(approvalId);
  }

  // --- Vector memory -------------------------------------------------------

  upsertMemoryVector({ memoryId, sessionId, vector, model = 'local-hash-384' }) {
    const row = {
      memory_id: memoryId,
      session_id: sessionId,
      dim: vector.length,
      vector_json: JSON.stringify(vector),
      model,
      created_at: nowIso(),
    };
    this.db.prepare(`INSERT INTO memory_vectors (memory_id,session_id,dim,vector_json,model,created_at)
      VALUES (?,?,?,?,?,?)
      ON CONFLICT(memory_id) DO UPDATE SET vector_json=excluded.vector_json, dim=excluded.dim, model=excluded.model`)
      .run(row.memory_id, row.session_id, row.dim, row.vector_json, row.model, row.created_at);
    return row;
  }

  replaceMemoryChunks({ memoryId, sessionId, chunks, model = 'local-hash-384' }) {
    const deleteStmt = this.db.prepare('DELETE FROM memory_chunks WHERE memory_id=?');
    const insertStmt = this.db.prepare('INSERT INTO memory_chunks (id,memory_id,session_id,chunk_index,text,dim,vector_json,model,created_at) VALUES (?,?,?,?,?,?,?,?,?)');
    const ts = nowIso();
    deleteStmt.run(memoryId);
    chunks.forEach((chunk, index) => {
      insertStmt.run(id('chk'), memoryId, sessionId, index, chunk.text, chunk.vector.length, JSON.stringify(chunk.vector), model, ts);
    });
    return chunks.length;
  }

  listMemoryChunks(sessionId, { limit = 20000 } = {}) {
    const rows = this.db.prepare('SELECT * FROM memory_chunks WHERE session_id=? ORDER BY memory_id, chunk_index LIMIT ?').all(sessionId, limit);
    return rows.map((row) => ({
      id: row.id,
      memory_id: row.memory_id,
      session_id: row.session_id,
      chunk_index: row.chunk_index,
      text: row.text,
      dim: row.dim,
      model: row.model,
      vector: parse(row.vector_json, []),
    }));
  }

  countMemoryChunks(sessionId) {
    return this.db.prepare('SELECT COUNT(*) AS c FROM memory_chunks WHERE session_id=?').get(sessionId).c;
  }

  listMemoryVectors(sessionId, { limit = 2000 } = {}) {
    const rows = this.db.prepare('SELECT * FROM memory_vectors WHERE session_id=? ORDER BY created_at DESC LIMIT ?').all(sessionId, limit);
    return rows.map((row) => ({
      memory_id: row.memory_id,
      session_id: row.session_id,
      dim: row.dim,
      model: row.model,
      vector: parse(row.vector_json, []),
    }));
  }


  countMemoryVectors(sessionId) {
    return this.db.prepare('SELECT COUNT(*) AS c FROM memory_vectors WHERE session_id=?').get(sessionId).c;
  }

  // --- File watchers -------------------------------------------------------

  createWatcher({ sessionId, path, pattern = null, events = ['add', 'change'], recursive = true }) {
    const row = {
      id: id('watch'),
      session_id: sessionId,
      path,
      pattern,
      events,
      recursive: recursive ? 1 : 0,
      active: 1,
      created_at: nowIso(),
    };
    this.db.prepare('INSERT INTO watcher_subscriptions (id,session_id,path,pattern,events_json,recursive,active,created_at) VALUES (?,?,?,?,?,?,?,?)')
      .run(row.id, row.session_id, row.path, row.pattern, json(row.events), row.recursive, row.active, row.created_at);
    return { ...row, events, recursive: Boolean(row.recursive), active: true };
  }

  listWatchers({ activeOnly = true, sessionId = null } = {}) {
    let sql = 'SELECT * FROM watcher_subscriptions WHERE 1=1';
    const args = [];
    if (activeOnly) sql += ' AND active=1';
    if (sessionId) { sql += ' AND session_id=?'; args.push(sessionId); }
    sql += ' ORDER BY created_at DESC';
    return this.db.prepare(sql).all(...args).map((row) => ({
      ...row,
      events: parse(row.events_json, ['add', 'change']),
      events_json: undefined,
      recursive: Boolean(row.recursive),
      active: Boolean(row.active),
    }));
  }

  deactivateWatcher(watcherId) {
    this.db.prepare('UPDATE watcher_subscriptions SET active=0 WHERE id=?').run(watcherId);
    const row = this.db.prepare('SELECT * FROM watcher_subscriptions WHERE id=?').get(watcherId);
    return row ? { ...row, events: parse(row.events_json, []), recursive: Boolean(row.recursive), active: Boolean(row.active) } : null;
  }

  addWatcherEvent({ subscriptionId, path: eventPath, eventType, payload = {} }) {
    const row = { id: id('wevt'), subscription_id: subscriptionId, path: eventPath, event_type: eventType, payload, created_at: nowIso() };
    this.db.prepare('INSERT INTO watcher_events (id,subscription_id,path,event_type,payload_json,created_at) VALUES (?,?,?,?,?,?)')
      .run(row.id, row.subscription_id, row.path, row.event_type, json(row.payload), row.created_at);
    return row;
  }

  listWatcherEvents(limit = 100) {
    return this.db.prepare('SELECT * FROM watcher_events ORDER BY created_at DESC LIMIT ?').all(limit)
      .map((row) => ({ ...row, payload: parse(row.payload_json, {}), payload_json: undefined }));
  }

  createSubscription({ sessionId, taskId = null, source, matcher = {} }) {
    const row = { id: id('sub'), session_id: sessionId, task_id: taskId, source, matcher, active: 1, created_at: nowIso() };
    this.db.prepare('INSERT INTO subscriptions (id,session_id,task_id,source,matcher_json,active,created_at) VALUES (?,?,?,?,?,?,?)')
      .run(row.id, row.session_id, row.task_id, row.source, json(row.matcher), row.active, row.created_at);
    return row;
  }

  listSubscriptions({ activeOnly = true, sessionId = null } = {}) {
    let sql = 'SELECT * FROM subscriptions WHERE 1=1';
    const args = [];
    if (activeOnly) sql += ' AND active=1';
    if (sessionId) { sql += ' AND session_id=?'; args.push(sessionId); }
    sql += ' ORDER BY created_at DESC';
    return this.db.prepare(sql).all(...args).map((row) => ({ ...row, matcher: parse(row.matcher_json, {}), matcher_json: undefined, active: Boolean(row.active) }));
  }

  deactivateSubscription(subscriptionId) {
    this.db.prepare('UPDATE subscriptions SET active=0 WHERE id=?').run(subscriptionId);
    return this.listSubscriptions({ activeOnly: false }).find((item) => item.id === subscriptionId) || null;
  }

  expirePendingApprovalsForTask(taskId, resolution = '任务恢复，旧审批失效') {
    const now = nowIso();
    this.db.prepare("UPDATE approvals SET status='expired',resolution=?,resolved_at=? WHERE task_id=? AND status='pending'")
      .run(resolution, now, taskId);
    return this.db.prepare('SELECT * FROM approvals WHERE task_id=? ORDER BY created_at DESC').all(taskId)
      .map((row) => ({ ...row, details: parse(row.details_json, {}), details_json: undefined }));
  }

  // --- General coordinator-led collaboration --------------------------------

  createCollaborationRun({ sessionId, title, goal, strategy = 'coordinator', failurePolicy = 'continue', maxAgents = 5, maxRounds = 2, timeoutMs = 3600000, plan = {} }) {
    const row = {
      id: id('col'),
      session_id: sessionId,
      title: String(title || '多智能体协作').slice(0, 160),
      goal: String(goal || '').slice(0, 30000),
      strategy: String(strategy || 'coordinator').slice(0, 40),
      status: 'queued',
      failure_policy: failurePolicy === 'stop' ? 'stop' : 'continue',
      max_agents: Math.max(1, Math.min(5, Number(maxAgents) || 5)),
      max_rounds: Math.max(1, Math.min(5, Number(maxRounds) || 2)),
      timeout_ms: Math.max(30000, Number(timeoutMs) || 3600000),
      plan,
      metrics: {},
      created_at: nowIso(),
    };
    this.db.prepare(`INSERT INTO collaboration_runs
      (id,session_id,title,goal,strategy,status,failure_policy,max_agents,max_rounds,timeout_ms,plan_json,metrics_json,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(row.id, row.session_id, row.title, row.goal, row.strategy, row.status, row.failure_policy, row.max_agents, row.max_rounds, row.timeout_ms, json(row.plan, '{}'), '{}', row.created_at);
    return this.getCollaborationRun(row.id);
  }

  getCollaborationRun(runId) {
    const row = this.db.prepare('SELECT * FROM collaboration_runs WHERE id=?').get(runId);
    return row ? this.#collaborationRun(row) : null;
  }

  listCollaborationRuns({ sessionId, status, limit = 50 } = {}) {
    let sql = 'SELECT * FROM collaboration_runs WHERE 1=1';
    const args = [];
    if (sessionId) { sql += ' AND session_id=?'; args.push(sessionId); }
    if (status) { sql += ' AND status=?'; args.push(status); }
    sql += ' ORDER BY created_at DESC LIMIT ?';
    args.push(limit);
    return this.db.prepare(sql).all(...args).map((row) => this.#collaborationRun(row));
  }

  updateCollaborationRun(runId, patch) {
    const current = this.getCollaborationRun(runId);
    if (!current) return null;
    const merged = { ...current, ...patch };
    this.db.prepare(`UPDATE collaboration_runs SET
      title=?,goal=?,strategy=?,status=?,failure_policy=?,max_agents=?,max_rounds=?,timeout_ms=?,
      plan_json=?,metrics_json=?,summary=?,error=?,started_at=?,finished_at=? WHERE id=?`)
      .run(
        merged.title, merged.goal, merged.strategy, merged.status, merged.failurePolicy,
        merged.maxAgents, merged.maxRounds, merged.timeoutMs, json(merged.plan, '{}'),
        json(merged.metrics, '{}'), merged.summary ?? null, merged.error ?? null,
        merged.started_at ?? null, merged.finished_at ?? null, runId,
      );
    return this.getCollaborationRun(runId);
  }

  #collaborationRun(row) {
    return {
      id: row.id,
      sessionId: row.session_id,
      title: row.title,
      goal: row.goal,
      strategy: row.strategy,
      status: row.status,
      failurePolicy: row.failure_policy,
      maxAgents: row.max_agents,
      maxRounds: row.max_rounds,
      timeoutMs: row.timeout_ms,
      plan: parse(row.plan_json, {}),
      metrics: parse(row.metrics_json, {}),
      summary: row.summary,
      error: row.error,
      created_at: row.created_at,
      started_at: row.started_at,
      finished_at: row.finished_at,
    };
  }

  // --- Research-report multi-agent pipeline ---------------------------------

  createMasRun({ sessionId = null, template, topic, params = {} }) {
    const row = {
      id: id('mas'),
      session_id: sessionId,
      template,
      topic,
      status: 'queued',
      params,
      created_at: nowIso(),
    };
    this.db.prepare('INSERT INTO mas_runs (id,session_id,template,topic,status,params_json,metrics_json,created_at) VALUES (?,?,?,?,?,?,?,?)')
      .run(row.id, row.session_id, row.template, row.topic, row.status, json(row.params, '{}'), '{}', row.created_at);
    return this.getMasRun(row.id);
  }

  getMasRun(runId) {
    const row = this.db.prepare('SELECT * FROM mas_runs WHERE id=?').get(runId);
    return row ? this.#masRun(row) : null;
  }

  listMasRuns({ status, limit = 50 } = {}) {
    const sql = status
      ? 'SELECT * FROM mas_runs WHERE status=? ORDER BY created_at DESC LIMIT ?'
      : 'SELECT * FROM mas_runs ORDER BY created_at DESC LIMIT ?';
    const rows = status ? this.db.prepare(sql).all(status, limit) : this.db.prepare(sql).all(limit);
    return rows.map((row) => this.#masRun(row));
  }

  updateMasRun(runId, patch) {
    const current = this.getMasRun(runId);
    if (!current) return null;
    const merged = { ...current, ...patch };
    this.db.prepare(`UPDATE mas_runs SET status=?, params_json=?, state_json=?, metrics_json=?, error=?, started_at=?, finished_at=? WHERE id=?`)
      .run(
        merged.status,
        json(merged.params, '{}'),
        merged.state == null ? null : json(merged.state),
        json(merged.metrics, '{}'),
        merged.error ?? null,
        merged.started_at ?? null,
        merged.finished_at ?? null,
        runId,
      );
    return this.getMasRun(runId);
  }

  upsertMasStep({ runId, nodeId, round = 1, label = '', role = '', status, attempts = null, durationMs = null, summary = null, output = null, error = null, startedAt = null, finishedAt = null }) {
    const existing = this.db.prepare('SELECT * FROM mas_steps WHERE run_id=? AND node_id=? AND round=?').get(runId, nodeId, round);
    if (existing) {
      this.db.prepare(`UPDATE mas_steps SET label=?,role=?,status=?,attempts=?,duration_ms=?,summary=?,output_json=?,error=?,finished_at=? WHERE id=?`)
        .run(label || existing.label, role || existing.role, status,
          attempts ?? existing.attempts, durationMs ?? existing.duration_ms,
          summary ?? existing.summary,
          output === null ? existing.output_json : json(output),
          error ?? existing.error,
          finishedAt ?? existing.finished_at, existing.id);
      return this.db.prepare('SELECT * FROM mas_steps WHERE id=?').get(existing.id);
    }
    const row = {
      id: id('mstep'), run_id: runId, round, node_id: nodeId, label, role, status,
      attempts, duration_ms: durationMs, summary,
      output_json: output === null ? null : json(output), error,
      started_at: startedAt || nowIso(), finished_at: finishedAt,
    };
    this.db.prepare(`INSERT INTO mas_steps (id,run_id,round,node_id,label,role,status,attempts,duration_ms,summary,output_json,error,started_at,finished_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(row.id, row.run_id, row.round, row.node_id, row.label, row.role, row.status,
        row.attempts, row.duration_ms, row.summary, row.output_json, row.error, row.started_at, row.finished_at);
    return row;
  }

  listMasSteps(runId) {
    return this.db.prepare('SELECT * FROM mas_steps WHERE run_id=? ORDER BY round ASC, started_at ASC').all(runId)
      .map((row) => ({
        id: row.id,
        runId: row.run_id,
        round: row.round,
        nodeId: row.node_id,
        label: row.label,
        role: row.role,
        status: row.status,
        attempts: row.attempts,
        durationMs: row.duration_ms,
        summary: row.summary,
        output: parse(row.output_json, null),
        error: row.error,
        startedAt: row.started_at,
        finishedAt: row.finished_at,
      }));
  }

  addMasArtifact({ runId, kind, name, path = null, content = null }) {
    const row = { id: id('mart'), run_id: runId, kind, name, path, content, created_at: nowIso() };
    this.db.prepare('INSERT INTO mas_artifacts (id,run_id,kind,name,path,content,created_at) VALUES (?,?,?,?,?,?,?)')
      .run(row.id, row.run_id, row.kind, row.name, row.path, row.content, row.created_at);
    return row;
  }

  listMasArtifacts(runId) {
    return this.db.prepare('SELECT id,run_id,kind,name,path,created_at FROM mas_artifacts WHERE run_id=? ORDER BY created_at DESC').all(runId)
      .map((row) => ({ id: row.id, runId: row.run_id, kind: row.kind, name: row.name, path: row.path, createdAt: row.created_at }));
  }

  getMasArtifact(artifactId) {
    const row = this.db.prepare('SELECT * FROM mas_artifacts WHERE id=?').get(artifactId);
    return row ? { id: row.id, runId: row.run_id, kind: row.kind, name: row.name, path: row.path, content: row.content, createdAt: row.created_at } : null;
  }

  #masRun(row) {
    return {
      id: row.id,
      sessionId: row.session_id,
      template: row.template,
      topic: row.topic,
      status: row.status,
      params: parse(row.params_json, {}),
      state: parse(row.state_json, null),
      metrics: parse(row.metrics_json, {}),
      error: row.error,
      created_at: row.created_at,
      started_at: row.started_at,
      finished_at: row.finished_at,
    };
  }

  close() {
    if (this.closed) return;
    this.closed = true;
    this.db.close();
  }
}

export function openStore(config) {
  return new AgentStore(path.join(config.dataDir, 'agent.db'), { workspace: config.workspace });
}













