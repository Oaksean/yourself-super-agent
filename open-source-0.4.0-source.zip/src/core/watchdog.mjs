export class Watchdog {
  constructor({ manager, store, events, logger, intervalMs = 15000, stallMs = 180000 }) {
    this.manager = manager;
    this.store = store;
    this.events = events;
    this.logger = logger;
    this.intervalMs = intervalMs;
    this.stallMs = stallMs;
    this.timer = null;
    this.checking = false;
  }

  start() {
    if (this.timer) return;
    this.timer = setInterval(() => {
      if (!this.checking) this.check();
    }, this.intervalMs);
    this.timer.unref?.();
  }

  async check() {
    this.checking = true;
    try {
      const now = Date.now();
      for (const [taskId, record] of this.manager.active) {
        const idleMs = now - record.lastActivity;
        if (idleMs > this.stallMs) {
          const reason = `自动监督：Worker 已连续 ${Math.round(idleMs / 1000)} 秒无心跳`;
          this.store.addEvent({ type: 'watchdog.stall', sessionId: record.task.sessionId, taskId, payload: { idleMs, progress: record.lastProgress, action: 'retry' } });
          this.events.emit({ type: 'watchdog.alert', sessionId: record.task.sessionId, taskId, reason: 'stalled', idleMs, progress: record.lastProgress, action: 'retry' });
          await this.manager.recover(taskId, reason, { retryable: true, partialResult: record.partialResult || '' });
        } else if (record.repeatedProgress >= 8) {
          const reason = `自动监督：检测到重复进度，重启 Worker 换一种执行路径`;
          this.store.addEvent({ type: 'watchdog.loop', sessionId: record.task.sessionId, taskId, payload: { progress: record.lastProgress, repeats: record.repeatedProgress, action: 'retry' } });
          this.events.emit({ type: 'watchdog.alert', sessionId: record.task.sessionId, taskId, reason: 'loop', progress: record.lastProgress, action: 'retry' });
          await this.manager.recover(taskId, reason, { retryable: true, partialResult: record.partialResult || '' });
        }
      }
    } catch (error) {
      this.logger?.warn('Watchdog 自动恢复失败', error.message);
    } finally {
      this.checking = false;
    }
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }
}
