import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { publicConfig } from '../core/config.mjs';
import { createRuntime } from '../core/runtime.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const webRoot = path.resolve(__dirname, '..', 'web');
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon',
};

// The desktop shell (Tauri) loads the UI from the app bundle, so API calls
// arrive cross-origin from tauri://localhost. Only loopback origins are allowed.
function applyCors(req, res) {
  const origin = req.headers.origin || '';
  const allowed = !origin
    || /^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(origin)
    || /^tauri:\/\//.test(origin)
    || /^https?:\/\/tauri\.localhost$/.test(origin);
  if (allowed) {
    res.setHeader('access-control-allow-origin', origin || '*');
    res.setHeader('vary', 'origin');
    res.setHeader('access-control-allow-methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
    res.setHeader('access-control-allow-headers', 'content-type,authorization');
  }
  return allowed;
}

function json(res, status, value) {
  const body = JSON.stringify(value);
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body) });
  res.end(body);
}

async function body(req, limit = 2_000_000) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw new Error('请求体过大');
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw new Error('请求体不是有效 JSON'); }
}

function sessionDetail(store, sessionId) {
  const session = store.getSession(sessionId);
  if (!session) return null;
  return {
    session,
    messages: store.listMessages(sessionId, 500),
    tasks: store.listTasks({ sessionId, limit: 200 }),
    memories: store.listMemories(sessionId, 100),
    approvals: store.listApprovals({ limit: 200 }).filter((approval) => approval.session_id === sessionId),
    collaborations: store.listCollaborationRuns({ sessionId, limit: 100 }),
  };
}

export function createAgentServer({ runtime = createRuntime() } = {}) {
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, `http://${req.headers.host || '127.0.0.1'}`);
      const pathname = decodeURIComponent(url.pathname);

      applyCors(req, res);
      if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
      }

      if (pathname === '/api/events' && req.method === 'GET') {
        res.writeHead(200, {
          'content-type': 'text/event-stream; charset=utf-8',
          'cache-control': 'no-cache, no-transform',
          connection: 'keep-alive',
          'x-accel-buffering': 'no',
        });
        res.write(`event: ready\ndata: ${JSON.stringify({ ts: new Date().toISOString() })}\n\n`);
        const unsubscribe = runtime.events.subscribe((event) => res.write(`event: message\ndata: ${JSON.stringify(event)}\n\n`));
        const ping = setInterval(() => res.write(': ping\n\n'), 20000);
        req.on('close', () => { clearInterval(ping); unsubscribe(); });
        return;
      }

      if (pathname === '/api/health' && req.method === 'GET') return json(res, 200, runtime.status());
      if (pathname === '/api/status' && req.method === 'GET') return json(res, 200, runtime.status());
      if (pathname === '/api/config' && req.method === 'GET') return json(res, 200, publicConfig(runtime.config));
      if (pathname === '/api/config' && req.method === 'PUT') return json(res, 200, runtime.updateSettings(await body(req)));
      if (pathname === '/api/config/test' && req.method === 'POST') {
        const startedAt = Date.now();
        const model = runtime.config.provider.routerModel || runtime.config.provider.model;
        try {
          await runtime.llm.chat([
            { role: 'system', content: 'You are a connection test. Reply with exactly OK.' },
            { role: 'user', content: 'ping' },
          ], { model, temperature: 0, timeoutMs: 30000 });
          return json(res, 200, { ok: true, model, elapsedMs: Date.now() - startedAt });
        } catch (error) {
          return json(res, 502, { error: error.message || '模型连接测试失败', details: error.details || null });
        }
      }

      if (pathname === '/api/sessions' && req.method === 'GET') return json(res, 200, runtime.store.listSessions(100));
      if (pathname === '/api/sessions' && req.method === 'POST') {
        const payload = await body(req);
        return json(res, 201, runtime.store.createSession(payload.title || '新会话'));
      }

      const sessionMatch = pathname.match(/^\/api\/sessions\/([^/]+)$/);
      if (sessionMatch && req.method === 'GET') {
        const detail = sessionDetail(runtime.store, sessionMatch[1]);
        return detail ? json(res, 200, detail) : json(res, 404, { error: '会话不存在' });
      }

      if (pathname === '/api/chat' && req.method === 'POST') {
        const payload = await body(req);
        const result = await runtime.router.handleUserMessage({ sessionId: payload.sessionId, text: payload.text, source: 'user' });
        return json(res, 200, result);
      }

      if (pathname === '/api/tasks' && req.method === 'GET') {
        return json(res, 200, runtime.store.listTasks({ sessionId: url.searchParams.get('sessionId') || undefined, status: url.searchParams.get('status') || undefined, limit: 200 }));
      }
      const taskMatch = pathname.match(/^\/api\/tasks\/([^/]+)$/);
      if (taskMatch && req.method === 'GET') {
        const task = runtime.store.getTask(taskMatch[1]);
        return task ? json(res, 200, task) : json(res, 404, { error: '任务不存在' });
      }
      const retryMatch = pathname.match(/^\/api\/tasks\/([^/]+)\/retry$/);
      if (retryMatch && req.method === 'POST') {
        const task = runtime.manager.retry(retryMatch[1], '用户重新执行');
        return task ? json(res, 200, task) : json(res, 404, { error: '任务不存在' });
      }
      const cancelMatch = pathname.match(/^\/api\/tasks\/([^/]+)\/cancel$/);
      if (cancelMatch && req.method === 'POST') {
        const task = runtime.manager.cancel(cancelMatch[1], '用户取消');
        return task ? json(res, 200, task) : json(res, 404, { error: '任务不存在' });
      }

      if (pathname === '/api/approvals' && req.method === 'GET') {
        return json(res, 200, runtime.store.listApprovals({ status: url.searchParams.get('status') || undefined }));
      }
      const approvalMatch = pathname.match(/^\/api\/approvals\/([^/]+)\/resolve$/);
      if (approvalMatch && req.method === 'POST') {
        const payload = await body(req);
        const resolution = payload.resolution || (payload.approved ? '本次允许' : '拒绝');
        const approval = runtime.manager.resolveApproval(approvalMatch[1], resolution);
        return approval ? json(res, 200, approval) : json(res, 404, { error: '审批不存在' });
      }

      if (pathname === '/api/subscriptions' && req.method === 'GET') {
        return json(res, 200, runtime.store.listSubscriptions({ activeOnly: url.searchParams.get('all') !== '1', sessionId: url.searchParams.get('sessionId') || null }));
      }
      if (pathname === '/api/subscriptions' && req.method === 'POST') {
        const payload = await body(req);
        if (!payload.sessionId || !payload.source) return json(res, 400, { error: 'sessionId 和 source 必填' });
        return json(res, 201, runtime.store.createSubscription({ sessionId: payload.sessionId, taskId: payload.taskId, source: payload.source, matcher: payload.matcher || {} }));
      }
      const subscriptionDeleteMatch = pathname.match(/^\/api\/subscriptions\/([^/]+)$/);
      if (subscriptionDeleteMatch && req.method === 'DELETE') {
        const subscription = runtime.store.deactivateSubscription(subscriptionDeleteMatch[1]);
        return subscription ? json(res, 200, subscription) : json(res, 404, { error: '订阅不存在' });
      }

      if (pathname === '/api/watchers' && req.method === 'GET') {
        return json(res, 200, runtime.watchers.snapshot());
      }
      if (pathname === '/api/watchers' && req.method === 'POST') {
        const payload = await body(req);
        if (!payload.sessionId) return json(res, 400, { error: 'sessionId 必填' });
        try {
          const watcher = runtime.watchers.register({
            sessionId: payload.sessionId,
            path: payload.path || runtime.config.workspace,
            pattern: payload.pattern || null,
            events: payload.events,
            recursive: payload.recursive,
          });
          return json(res, 201, watcher);
        } catch (error) {
          return json(res, 400, { error: error.message });
        }
      }
      const watcherMatch = pathname.match(/^\/api\/watchers\/([^/]+)$/);
      if (watcherMatch && req.method === 'DELETE') {
        const watcher = runtime.watchers.unregister(watcherMatch[1]);
        return watcher ? json(res, 200, watcher) : json(res, 404, { error: '监听不存在' });
      }
      if (pathname === '/api/watcher-events' && req.method === 'GET') {
        return json(res, 200, runtime.store.listWatcherEvents(Number(url.searchParams.get('limit')) || 100));
      }

      // --- Long-term memory: transcripts -> notes -> wiki -> index --------
      if (pathname === '/api/memory/overview' && req.method === 'GET') {
        const workspace = url.searchParams.get('workspace') || runtime.config.workspace;
        return json(res, 200, await runtime.memory.overview(workspace, url.searchParams.get('sessionId')));
      }
      if (pathname === '/api/memory/search' && req.method === 'POST') {
        const payload = await body(req);
        if (!payload.sessionId || !payload.query) return json(res, 400, { error: 'sessionId 和 query 必填' });
        const results = await runtime.memory.recall(payload.sessionId, payload.query, {
          topK: payload.topK,
          minScore: payload.minScore,
          scope: payload.scope || null,
          workspace: payload.workspace || runtime.config.workspace,
        });
        return json(res, 200, { query: payload.query, results });
      }
      if (pathname === '/api/memory/records' && req.method === 'GET') {
        return json(res, 200, runtime.memory.listRecords({
          sessionId: url.searchParams.get('sessionId') || null,
          workspace: url.searchParams.get('workspace') || runtime.config.workspace,
          status: url.searchParams.get('status') || 'all',
          query: url.searchParams.get('query') || '',
          limit: Number(url.searchParams.get('limit')) || 200,
        }));
      }
      if (pathname === '/api/memory/records' && req.method === 'POST') {
        const payload = await body(req);
        try {
          const memory = await runtime.memory.remember({
            ...payload,
            workspace: payload.workspace || runtime.config.workspace,
            sourceType: payload.sourceType || 'ui',
          });
          return json(res, 201, memory);
        } catch (error) {
          return json(res, 400, { error: error.message });
        }
      }
      const memoryFeedbackMatch = pathname.match(/^\/api\/memory\/records\/([^/]+)\/feedback$/);
      if (memoryFeedbackMatch && req.method === 'POST') {
        const payload = await body(req);
        const memory = runtime.memory.settleMemoryFeedback(memoryFeedbackMatch[1], {
          helpful: payload.helpful !== false,
          amount: payload.amount,
        });
        return memory ? json(res, 200, memory) : json(res, 404, { error: '记忆不存在' });
      }
      const memoryRecordMatch = pathname.match(/^\/api\/memory\/records\/([^/]+)$/);
      if (memoryRecordMatch && req.method === 'PATCH') {
        const memory = await runtime.memory.updateMemory(memoryRecordMatch[1], await body(req));
        return memory ? json(res, 200, memory) : json(res, 404, { error: '记忆不存在' });
      }
      if (memoryRecordMatch && req.method === 'DELETE') {
        const deleted = runtime.memory.deleteMemory(memoryRecordMatch[1]);
        return deleted ? json(res, 200, { deleted: true }) : json(res, 404, { error: '记忆不存在' });
      }
      if (pathname === '/api/memory/transcripts' && req.method === 'GET') {
        return json(res, 200, runtime.memory.listTranscripts({
          sessionId: url.searchParams.get('sessionId') || null,
          taskId: url.searchParams.get('taskId') || null,
          workspace: url.searchParams.get('workspace') || runtime.config.workspace,
          query: url.searchParams.get('query') || '',
          limit: Number(url.searchParams.get('limit')) || 200,
        }));
      }
      if (pathname === '/api/memory/pages' && req.method === 'GET') {
        return json(res, 200, await runtime.memory.listPages(
          url.searchParams.get('workspace') || runtime.config.workspace,
          { status: url.searchParams.get('status') || 'all', withContent: url.searchParams.get('content') === '1' },
        ));
      }
      const memoryPageMatch = pathname.match(/^\/api\/memory\/pages\/([^/]+)$/);
      if (memoryPageMatch && req.method === 'GET') {
        const page = await runtime.memory.readPage(memoryPageMatch[1], url.searchParams.get('workspace') || runtime.config.workspace);
        return page ? json(res, 200, page) : json(res, 404, { error: '记忆页面不存在' });
      }
      if (pathname === '/api/memory/sync' && req.method === 'POST') {
        return json(res, 200, await runtime.memory.syncIndex(runtime.config.workspace));
      }
      if (pathname === '/api/memory/dream' && req.method === 'POST') {
        const payload = await body(req);
        const run = runtime.memory.startDream(payload.workspace || runtime.config.workspace, payload.trigger || 'manual');
        return json(res, 202, run);
      }
      if (pathname === '/api/memory/runs' && req.method === 'GET') {
        return json(res, 200, runtime.store.listMemoryRuns({
          workspace: url.searchParams.get('workspace') || runtime.config.workspace,
          limit: Number(url.searchParams.get('limit')) || 30,
        }));
      }
      if (pathname === '/api/memory/backfill' && req.method === 'POST') {
        const payload = await body(req);
        const count = await runtime.memory.backfill(payload.sessionId || null, { workspace: payload.workspace || runtime.config.workspace });
        return json(res, 200, { indexed: count });
      }
      if (pathname === '/api/memory/stats' && req.method === 'GET') {
        const sessionId = url.searchParams.get('sessionId');
        if (!sessionId) return json(res, 400, { error: 'sessionId 必填' });
        return json(res, 200, runtime.memory.stats(sessionId));
      }

      if (pathname === '/api/triggers' && req.method === 'POST') {
        const payload = await body(req);
        const result = await runtime.router.handleExternalTrigger({
          sessionId: payload.sessionId,
          text: payload.text,
          source: payload.source || 'external',
          metadata: payload.metadata || {},
        });
        return json(res, 200, result);
      }

      // --- Coordinator-led task collaboration ----------------------------
      if (pathname === '/api/collaborations' && req.method === 'GET') {
        return json(res, 200, runtime.store.listCollaborationRuns({
          sessionId: url.searchParams.get('sessionId') || undefined,
          status: url.searchParams.get('status') || undefined,
          limit: Number(url.searchParams.get('limit')) || 50,
        }));
      }
      const collaborationMatch = pathname.match(/^\/api\/collaborations\/([^/]+)$/);
      if (collaborationMatch && req.method === 'GET') {
        const detail = runtime.collaboration.detail(collaborationMatch[1]);
        return detail ? json(res, 200, detail) : json(res, 404, { error: '协作运行不存在' });
      }
      const collaborationCancelMatch = pathname.match(/^\/api\/collaborations\/([^/]+)\/cancel$/);
      if (collaborationCancelMatch && req.method === 'POST') {
        const run = await runtime.collaboration.cancel(collaborationCancelMatch[1]);
        return run ? json(res, 200, run) : json(res, 404, { error: '协作运行不存在' });
      }
      const collaborationRetryMatch = pathname.match(/^\/api\/collaborations\/([^/]+)\/retry$/);
      if (collaborationRetryMatch && req.method === 'POST') {
        try {
          const created = await runtime.collaboration.retry(collaborationRetryMatch[1]);
          return created ? json(res, 201, created) : json(res, 404, { error: '协作运行不存在' });
        } catch (error) {
          return json(res, 400, { error: error.message });
        }
      }

      // --- Research-report MAS pipeline ----------------------------------
      if (pathname === '/api/mas/templates' && req.method === 'GET') {
        return json(res, 200, runtime.mas.templates());
      }
      if (pathname === '/api/mas/runs' && req.method === 'GET') {
        return json(res, 200, runtime.store.listMasRuns({
          status: url.searchParams.get('status') || undefined,
          limit: Number(url.searchParams.get('limit')) || 50,
        }));
      }
      if (pathname === '/api/mas/runs' && req.method === 'POST') {
        const payload = await body(req);
        try {
          const run = runtime.mas.createRun(payload);
          return json(res, 201, run);
        } catch (error) {
          return json(res, 400, { error: error.message });
        }
      }
      const masRunMatch = pathname.match(/^\/api\/mas\/runs\/([^/]+)$/);
      if (masRunMatch && req.method === 'GET') {
        const detail = runtime.mas.detail(masRunMatch[1]);
        return detail ? json(res, 200, detail) : json(res, 404, { error: '协同运行不存在' });
      }
      const masCancelMatch = pathname.match(/^\/api\/mas\/runs\/([^/]+)\/cancel$/);
      if (masCancelMatch && req.method === 'POST') {
        const run = runtime.mas.cancel(masCancelMatch[1]);
        return run ? json(res, 200, run) : json(res, 404, { error: '协同运行不存在' });
      }
      const masRetryMatch = pathname.match(/^\/api\/mas\/runs\/([^/]+)\/retry$/);
      if (masRetryMatch && req.method === 'POST') {
        try {
          const run = runtime.mas.retry(masRetryMatch[1]);
          return run ? json(res, 201, run) : json(res, 404, { error: '协同运行不存在' });
        } catch (error) {
          return json(res, 400, { error: error.message });
        }
      }
      const masReportMatch = pathname.match(/^\/api\/mas\/runs\/([^/]+)\/report$/);
      if (masReportMatch && req.method === 'GET') {
        const report = runtime.mas.report(masReportMatch[1]);
        return report ? json(res, 200, report) : json(res, 404, { error: '尚未生成报告' });
      }
      const masArtifactMatch = pathname.match(/^\/api\/mas\/artifacts\/([^/]+)$/);
      if (masArtifactMatch && req.method === 'GET') {
        const artifact = runtime.store.getMasArtifact(masArtifactMatch[1]);
        return artifact ? json(res, 200, artifact) : json(res, 404, { error: '产物不存在' });
      }

      if (pathname.startsWith('/api/')) return json(res, 404, { error: 'API 不存在' });

      let filePath = pathname === '/' ? path.join(webRoot, 'index.html') : path.join(webRoot, pathname.replace(/^\/+/, ''));
      const resolved = path.resolve(filePath);
      const relativeWebPath = path.relative(webRoot, resolved);
      if (relativeWebPath.startsWith('..') || path.isAbsolute(relativeWebPath)) return json(res, 403, { error: '非法路径' });
      if (!fs.existsSync(resolved) || fs.statSync(resolved).isDirectory()) filePath = path.join(webRoot, 'index.html');
      const data = fs.readFileSync(filePath);
      res.writeHead(200, { 'content-type': MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream', 'content-length': data.length });
      res.end(data);
    } catch (error) {
      runtime.logger.error('HTTP 请求失败', error);
      if (!res.headersSent) json(res, 500, { error: error.message || '服务器内部错误' });
      else res.end();
    }
  });

  return {
    runtime,
    server,
    listen() {
      runtime.start();
      return new Promise((resolve, reject) => {
        server.once('error', reject);
        server.listen(runtime.config.port, runtime.config.host, () => {
          server.off('error', reject);
          const address = server.address();
          const port = typeof address === 'object' && address ? address.port : runtime.config.port;
          resolve(`http://${runtime.config.host}:${port}`);
        });
      });
    },
    close() {
      return new Promise((resolve) => {
        server.close(() => {
          Promise.resolve(runtime.close())
            .catch((error) => runtime.logger.error('运行时关闭失败', error))
            .finally(resolve);
        });
      });
    },
  };
}







