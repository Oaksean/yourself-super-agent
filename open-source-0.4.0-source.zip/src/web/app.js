const $ = (selector) => document.querySelector(selector);
const state = { sessions: [], currentSessionId: null, messages: [], tasks: [], approvals: [], memories: [], collaborations: [], config: null, busy: false, sandbox: null, watchers: null, memoryStats: null, memory: { overview: null, records: [], pages: [], transcripts: [], runs: [], tab: 'notes', query: '', searchActive: false, searchQuery: '', loading: false, openPage: null }, mas: { templates: [], runs: [], openRunId: null, detail: null, report: null, loading: false } };

// When served by the desktop shell the UI is loaded from tauri://localhost,
// so API calls must be addressed to the Router's loopback port explicitly.
// In a plain browser the same-origin relative path is used instead.
const ROUTER_ORIGIN = (() => {
  if (location.protocol === 'tauri:' || location.hostname === 'tauri.localhost') return 'http://127.0.0.1:4317';
  if (location.port && location.port !== '4317') return `http://127.0.0.1:4317`;
  return '';
})();

function apiUrl(path) {
  return ROUTER_ORIGIN ? `${ROUTER_ORIGIN}${path}` : path;
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(apiUrl(path), { headers: { 'content-type': 'application/json', ...(options.headers || {}) }, ...options });
  } catch {
    throw new Error('无法连接本地 Router，请稍候重试；若持续失败，请重启应用');
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `请求失败 (${response.status})`);
  return data;
}

function isTauriShell() {
  return Boolean(window.__TAURI_INTERNALS__) || location.hostname === 'tauri.localhost';
}

async function invokeDesktop(command, args = {}) {
  const invoke = window.__TAURI_INTERNALS__?.invoke;
  if (typeof invoke !== 'function') throw new Error('当前浏览器模式不支持原生文件夹选择，请从桌面应用操作');
  return await invoke(command, args);
}

// The desktop window can finish loading before the bundled Router starts
// listening. Wait briefly so the first render reads the real provider state
// instead of showing a misleading "not configured" badge until manual refresh.
async function waitForRouter(timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs;
  let lastError;
  while (Date.now() < deadline) {
    try {
      await api('/api/health');
      return;
    } catch (error) {
      lastError = error;
      await new Promise((resolve) => setTimeout(resolve, 250));
    }
  }
  throw new Error(`无法连接本地 Router：${lastError?.message || '启动超时'}`);
}
function escapeText(value) { return String(value ?? ''); }
function formatTime(value) { return value ? new Date(value).toLocaleString('zh-CN', { hour12: false }) : ''; }
function statusLabel(status) {
  return ({ blocked: '等待依赖', queued: '排队', running: '运行中', waiting_approval: '待审批', completed: '完成', partial: '部分完成', failed: '失败', cancelled: '已取消' })[status] || status;
}

async function loadConfig() {
  state.config = await api('/api/config');
  const p = state.config.provider;
  $('#provider-badge').textContent = p.hasApiKey ? `${p.routerModel}` : '未配置模型';
  $('#provider-badge').classList.toggle('ready', p.hasApiKey);
  const form = $('#settings-form');
  form.elements.baseUrl.value = p.baseUrl || '';
  form.elements.routerModel.value = p.routerModel || '';
  form.elements.workerModel.value = p.workerModel || '';
  form.elements.autoApproveWorkspaceWrites.checked = Boolean(state.config.autoApproveWorkspaceWrites);
  form.elements.autoApproveCommands.checked = Boolean(state.config.autoApproveCommands);
  form.elements.sandboxMode.value = state.config.sandboxMode || 'auto';
  if (form.elements.dreamingEnabled) form.elements.dreamingEnabled.checked = state.config.memory?.dreaming?.enabled !== false;
  if (form.elements.dreamingInterval) form.elements.dreamingInterval.value = state.config.memory?.dreaming?.intervalHours || 6;
  renderWorkspace();
}

function workspaceName(value) {
  const parts = String(value || '').split(/[\\/]+/).filter(Boolean);
  return parts[parts.length - 1] || value || '未选择';
}

function renderWorkspace() {
  const workspace = state.config?.workspace || '';
  const name = workspaceName(workspace);
  const nameNode = $('#workspace-name');
  const pathNode = $('#workspace-path');
  const permission = $('#workspace-permission');
  const autoWrite = $('#auto-write-toggle');
  if (nameNode) nameNode.textContent = name;
  if (pathNode) pathNode.textContent = workspace || '尚未选择任务文件夹';
  const selector = $('#choose-workspace');
  if (selector) selector.title = workspace ? `当前任务文件夹：${workspace}\n点击更换` : '选择任务文件夹';
  if (permission) {
    permission.textContent = state.config?.autoApproveWorkspaceWrites ? '读写已授权' : '写入需审批';
    permission.classList.toggle('write', Boolean(state.config?.autoApproveWorkspaceWrites));
  }
  if (autoWrite) autoWrite.checked = Boolean(state.config?.autoApproveWorkspaceWrites);
}

async function chooseTaskFolder() {
  const current = state.config?.workspace || '';
  let selected;
  if (isTauriShell()) {
    try {
      selected = await invokeDesktop('select_task_folder', { current });
    } catch (error) {
      selected = window.prompt(`原生文件夹选择器不可用（${error.message}）。\n请输入任务文件夹的完整路径：`, current);
    }
  } else {
    selected = window.prompt('请输入任务文件夹的完整路径（例如 D:\\工程文件\\项目）', current);
  }
  if (!selected) return;
  await api('/api/config', { method: 'PUT', body: JSON.stringify({ workspace: selected }) });
  await loadConfig();
  toast(`任务文件夹已切换：${workspaceName(selected)}`);
}

async function setWorkspaceWriteAccess(enabled) {
  await api('/api/config', {
    method: 'PUT',
    body: JSON.stringify({ autoApproveWorkspaceWrites: Boolean(enabled) }),
  });
  await loadConfig();
  toast(enabled ? '已允许自动写入当前任务文件夹' : '文件写入将逐次等待审批');
}

async function openTaskFolder() {
  const workspace = state.config?.workspace;
  if (!workspace) throw new Error('尚未选择任务文件夹');
  if (!isTauriShell()) throw new Error('请在桌面应用中打开任务文件夹');
  await invokeDesktop('open_task_folder', { path: workspace });
}

async function loadSessions() {
  state.sessions = await api('/api/sessions');
  renderSessions();
}

async function loadSession(sessionId) {
  if (!sessionId) return;
  state.currentSessionId = sessionId;
  const detail = await api(`/api/sessions/${encodeURIComponent(sessionId)}`);
  state.messages = detail.messages;
  state.tasks = detail.tasks;
  state.approvals = detail.approvals.filter((approval) => approval.status === 'pending');
  state.memories = detail.memories;
  state.collaborations = detail.collaborations || [];
  $('#session-title').textContent = detail.session.title;
  $('#session-subtitle').textContent = `会话 ${detail.session.id} · ${detail.messages.length} 条消息`;
  renderAll();
  loadSystem();
  if ($('#panel-memory')?.classList.contains('active')) loadMemoryCenter().catch((error) => toast(error.message));
}

async function refresh() {
  try {
    await loadConfig();
    await loadSessions();
    if (state.currentSessionId) await loadSession(state.currentSessionId);
    await loadTasks();
    await loadCollaborations();
    await loadSystem();
    await loadMas();
  } catch (error) { toast(error.message); }
}

async function loadTasks() {
  state.tasks = await api(`/api/tasks${state.currentSessionId ? `?sessionId=${encodeURIComponent(state.currentSessionId)}` : ''}`);
  state.approvals = (await api('/api/approvals?status=pending')).filter((item) => !state.currentSessionId || item.session_id === state.currentSessionId);
  renderInspector();
}

async function loadSystem() {
  try {
    const health = await api('/api/health');
    state.sandbox = health.sandbox;
    state.watchers = health.watchers;
    state.memoryStats = state.currentSessionId ? await api(`/api/memory/stats?sessionId=${encodeURIComponent(state.currentSessionId)}`) : null;
    renderSystem(); renderWatchers();
  } catch (error) { /* health polling is best-effort */ }
}

function renderSessions() {
  const root = $('#sessions');
  root.replaceChildren();
  if (!state.sessions.length) {
    const empty = document.createElement('div'); empty.className = 'empty-mini'; empty.textContent = '还没有会话'; root.append(empty); return;
  }
  for (const session of state.sessions) {
    const button = document.createElement('button');
    button.className = `session-item ${session.id === state.currentSessionId ? 'active' : ''}`;
    const title = document.createElement('strong'); title.textContent = session.title;
    const meta = document.createElement('span'); meta.textContent = formatTime(session.updated_at);
    button.append(title, meta);
    button.addEventListener('click', () => loadSession(session.id).catch((error) => toast(error.message)));
    root.append(button);
  }
}

function renderMessages() {
  const root = $('#messages');
  root.replaceChildren();
  if (!state.messages.length) {
    const empty = document.createElement('div'); empty.className = 'empty-state';
    empty.innerHTML = '<div class="orb"></div><h2>把目标交给 Coordinator</h2><p>复杂目标会自动拆成 Agent DAG；简单任务仍只启动一个隔离 Worker。</p>';
    root.append(empty); return;
  }
  for (const message of state.messages) {
    const row = document.createElement('article'); row.className = `message ${message.role}`;
    const avatar = document.createElement('div'); avatar.className = 'message-avatar'; avatar.textContent = message.role === 'user' ? '你' : 'R';
    const body = document.createElement('div'); body.className = 'message-body'; body.textContent = message.content;
    const meta = document.createElement('div'); meta.className = 'message-meta'; meta.textContent = formatTime(message.created_at);
    const wrap = document.createElement('div'); wrap.append(body, meta);
    row.append(avatar, wrap); root.append(row);
  }
  root.scrollTop = root.scrollHeight;
}

function renderInspector() {
  renderTasks(); renderApprovals(); renderMemories();
  // 协同面板只在被激活时重建，避免普通任务事件把正在阅读的链路/报告刷掉
  if ($('#panel-collaboration')?.classList.contains('active')) renderCollaborations();
  if ($('#panel-mas')?.classList.contains('active')) renderMas();
  const active = state.mas.runs.filter((run) => ['queued', 'running'].includes(run.status)).length;
  const badge = $('#mas-count');
  if (badge) { badge.textContent = String(active); badge.classList.toggle('hidden', !active); }
}
function renderSystem() {
  const root = $('#panel-system');
  if (!root) return;
  root.replaceChildren();
  const sandbox = state.sandbox;
  if (sandbox) {
    const card = document.createElement('article'); card.className = 'card';
    const heading = document.createElement('h3'); heading.textContent = 'Worker 沙箱';
    const tier = document.createElement('p');
    tier.textContent = `隔离级别: ${sandbox.tier}${sandbox.mode ? ` (${sandbox.mode})` : ''}`;
    const host = document.createElement('p'); host.textContent = `宿主: ${sandbox.host || '进程内隔离'}`;
    card.append(heading, tier, host);
    if (sandbox.reason) { const reason = document.createElement('p'); reason.textContent = `降级原因: ${sandbox.reason}`; card.append(reason); }
    root.append(card);
  }
  if (state.memoryStats) {
    const card = document.createElement('article'); card.className = 'card';
    const heading = document.createElement('h3'); heading.textContent = '向量记忆';
    const p = document.createElement('p'); p.textContent = `已索引 ${state.memoryStats.indexed}/${state.memoryStats.total} 条 · 模型 ${state.memoryStats.model || '无'}`;
    const actions = document.createElement('div'); actions.className = 'actions';
    const backfill = document.createElement('button'); backfill.className = 'mini-button'; backfill.textContent = '重建索引';
    backfill.addEventListener('click', async () => { await api('/api/memory/backfill', { method: 'POST', body: JSON.stringify({ sessionId: state.currentSessionId }) }); await loadSystem(); toast('向量索引已重建'); });
    actions.append(backfill); card.append(heading, p, actions); root.append(card);
  }
  if (!root.children.length) { const empty = document.createElement('div'); empty.className = 'empty-mini'; empty.textContent = '暂无系统信息'; root.append(empty); }
}

function renderWatchers() {
  const root = $('#panel-watch');
  if (!root) return;
  root.replaceChildren();
  const form = document.createElement('div'); form.className = 'card';
  const heading = document.createElement('h3'); heading.textContent = '新增文件监听';
  const pathInput = document.createElement('input'); pathInput.placeholder = '目录路径（默认工作区）'; pathInput.className = 'mini-input';
  const patternInput = document.createElement('input'); patternInput.placeholder = '正则过滤，例如 \\.md$'; patternInput.className = 'mini-input';
  const addButton = document.createElement('button'); addButton.className = 'mini-button approve'; addButton.textContent = '开始监听';
  addButton.addEventListener('click', async () => {
    try {
      await api('/api/watchers', { method: 'POST', body: JSON.stringify({ sessionId: state.currentSessionId, path: pathInput.value || state.config?.workspace, pattern: patternInput.value || null }) });
      await loadSystem(); toast('已开始监听');
    } catch (error) { toast(error.message); }
  });
  form.append(heading, pathInput, patternInput, addButton); root.append(form);

  const watchers = state.watchers?.watchers || [];
  if (!watchers.length) { const empty = document.createElement('div'); empty.className = 'empty-mini'; empty.textContent = '没有活动的文件监听'; root.append(empty); return; }
  for (const watcher of watchers) {
    const card = document.createElement('article'); card.className = 'card';
    const title = document.createElement('h3'); title.textContent = '文件监听';
    const p = document.createElement('p'); p.textContent = watcher.path;
    const meta = document.createElement('p'); meta.textContent = `${watcher.pattern ? `过滤: ${watcher.pattern} · ` : ''}${watcher.events.join(', ')}`;
    const actions = document.createElement('div'); actions.className = 'actions';
    const stop = document.createElement('button'); stop.className = 'mini-button deny'; stop.textContent = '停止';
    stop.addEventListener('click', async () => { await api(`/api/watchers/${watcher.id}`, { method: 'DELETE' }); await loadSystem(); });
    actions.append(stop); card.append(title, p, meta, actions); root.append(card);
  }
}
function renderTasks() {
  const root = $('#panel-tasks'); root.replaceChildren();
  if (!state.tasks.length) { const empty = document.createElement('div'); empty.className = 'empty-mini'; empty.textContent = '暂无 Worker 任务'; root.append(empty); return; }
  for (const task of state.tasks) {
    const card = document.createElement('article'); card.className = 'card';
    const heading = document.createElement('h3'); const dot = document.createElement('span'); dot.className = `task-status ${task.status}`; const label = document.createElement('span'); label.textContent = task.title; heading.append(dot, label);
    const status = document.createElement('p'); status.textContent = `${statusLabel(task.status)} · 第 ${task.attempt || 1}/${task.maxAttempts || 3} 轮${task.progress ? ` · ${task.progress}` : ''}`;
    const heartbeat = document.createElement('p'); heartbeat.textContent = task.last_heartbeat_at ? `最近心跳: ${formatTime(task.last_heartbeat_at)}` : '尚未收到心跳'; heartbeat.className = 'task-meta';
    const workspace = document.createElement('p'); workspace.className = 'task-workspace'; workspace.textContent = `任务文件夹: ${task.workspace || '未记录'}`; workspace.title = task.workspace || '';
    const caps = document.createElement('p'); caps.textContent = `能力: ${task.capabilities.join(', ')} · ${task.id}`;
    card.append(heading, status, workspace, heartbeat, caps);
    if (task.result || task.error) { const pre = document.createElement('pre'); pre.textContent = task.result || task.error; card.append(pre); }
    if (['failed', 'cancelled'].includes(task.status)) {
      const actions = document.createElement('div'); actions.className = 'actions';
      const retry = document.createElement('button'); retry.className = 'mini-button approve'; retry.textContent = '重新执行';
      retry.addEventListener('click', async () => { await api(`/api/tasks/${task.id}/retry`, { method: 'POST' }); await loadTasks(); toast('任务已重新进入自动监督'); });
      actions.append(retry); card.append(actions);
    }    if (['queued', 'running', 'waiting_approval'].includes(task.status)) {
      const actions = document.createElement('div'); actions.className = 'actions'; const cancel = document.createElement('button'); cancel.className = 'mini-button deny'; cancel.textContent = '取消'; cancel.addEventListener('click', async () => { await api(`/api/tasks/${task.id}/cancel`, { method: 'POST' }); await loadTasks(); }); actions.append(cancel); card.append(actions);
    }
    root.append(card);
  }
}
function renderApprovals() {
  const root = $('#panel-approvals'); root.replaceChildren();
  $('#approval-count').textContent = state.approvals.length; $('#approval-count').classList.toggle('hidden', !state.approvals.length);
  if (!state.approvals.length) { const empty = document.createElement('div'); empty.className = 'empty-mini'; empty.textContent = '没有待审批操作'; root.append(empty); return; }
  for (const approval of state.approvals) {
    const card = document.createElement('article'); card.className = 'card';
    const heading = document.createElement('h3'); heading.textContent = approval.kind === 'run_command' ? '命令执行审批' : '文件写入审批';
    const detail = document.createElement('pre'); detail.textContent = JSON.stringify(approval.details, null, 2);
    const actions = document.createElement('div'); actions.className = 'actions';
    const approve = document.createElement('button'); approve.className = 'mini-button approve'; approve.textContent = '本次允许';
    const deny = document.createElement('button'); deny.className = 'mini-button deny'; deny.textContent = '拒绝';
    approve.addEventListener('click', () => resolveApproval(approval.id, '本次允许'));
    deny.addEventListener('click', () => resolveApproval(approval.id, '拒绝'));
    actions.append(approve, deny); card.append(heading, detail, actions); root.append(card);
  }
}
function renderMemories() { renderMemoryPanel(); }
const COLLAB_STATUS_LABELS = {
  queued: '排队中', running: '协作中', completed: '已完成', partial: '部分完成', failed: '失败', cancelled: '已取消',
};
const AGENT_ROLE_LABELS = {
  coordinator: '协调', researcher: '研究', implementer: '执行', reviewer: '校验',
  arbiter: '仲裁', archivist: '归档', general: '通用',
};

async function loadCollaborations() {
  try {
    const query = state.currentSessionId ? `?sessionId=${encodeURIComponent(state.currentSessionId)}` : '';
    state.collaborations = await api(`/api/collaborations${query}`);
    if ($('#panel-collaboration')?.classList.contains('active')) renderCollaborations();
  } catch { /* 协作面板为增量能力，不阻塞主界面 */ }
}

function formatDuration(ms) {
  const value = Number(ms) || 0;
  if (value < 1000) return `${value} ms`;
  if (value < 60000) return `${(value / 1000).toFixed(1)} 秒`;
  return `${Math.floor(value / 60000)} 分 ${Math.round((value % 60000) / 1000)} 秒`;
}

function agentNodeCard(task, allTasks) {
  const node = document.createElement('details');
  node.className = `agent-node ${task.status}`;
  const summary = document.createElement('summary');
  const role = document.createElement('span'); role.className = `role-badge ${task.agentRole || 'general'}`; role.textContent = AGENT_ROLE_LABELS[task.agentRole] || task.agentRole || '通用';
  const title = document.createElement('strong'); title.textContent = task.title;
  const stateBadge = document.createElement('span'); stateBadge.className = `task-status-pill ${task.status}`; stateBadge.textContent = statusLabel(task.status);
  summary.append(role, title, stateBadge);
  const meta = document.createElement('p'); meta.className = 'task-meta';
  const deps = (task.dependsOn || []).map((id) => allTasks.find((item) => item.id === id)?.title || id).join('、');
  meta.textContent = `${task.progress || '等待调度'}${deps ? ` · 上游：${deps}` : ' · 无上游依赖'} · 第 ${task.attempt || 1}/${task.maxAttempts || 3} 轮`;
  const body = document.createElement('div'); body.className = 'agent-node-body';
  if (task.expectedOutput) { const expected = document.createElement('p'); expected.textContent = `交付标准：${task.expectedOutput}`; body.append(expected); }
  if (task.handoff && Object.keys(task.handoff).length) { const handoff = document.createElement('p'); handoff.className = 'task-meta'; handoff.textContent = `交接要求：${JSON.stringify(task.handoff)}`; body.append(handoff); }
  if (task.result || task.error) { const pre = document.createElement('pre'); pre.textContent = task.result || task.error; body.append(pre); }
  node.append(summary, meta, body);
  return node;
}

function collaborationCard(run) {
  const tasks = state.tasks.filter((task) => task.runId === run.id).sort((a, b) => (a.collaborationOrder || 0) - (b.collaborationOrder || 0));
  const card = document.createElement('article'); card.className = `card collab-run ${run.status}`;
  const heading = document.createElement('h3');
  const dot = document.createElement('span'); dot.className = `task-status ${run.status}`;
  const title = document.createElement('span'); title.textContent = run.title;
  heading.append(dot, title);
  const metrics = run.metrics || {};
  const usage = metrics.usage || {};
  const usageText = usage.llmCalls ? ` · ${usage.llmCalls} 次模型调用 / ${usage.totalTokens || 0} tokens` : '';
  const status = document.createElement('p'); status.textContent = `${COLLAB_STATUS_LABELS[run.status] || run.status} · ${metrics.completed || 0}/${metrics.agentCount || tasks.length} Agent 成功 · 重试 ${metrics.retries || 0} 次 · ${formatDuration(metrics.durationMs)}${usageText}`;
  const strategy = document.createElement('p'); strategy.className = 'task-meta';
  strategy.textContent = `中心化 DAG · 失败策略 ${run.failurePolicy === 'stop' ? '中止' : '继续'} · ${run.id}`;
  const flow = document.createElement('div'); flow.className = 'agent-flow';
  flow.append(...tasks.map((task) => agentNodeCard(task, tasks)));
  card.append(heading, status, strategy, flow);
  if (run.error) { const error = document.createElement('pre'); error.textContent = run.error; card.append(error); }
  const actions = document.createElement('div'); actions.className = 'actions';
  if (['queued', 'running'].includes(run.status)) {
    const cancel = document.createElement('button'); cancel.className = 'mini-button deny'; cancel.textContent = '取消协作';
    cancel.addEventListener('click', async () => {
      await api(`/api/collaborations/${run.id}/cancel`, { method: 'POST' }).catch((error) => toast(error.message));
      await loadTasks(); await loadCollaborations();
    });
    actions.append(cancel);
  }
  if (['failed', 'partial', 'cancelled', 'completed'].includes(run.status)) {
    const retry = document.createElement('button'); retry.className = 'mini-button'; retry.textContent = '重跑协作组';
    retry.addEventListener('click', async () => {
      try { await api(`/api/collaborations/${run.id}/retry`, { method: 'POST' }); await loadTasks(); await loadCollaborations(); toast('已创建新的协作运行'); }
      catch (error) { toast(error.message); }
    });
    actions.append(retry);
  }
  if (actions.children.length) card.append(actions);
  return card;
}

function renderCollaborations() {
  const root = $('#panel-collaboration');
  if (!root) return;
  root.replaceChildren();
  const intro = document.createElement('article'); intro.className = 'card collaboration-intro';
  const heading = document.createElement('h3'); heading.textContent = '中心化多智能体协作';
  const text = document.createElement('p'); text.textContent = 'Coordinator 自动生成 2–5 个 Agent 的 DAG：无依赖节点并行，上游结果结构化交接给下游，独立校验后统一交付。';
  const rule = document.createElement('p'); rule.className = 'task-meta'; rule.textContent = '复杂目标直接在聊天框发送即可；专项带引用的深度调研请使用“深度调研”面板。';
  intro.append(heading, text, rule); root.append(intro);
  if (!state.collaborations.length) {
    const empty = document.createElement('div'); empty.className = 'empty-mini'; empty.textContent = '当前会话还没有协作组。发送一个可拆分任务试试。'; root.append(empty); return;
  }
  for (const run of state.collaborations) root.append(collaborationCard(run));
}
const MAS_STATUS_LABELS = {
  queued: '排队中', running: '调研中', completed: '已交付', failed: '失败', cancelled: '已取消',
};

async function loadMas() {
  try {
    if (!state.mas.templates.length) state.mas.templates = await api('/api/mas/templates');
    state.mas.runs = await api('/api/mas/runs?limit=30');
    if (state.mas.openRunId) {
      state.mas.detail = await api(`/api/mas/runs/${encodeURIComponent(state.mas.openRunId)}`).catch(() => null);
    }
  } catch (error) { /* 面板为增量能力，失败时不阻塞主界面 */ }
  if ($('#panel-collaboration')?.classList.contains('active')) renderCollaborations();
  if ($('#panel-mas')?.classList.contains('active')) renderMas();
}

function masRunCard(run) {
  const card = document.createElement('article');
  card.className = `card mas-run ${run.status}`;
  const heading = document.createElement('h3');
  const dot = document.createElement('span'); dot.className = `task-status ${run.status === 'completed' ? 'completed' : run.status}`;
  const label = document.createElement('span'); label.textContent = run.topic;
  heading.append(dot, label);

  const status = document.createElement('p');
  const metrics = run.metrics || {};
  const parts = [MAS_STATUS_LABELS[run.status] || run.status];
  if (metrics.rounds) parts.push(`第 ${metrics.rounds} 轮`);
  if (metrics.passRate != null && metrics.claims) parts.push(`引用 ${metrics.verified}/${metrics.claims} 通过`);
  if (metrics.llmCalls) parts.push(`${metrics.llmCalls} 次模型调用`);
  status.textContent = parts.join(' · ');

  const meta = document.createElement('p'); meta.className = 'task-meta';
  meta.textContent = `${run.template || 'research_report'} · ${formatTime(run.created_at)}`;

  const actions = document.createElement('div'); actions.className = 'actions';
  const open = document.createElement('button'); open.className = 'mini-button'; open.textContent = '查看链路';
  open.addEventListener('click', async () => {
    state.mas.openRunId = state.mas.openRunId === run.id ? null : run.id;
    state.mas.report = null;
    await loadMas();
  });
  actions.append(open);
  if (['queued', 'running'].includes(run.status)) {
    const cancel = document.createElement('button'); cancel.className = 'mini-button deny'; cancel.textContent = '取消';
    cancel.addEventListener('click', async () => {
      await api(`/api/mas/runs/${run.id}/cancel`, { method: 'POST' }).catch((error) => toast(error.message));
      await loadMas();
    });
    actions.append(cancel);
  }
  if (['failed', 'cancelled', 'completed'].includes(run.status)) {
    const retry = document.createElement('button'); retry.className = 'mini-button'; retry.textContent = '再跑一次';
    retry.addEventListener('click', async () => {
      await api(`/api/mas/runs/${run.id}/retry`, { method: 'POST' }).catch((error) => toast(error.message));
      await loadMas();
    });
    actions.append(retry);
  }
  if (run.status === 'completed') {
    const report = document.createElement('button'); report.className = 'mini-button approve'; report.textContent = '查看报告';
    report.addEventListener('click', async () => {
      try {
        const payload = await api(`/api/mas/runs/${run.id}/report`);
        state.mas.report = payload;
        state.mas.openRunId = run.id;
        renderMas();
      } catch (error) { toast(error.message); }
    });
    actions.append(report);
  }
  card.append(heading, status, meta, actions);
  return card;
}

function masStepList(steps) {
  const list = document.createElement('ol'); list.className = 'mas-timeline';
  const rounds = [...new Set(steps.map((step) => step.round))].sort((a, b) => a - b);
  for (const round of rounds) {
    const heading = document.createElement('li'); heading.className = 'mas-round'; heading.textContent = `第 ${round} 轮`;
    list.append(heading);
    for (const step of steps.filter((item) => item.round === round)) {
      const item = document.createElement('li');
      item.className = `mas-step ${step.status}`;
      const title = document.createElement('div'); title.className = 'mas-step-title';
      title.textContent = `${step.nodeId || step.node_id} · ${step.label}`;
      const stateLabel = { completed: '完成', failed: '失败', skipped: '跳过', running: '进行中' }[step.status] || step.status;
      const badge = document.createElement('span'); badge.className = 'mas-step-badge'; badge.textContent = stateLabel;
      title.append(badge);
      item.append(title);
      const detailLine = step.summary || step.error || '';
      if (detailLine) { const summary = document.createElement('p'); summary.className = 'task-meta'; summary.textContent = detailLine; item.append(summary); }
      const durationMs = step.durationMs ?? step.duration_ms;
      if (durationMs) { const time = document.createElement('p'); time.className = 'task-meta'; time.textContent = `${durationMs} ms${step.attempts > 1 ? ` · 重试 ${step.attempts} 次` : ''}`; item.append(time); }
      list.append(item);
    }
  }
  return list;
}

function renderMas() {
  const root = $('#panel-mas');
  if (!root) return;
  root.replaceChildren();

  const template = state.mas.templates[0];
  const form = document.createElement('article'); form.className = 'card';
  const formTitle = document.createElement('h3'); formTitle.textContent = template?.name || '技术调研报告流水线';
  const formNote = document.createElement('p'); formNote.className = 'task-meta';
  formNote.textContent = template?.description || '并行检索 → 引用回抓校验 → 撰写 → 审校 → 仲裁 → 归档';
  const topic = document.createElement('input'); topic.className = 'mini-input'; topic.placeholder = '研究主题，例如：多智能体协同架构选型';
  const row = document.createElement('div'); row.className = 'mas-form-row';

  const depth = document.createElement('select'); depth.className = 'mini-input';
  for (const [value, text] of [['1', '轻量 · 2 个检索 Agent'], ['2', '标准 · 3 个检索 Agent'], ['3', '深入 · 4 个检索 Agent']]) {
    const option = document.createElement('option'); option.value = value; option.textContent = text; depth.append(option);
  }
  depth.value = '2';
  const revisions = document.createElement('select'); revisions.className = 'mini-input';
  for (const [value, text] of [['0', '不返工'], ['1', '最多返工 1 轮'], ['2', '最多返工 2 轮']]) {
    const option = document.createElement('option'); option.value = value; option.textContent = text; revisions.append(option);
  }
  revisions.value = '1';
  row.append(depth, revisions);

  const start = document.createElement('button'); start.className = 'mini-button approve'; start.textContent = '启动调研';
  start.addEventListener('click', async () => {
    const text = topic.value.trim();
    if (!text) { toast('先填写研究主题'); return; }
    start.disabled = true; start.textContent = '启动中…';
    try {
      const run = await api('/api/mas/runs', {
        method: 'POST',
        body: JSON.stringify({ topic: text, depth: Number(depth.value), maxRevisions: Number(revisions.value) }),
      });
      state.mas.openRunId = run.id;
      toast('深度调研任务已启动');
      await loadMas();
    } catch (error) { toast(error.message); }
    finally { start.disabled = false; start.textContent = '启动调研'; }
  });
  form.append(formTitle, formNote, topic, row, start);
  root.append(form);

  const openDetail = state.mas.openRunId && state.mas.detail;
  if (openDetail) {
    const card = document.createElement('article'); card.className = 'card mas-detail';
    const heading = document.createElement('h3'); heading.textContent = `执行链路 · ${openDetail.run.topic}`;
    card.append(heading);
    if (openDetail.run.error) { const error = document.createElement('pre'); error.textContent = openDetail.run.error; card.append(error); }
    if (openDetail.steps?.length) card.append(masStepList(openDetail.steps));
    const metrics = openDetail.run.metrics || {};
    if (openDetail.run.state?.arbitration) {
      const arbitration = openDetail.run.state.arbitration;
      const p = document.createElement('p'); p.textContent = `仲裁结论：${arbitration.decision === 'ship' ? '交付' : '返工'} · ${arbitration.reason}`;
      card.append(p);
      if (arbitration.openRisks?.length) {
        const risks = document.createElement('ul'); risks.className = 'mas-risks';
        for (const risk of arbitration.openRisks) { const li = document.createElement('li'); li.textContent = risk; risks.append(li); }
        card.append(risks);
      }
    }
    if (metrics.claims) {
      const p = document.createElement('p'); p.className = 'task-meta';
      p.textContent = `论断 ${metrics.verified}/${metrics.claims} 通过引用校验 · 抓取 ${metrics.pages} 页 · 检索 ${metrics.searchCalls} 次`;
      card.append(p);
    }
    root.append(card);
  }

  if (state.mas.report) {
    const card = document.createElement('article'); card.className = 'card';
    const heading = document.createElement('h3'); heading.textContent = '交付报告';
    const pathLine = document.createElement('p'); pathLine.className = 'task-meta'; pathLine.textContent = state.mas.report.path || '仅存于数据库';
    const actions = document.createElement('div'); actions.className = 'actions';
    const copy = document.createElement('button'); copy.className = 'mini-button'; copy.textContent = '复制全文';
    copy.addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(state.mas.report.content || ''); toast('已复制报告全文'); } catch { toast('复制失败，可手动选择正文'); }
    });
    const download = document.createElement('button'); download.className = 'mini-button approve'; download.textContent = '下载 .md';
    download.addEventListener('click', () => {
      const blob = new Blob([state.mas.report.content || ''], { type: 'text/markdown;charset=utf-8' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = state.mas.report.name || 'research-report.md';
      link.click();
      setTimeout(() => URL.revokeObjectURL(link.href), 2000);
    });
    actions.append(copy, download);
    const pre = document.createElement('pre'); pre.className = 'mas-report'; pre.textContent = state.mas.report.content || '';
    card.append(heading, pathLine, actions, pre);
    root.append(card);
  }

  const listTitle = document.createElement('div'); listTitle.className = 'section-label'; listTitle.textContent = '协同运行';
  root.append(listTitle);
  if (!state.mas.runs.length) {
    const empty = document.createElement('div'); empty.className = 'empty-mini'; empty.textContent = '还没有协同任务'; root.append(empty);
  } else {
    for (const run of state.mas.runs) root.append(masRunCard(run));
  }
}

function renderAll() { renderSessions(); renderMessages(); renderInspector(); }

async function resolveApproval(id, resolution) {
  try { await api(`/api/approvals/${id}/resolve`, { method: 'POST', body: JSON.stringify({ resolution }) }); await loadTasks(); }
  catch (error) { toast(error.message); }
}

async function sendMessage(event) {
  event?.preventDefault();
  const input = $('#prompt'); const text = input.value.trim();
  if (!text || state.busy) return;
  state.busy = true; $('.send').disabled = true; input.value = ''; input.style.height = 'auto';
  const optimistic = { id: 'local', role: 'user', content: text, created_at: new Date().toISOString() };
  state.messages.push(optimistic); renderMessages();
  try {
    const result = await api('/api/chat', { method: 'POST', body: JSON.stringify({ sessionId: state.currentSessionId, text }) });
    state.currentSessionId = result.sessionId;
    await loadSessions(); await loadSession(result.sessionId); await loadTasks(); await loadCollaborations();
  } catch (error) { toast(error.message); state.messages = state.messages.filter((message) => message.id !== 'local'); renderMessages(); }
  finally { state.busy = false; $('.send').disabled = false; input.focus(); }
}

function toast(message) {
  const node = document.createElement('div'); node.textContent = message;
  Object.assign(node.style, { position: 'fixed', right: '18px', bottom: '18px', zIndex: 50, background: '#25151a', color: '#ffd9de', border: '1px solid rgba(255,107,122,.35)', padding: '11px 14px', borderRadius: '11px', boxShadow: '0 12px 35px rgba(0,0,0,.35)', fontSize: '12px' });
  document.body.append(node); setTimeout(() => node.remove(), 4200);
}

function notifyTaskEvent(payload) {
  const title = payload.task?.title || '本地任务';
  let message = '';
  if (payload.type === 'task.completed' && !payload.task?.runId) message = `任务已完成：${title}`;
  else if (payload.type === 'task.failed' && !payload.task?.runId) message = `任务需要处理：${title}`;
  else if (payload.type === 'approval.requested') message = `任务等待审批：${title}`;
  else if (payload.type === 'task.retrying' && !payload.task?.runId) message = `任务中断，正在自动恢复：${title}`;
  else if (payload.type === 'collaboration.completed') message = `多智能体协作已交付：${payload.run?.title || payload.runId}`;
  else if (payload.type === 'collaboration.partial') message = `多智能体协作部分完成：${payload.run?.title || payload.runId}`;
  else if (payload.type === 'collaboration.failed') message = `多智能体协作失败：${payload.run?.title || payload.runId}`;
  if (!message) return;
  toast(message);
  if (!isTauriShell() && 'Notification' in window) {
    try {
      if (Notification.permission === 'granted') new Notification('Local Super Agent', { body: message });
      else if (Notification.permission !== 'denied') Notification.requestPermission();
    } catch { /* fall back to the in-app toast */ }
  }
}
function connectEvents() {
  const events = new EventSource(apiUrl('/api/events'));
  events.addEventListener('open', () => { $('#status-dot').className = 'status-dot online'; $('#status-text').textContent = 'Router 在线'; });
  events.addEventListener('error', () => { $('#status-dot').className = 'status-dot offline'; $('#status-text').textContent = '正在重连'; });
  events.addEventListener('message', async (event) => {
    let payload; try { payload = JSON.parse(event.data); } catch { return; }
    notifyTaskEvent(payload);
    if (payload.sessionId && payload.sessionId !== state.currentSessionId && !['task.queued'].includes(payload.type)) { await loadSessions(); return; }
    if (['task.queued','task.started','task.progress','task.heartbeat','task.retrying','task.recovered','task.restarted','task.completed','task.failed','task.cancelled','watchdog.alert','approval.requested','approval.approved','approval.denied','approval.expired'].includes(payload.type)) {
      await loadTasks().catch(() => {});
      if (payload.task?.runId) await loadCollaborations().catch(() => {});
    }
    if (payload.type?.startsWith('collaboration.')) {
      await loadTasks().catch(() => {});
      await loadCollaborations().catch(() => {});
    }
    if (['watcher.triggered','trigger.routed_directly','trigger.subscription'].includes(payload.type)) {
      await loadSystem().catch(() => {});
    }
    if (payload.type?.startsWith('mas.')) {
      await loadMas().catch(() => {});
      if (payload.type === 'mas.run.completed') toast(`深度调研任务已交付：${payload.topic || payload.runId}`);
      if (payload.type === 'mas.run.failed') toast(`深度调研任务失败：${payload.error || payload.runId}`);
    }    if (['task.completed','task.failed','message.task_result','message.collaboration_result'].includes(payload.type) && payload.sessionId === state.currentSessionId) {
      await loadSession(state.currentSessionId).catch(() => {});
    }
    if (['mas.run.completed','mas.run.failed','mas.run.cancelled'].includes(payload.type) && payload.sessionId === state.currentSessionId) {
      await loadSession(state.currentSessionId).catch(() => {});
    }
    if (payload.type?.startsWith('memory.')) {
      if ($('#panel-memory')?.classList.contains('active')) await loadMemoryCenter().catch(() => {});
      if (payload.type === 'memory.dream.completed') toast('长期记忆整理完成');
      if (payload.type === 'memory.dream.failed') toast('长期记忆整理失败：' + (payload.error || '未知错误'));
    }
  });
}

// On narrow windows the inspector becomes a slide-in drawer; these helpers keep
// the toggle button, scrim and Escape key in sync with it.
function setInspectorOpen(open) {
  const inspector = $('.inspector');
  const scrim = $('#scrim');
  if (!inspector || !scrim) return;
  inspector.classList.toggle('open', open);
  scrim.classList.toggle('open', open);
  const toggle = $('#toggle-inspector');
  if (toggle) toggle.setAttribute('aria-expanded', String(open));
}

function inspectorIsDrawer() {
  return window.matchMedia('(max-width: 980px)').matches;
}

function bind() {
  $('#new-session').addEventListener('click', async () => { const session = await api('/api/sessions', { method: 'POST', body: JSON.stringify({ title: '新会话' }) }); state.currentSessionId = session.id; await loadSessions(); await loadSession(session.id); $('#prompt').focus(); });
  $('#composer').addEventListener('submit', sendMessage);
  $('#prompt').addEventListener('keydown', (event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendMessage(); } });
  $('#prompt').addEventListener('input', (event) => { event.target.style.height = 'auto'; event.target.style.height = `${Math.min(event.target.scrollHeight, 150)}px`; });
  $('#refresh').addEventListener('click', refresh);
  document.querySelectorAll('.tab').forEach((tab) => tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((item) => item.classList.toggle('active', item === tab));
    document.querySelectorAll('.panel').forEach((panel) => panel.classList.toggle('active', panel.id === `panel-${tab.dataset.tab}`));
    if (tab.dataset.tab === 'mas') loadMas().catch((error) => toast(error.message));
    if (tab.dataset.tab === 'collaboration') loadCollaborations().catch((error) => toast(error.message));
    if (tab.dataset.tab === 'memory') loadMemoryCenter().catch((error) => toast(error.message));
  }));
  const inspectorToggle = $('#toggle-inspector');
  if (inspectorToggle) inspectorToggle.addEventListener('click', () => setInspectorOpen(!$('.inspector').classList.contains('open')));
  const scrim = $('#scrim');
  if (scrim) scrim.addEventListener('click', () => setInspectorOpen(false));
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') setInspectorOpen(false); });
  window.addEventListener('resize', () => { if (!inspectorIsDrawer()) setInspectorOpen(false); });
  $('#open-settings').addEventListener('click', () => $('#settings-dialog').showModal());
  $('#close-settings').addEventListener('click', () => $('#settings-dialog').close());
  $('#cancel-settings').addEventListener('click', () => $('#settings-dialog').close());
  const chooseWorkspace = async () => {
    try { await chooseTaskFolder(); }
    catch (error) { toast(`无法切换任务文件夹：${error.message}`); }
  };
  $('#choose-workspace').addEventListener('click', chooseWorkspace);
  $('#choose-workspace-action').addEventListener('click', chooseWorkspace);
  $('#open-workspace').addEventListener('click', async () => {
    try { await openTaskFolder(); }
    catch (error) { toast(error.message); }
  });
  $('#auto-write-toggle').addEventListener('change', async (event) => {
    try { await setWorkspaceWriteAccess(event.target.checked); }
    catch (error) { toast(error.message); await loadConfig().catch(() => {}); }
  });
  async function saveSettingsForm(form) {
    const baseUrl = form.elements.baseUrl.value.trim();
    const routerModel = form.elements.routerModel.value.trim();
    const workerModel = form.elements.workerModel.value.trim();
    const apiKey = form.elements.apiKey.value.trim();
    if (!baseUrl) throw new Error('请填写 Base URL');
    if (!routerModel || !workerModel) throw new Error('请填写 Router 模型和 Worker 模型');
    if (!apiKey && !state.config?.provider?.hasApiKey) throw new Error('请填写 API Key');
    const payload = { baseUrl, routerModel, workerModel, autoApproveWorkspaceWrites: form.elements.autoApproveWorkspaceWrites.checked, autoApproveCommands: form.elements.autoApproveCommands.checked, sandboxMode: form.elements.sandboxMode.value, memory: { dreaming: { enabled: Boolean(form.elements.dreamingEnabled?.checked), intervalHours: Number(form.elements.dreamingInterval?.value) || 6 } } };
    if (apiKey) payload.apiKey = apiKey;
    await api('/api/config', { method: 'PUT', body: JSON.stringify(payload) });
    form.elements.apiKey.value = '';
    await loadConfig();
    return state.config;
  }

  $('#settings-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    try {
      await saveSettingsForm(event.target);
      $('#settings-dialog').close();
      toast('设置已保存');
    } catch (error) { toast(error.message); }
  });
  $('#test-settings').addEventListener('click', async () => {
    try {
      await saveSettingsForm($('#settings-form'));
      toast('正在测试模型连接…');
      const result = await api('/api/config/test', { method: 'POST', body: '{}' });
      toast(`连接成功：${result.model}（${result.elapsedMs} ms）`);
    } catch (error) { toast(`连接失败：${error.message}`); }
  });
}

const MEMORY_TAB_LABELS = { notes: '记忆笔记', wiki: 'Wiki', transcripts: '原始流水', runs: '整理记录' };
const MEMORY_STATUS_LABELS = { active: '活跃', dormant: '休眠', archived: '已归档', superseded: '已被替代' };

function memoryNode(tag, className = '', text = '') {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== '') node.textContent = text;
  return node;
}

async function loadMemoryCenter() {
  if (!state.config) return;
  state.memory.loading = true;
  try {
    const workspace = state.config.workspace || '';
    const sessionId = state.currentSessionId || '';
    const sessionQuery = sessionId ? `&sessionId=${encodeURIComponent(sessionId)}` : '';
    const [overview, records, pages, transcripts, runs] = await Promise.all([
      api(`/api/memory/overview?workspace=${encodeURIComponent(workspace)}${sessionQuery}`),
      api(`/api/memory/records?workspace=${encodeURIComponent(workspace)}${sessionQuery}&status=all&limit=300`),
      api(`/api/memory/pages?workspace=${encodeURIComponent(workspace)}&status=all&content=1`),
      api(`/api/memory/transcripts?workspace=${encodeURIComponent(workspace)}${sessionId ? `&sessionId=${encodeURIComponent(sessionId)}` : ''}&limit=200`),
      api(`/api/memory/runs?workspace=${encodeURIComponent(workspace)}&limit=20`),
    ]);
    state.memory.overview = overview;
    state.memory.records = records;
    state.memory.pages = pages;
    state.memory.transcripts = transcripts;
    state.memory.runs = runs;
    state.memory.searchActive = false;
    state.memory.searchQuery = '';
    state.memoryStats = null;
  } catch (error) {
    toast(`长期记忆加载失败：${error.message}`);
  } finally {
    state.memory.loading = false;
    renderMemoryPanel();
    renderSystem();
  }
}

function memoryMeta(memory) {
  const meta = memoryNode('div', 'memory-meta');
  meta.append(
    memoryNode('span', `memory-pill kind-${memory.kind}`, memory.kind),
    memoryNode('span', 'memory-pill', memory.scope),
    memoryNode('span', `memory-pill status-${memory.status}`, MEMORY_STATUS_LABELS[memory.status] || memory.status),
    memoryNode('span', 'memory-score', `置信 ${Number(memory.confidence || 0).toFixed(2)}`),
    memoryNode('span', 'memory-score', `重要度 ${memory.importance || 1}/5`),
    memoryNode('span', 'memory-score', `访问 ${memory.access_count || 0}`),
  );
  if (memory.pinned) meta.append(memoryNode('span', 'memory-pill pinned', '已置顶'));
  return meta;
}

function memoryActionButton(label, className, action) {
  const button = memoryNode('button', `mini-button ${className || ''}`, label);
  button.addEventListener('click', async () => {
    try { await action(); }
    catch (error) { toast(error.message); }
  });
  return button;
}


function memoryNoteCard(memory) {
  const card = memoryNode('article', `card memory-card status-${memory.status}`);
  const heading = memoryNode('h3');
  heading.append(memoryNode('span', 'memory-title-icon', memory.kind === 'preference' ? '◎' : memory.kind === 'decision' ? '◆' : '•'));
  heading.append(document.createTextNode(memory.topic || memory.kind || '记忆笔记'));
  card.append(heading, memoryMeta(memory), memoryNode('p', 'memory-content', memory.content));
  const actions = memoryNode('div', 'actions memory-actions');
  actions.append(
    memoryActionButton(memory.pinned ? '取消置顶' : '置顶', '', async () => {
      await api(`/api/memory/records/${encodeURIComponent(memory.id)}`, { method: 'PATCH', body: JSON.stringify({ pinned: !memory.pinned }) });
      await loadMemoryCenter();
    }),
    memoryActionButton('有帮助', 'approve', async () => {
      await api(`/api/memory/records/${encodeURIComponent(memory.id)}/feedback`, { method: 'POST', body: JSON.stringify({ helpful: true }) });
      await loadMemoryCenter();
    }),
    memoryActionButton('编辑', '', async () => {
      const value = window.prompt('编辑记忆内容', memory.content);
      if (value == null || !value.trim()) return;
      await api(`/api/memory/records/${encodeURIComponent(memory.id)}`, { method: 'PATCH', body: JSON.stringify({ content: value }) });
      await loadMemoryCenter();
    }),
    memoryActionButton(memory.status === 'archived' ? '恢复' : '归档', 'deny', async () => {
      await api(`/api/memory/records/${encodeURIComponent(memory.id)}`, { method: 'PATCH', body: JSON.stringify({ status: memory.status === 'archived' ? 'active' : 'archived' }) });
      await loadMemoryCenter();
    }),
    memoryActionButton('删除', 'deny', async () => {
      if (!window.confirm('确定永久删除这条记忆？原始流水不会被删除。')) return;
      await api(`/api/memory/records/${encodeURIComponent(memory.id)}`, { method: 'DELETE' });
      await loadMemoryCenter();
    }),
  );
  card.append(actions);
  return card;
}

function memoryToolbar() {
  const box = memoryNode('section', 'memory-toolbar');
  const searchRow = memoryNode('div', 'memory-search-row');
  const input = memoryNode('input', 'mini-input memory-search-input');
  input.placeholder = '搜索记忆内容…';
  input.value = state.memory.query || '';
  input.addEventListener('input', () => {
    state.memory.query = input.value;
    state.memory.searchActive = false;
    state.memory.searchQuery = '';
    renderMemoryPanel();
  });
  input.addEventListener('keydown', async (event) => {
    if (event.key === 'Enter') { event.preventDefault(); await searchMemory(); }
  });
  searchRow.append(input, memoryActionButton('语义搜索', 'approve', searchMemory), memoryActionButton('清除', '', async () => {
    state.memory.query = '';
    state.memory.searchActive = false;
    state.memory.searchQuery = '';
    await loadMemoryCenter();
  }));
  const actions = memoryNode('div', 'actions');
  actions.append(
    memoryActionButton('立即 Dreaming', 'approve', startDreaming),
    memoryActionButton('重建向量索引', '', async () => {
      await api('/api/memory/backfill', { method: 'POST', body: JSON.stringify({ workspace: state.config.workspace }) });
      await loadMemoryCenter();
      toast('长期记忆向量索引已重建');
    }),
    memoryActionButton('刷新', '', loadMemoryCenter),
  );
  box.append(searchRow, actions);
  return box;
}

async function searchMemory() {
  if (!state.currentSessionId) return;
  const query = String(state.memory.query || '').trim();
  if (!query) return await loadMemoryCenter();
  try {
    const result = await api('/api/memory/search', {
      method: 'POST',
      body: JSON.stringify({ sessionId: state.currentSessionId, query, workspace: state.config.workspace, topK: 50 }),
    });
    state.memory.records = result.results || [];
    state.memory.searchActive = true;
    state.memory.searchQuery = query;
    state.memory.tab = 'notes';
    renderMemoryPanel();
  } catch (error) { toast(error.message); }
}

async function startDreaming() {
  try {
    const run = await api('/api/memory/dream', { method: 'POST', body: JSON.stringify({ workspace: state.config.workspace, trigger: 'manual' }) });
    toast(`Dreaming 已启动：${run.id}`);
    state.memory.runs = [run, ...state.memory.runs];
    renderMemoryPanel();
    const poll = async (attempt = 0) => {
      if (attempt > 60) return;
      try {
        const runs = await api(`/api/memory/runs?workspace=${encodeURIComponent(state.config.workspace)}&limit=20`);
        state.memory.runs = runs;
        const current = runs.find((item) => item.id === run.id);
        if (current && ['completed', 'failed'].includes(current.status)) {
          toast(current.status === 'completed' ? 'Dreaming 整理完成' : `Dreaming 失败：${current.error || '未知错误'}`);
          await loadMemoryCenter();
          return;
        }
        renderMemoryPanel();
        setTimeout(() => poll(attempt + 1), 1000);
      } catch { setTimeout(() => poll(attempt + 1), 1500); }
    };
    setTimeout(() => poll(), 600);
  } catch (error) { toast(`Dreaming 启动失败：${error.message}`); }
}


function memoryAddForm() {
  const form = memoryNode('article', 'card memory-add-card');
  form.append(memoryNode('h3', '', '写入一条长期记忆'));
  const content = memoryNode('textarea', 'memory-add-textarea');
  content.placeholder = '记录事实、决定、偏好或可复用的经验…';
  const row = memoryNode('div', 'memory-add-row');
  const scope = memoryNode('select', 'mini-input');
  for (const value of ['project', 'session', 'global']) {
    const option = memoryNode('option', '', value === 'project' ? '项目记忆' : value === 'session' ? '仅本会话' : '全局记忆');
    option.value = value; scope.append(option);
  }
  const importance = memoryNode('select', 'mini-input');
  for (let value = 1; value <= 5; value += 1) {
    const option = memoryNode('option', '', `重要度 ${value}`); option.value = String(value); importance.append(option);
  }
  importance.value = '3';
  const add = memoryActionButton('保存记忆', 'approve', async () => {
    if (!content.value.trim()) throw new Error('请输入记忆内容');
    await api('/api/memory/records', {
      method: 'POST',
      body: JSON.stringify({ sessionId: state.currentSessionId, content: content.value, scope: scope.value, importance: Number(importance.value), sourceType: 'ui' }),
    });
    content.value = '';
    await loadMemoryCenter();
    toast('记忆已保存');
  });
  row.append(scope, importance, add);
  form.append(content, row);
  return form;
}

function memorySummary() {
  const overview = state.memory.overview;
  const section = memoryNode('section', 'memory-summary');
  const title = memoryNode('div', 'memory-summary-title');
  title.append(memoryNode('h2', '', '长期记忆'), memoryNode('p', '', 'Transcripts → 记忆笔记 → Wiki → 轻量注入索引。原始流水保留，Wiki 按需检索。'));
  const stats = memoryNode('div', 'memory-stat-grid');
  const counts = overview?.counts || {};
  const values = [
    ['活跃', counts.active || 0, 'active'], ['休眠', counts.dormant || 0, 'dormant'], ['归档', counts.archived || 0, 'archived'],
    ['Wiki 页面', counts.pages || 0, 'pages'], ['原始流水', counts.transcripts || 0, 'transcripts'], ['注入索引', overview?.index?.lineCount || 0, 'index'],
  ];
  for (const [label, value, tone] of values) {
    const item = memoryNode('div', `memory-stat ${tone}`);
    item.append(memoryNode('strong', '', String(value)), memoryNode('span', '', label));
    stats.append(item);
  }
  const note = overview
    ? `索引 ${overview.index?.lineCount || 0}/${overview.index?.maxLines || 200} 行 · ${overview.index?.bytes || 0}/${overview.index?.maxBytes || 25600} bytes · ${overview.index?.truncated ? '已截断，细节请检索 Wiki' : '索引健康'}`
    : '正在读取索引状态…';
  section.append(title, stats, memoryNode('p', 'memory-index-note', note));
  return section;
}

function renderMemoryTabs(root) {
  const tabs = memoryNode('div', 'memory-subtabs');
  for (const [key, label] of Object.entries(MEMORY_TAB_LABELS)) {
    const button = memoryNode('button', `memory-subtab ${state.memory.tab === key ? 'active' : ''}`, label);
    button.addEventListener('click', () => { state.memory.tab = key; state.memory.openPage = null; renderMemoryPanel(); });
    tabs.append(button);
  }
  root.append(tabs);
}

function renderNotesSection(root) {
  root.append(memoryAddForm());
  const query = state.memory.query.trim().toLowerCase();
  if (state.memory.searchActive) {
    root.append(memoryNode('p', 'memory-index-note', `语义搜索结果 · “${state.memory.searchQuery}” · ${state.memory.records.length} 条；结果按相关度排序`));
  }
  const records = state.memory.searchActive
    ? state.memory.records
    : state.memory.records.filter((memory) => !query || `${memory.content} ${memory.topic || ''} ${memory.kind}`.toLowerCase().includes(query));
  if (!records.length) root.append(memoryNode('div', 'empty-mini', state.memory.searchActive ? '语义搜索没有找到相关记忆' : query ? '没有匹配的记忆' : '还没有记忆笔记。发送任务或手动写入一条。'));
  else for (const memory of records) root.append(memoryNoteCard(memory));
}

function renderWikiSection(root) {
  if (!state.memory.pages.length) root.append(memoryNode('div', 'empty-mini', '还没有 Wiki 页面；Dreaming 会按主题生成。'));
  for (const page of state.memory.pages) {
    const card = memoryNode('article', 'card memory-wiki-card');
    card.append(memoryNode('h3', '', page.title || page.slug));
    card.append(memoryNode('p', 'memory-score', `${page.slug} · 修订 ${page.revision || 1} · ${formatTime(page.updated_at)}`));
    card.append(memoryNode('p', '', page.summary || '暂无摘要'));
    const actions = memoryNode('div', 'actions');
    actions.append(memoryActionButton(state.memory.openPage === page.id ? '收起' : '阅读全文', 'approve', async () => {
      state.memory.openPage = state.memory.openPage === page.id ? null : page.id;
      renderMemoryPanel();
    }));
    if (state.memory.openPage === page.id) card.append(memoryNode('pre', 'memory-wiki-content', page.content_md || page.content || '页面内容为空'));
    card.append(actions);
    root.append(card);
  }
}


function renderTranscriptsSection(root) {
  if (!state.memory.transcripts.length) root.append(memoryNode('div', 'empty-mini', '还没有原始流水。'));
  for (const item of state.memory.transcripts) {
    const card = memoryNode('article', 'card memory-transcript-card');
    card.append(memoryNode('h3', '', `${item.source || 'transcript'} · ${formatTime(item.created_at)}`));
    const details = memoryNode('details');
    details.append(memoryNode('summary', '', `任务 ${item.task_id || '—'} · ${String(item.content || '').slice(0, 90)}`));
    details.append(memoryNode('pre', 'memory-transcript-content', String(item.content || '').slice(0, 12000)));
    card.append(details);
    root.append(card);
  }
}

function renderRunsSection(root) {
  const indexCard = memoryNode('article', 'card memory-index-card');
  indexCard.append(memoryNode('h3', '', '注入索引'));
  indexCard.append(memoryNode('p', 'memory-index-note', state.memory.overview?.index?.path || 'MEMORY.md'));
  indexCard.append(memoryNode('p', 'memory-score', '硬限制：200 行 / 25 KB；超出部分只保留在 Wiki 和原始流水中。'));
  const dreaming = state.memory.overview?.dreaming;
  indexCard.append(memoryNode('p', 'memory-score', dreaming ? `后台整理：${dreaming.enabled ? '启用' : '关闭'} · 当前${dreaming.running ? '运行中' : '空闲'}${dreaming.nextRunAt ? ` · 下次 ${formatTime(dreaming.nextRunAt)}` : ''}` : '正在读取 Dreaming 状态…'));
  root.append(indexCard);
  if (!state.memory.runs.length) root.append(memoryNode('div', 'empty-mini', '还没有 Dreaming 记录。'));
  for (const run of state.memory.runs) {
    const card = memoryNode('article', `card memory-run-card ${run.status}`);
    card.append(memoryNode('h3', '', `Dreaming · ${run.trigger || 'manual'}`));
    card.append(memoryNode('p', 'memory-score', `${run.status} · ${formatTime(run.created_at)}${run.error ? ` · ${run.error}` : ''}`));
    const s = run.stats || {};
    card.append(memoryNode('p', '', `检查 ${s.examined || 0} · 更新 ${s.updated || 0} · 合并 ${s.merged || 0} · 归档 ${s.archived || 0} · Wiki ${s.pages || 0}`));
    root.append(card);
  }
}

function renderMemoryPanel() {
  const root = $('#panel-memory');
  if (!root) return;
  root.replaceChildren();
  root.append(memorySummary(), memoryToolbar());
  renderMemoryTabs(root);
  if (state.memory.loading) { root.append(memoryNode('div', 'empty-mini', '正在整理记忆…')); return; }
  if (state.memory.tab === 'notes') renderNotesSection(root);
  else if (state.memory.tab === 'wiki') renderWikiSection(root);
  else if (state.memory.tab === 'transcripts') renderTranscriptsSection(root);
  else renderRunsSection(root);
}

async function init() {
  bind(); connectEvents();
  try { await waitForRouter(); await refresh(); if (!state.currentSessionId && state.sessions[0]) await loadSession(state.sessions[0].id); else if (!state.sessions.length) { const session = await api('/api/sessions', { method: 'POST', body: JSON.stringify({ title: '新会话' }) }); state.currentSessionId = session.id; await loadSessions(); await loadSession(session.id); } }
  catch (error) { toast(error.message); }
  $('#prompt').focus();
}
init();
















