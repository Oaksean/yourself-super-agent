import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { resolveSafePath, assertNoSecretFile } from '../core/security.mjs';

const IGNORED = new Set(['.git', 'node_modules', '.cache', '.codex', '.cargo', '.rustup', 'AppData', 'Application Data', 'dist', 'build', 'coverage']);
const TEXT_EXTENSIONS = new Set(['.md', '.txt', '.json', '.js', '.mjs', '.cjs', '.ts', '.tsx', '.jsx', '.css', '.html', '.htm', '.py', '.rs', '.go', '.java', '.c', '.cpp', '.h', '.hpp', '.yaml', '.yml', '.toml', '.ini', '.xml', '.csv', '.log', '.ps1', '.sh', '.sql']);

function bounded(value, max = 40000) {
  const text = typeof value === 'string' ? value : JSON.stringify(value, null, 2);
  return text.length > max ? `${text.slice(0, max)}\n...[已截断]` : text;
}

function workspacePath(inputPath, workspace) {
  const raw = typeof inputPath === 'string' ? inputPath.trim() : '';
  if (!raw) return workspace;
  return path.isAbsolute(raw) ? raw : path.resolve(workspace, raw);
}

async function listFiles({ path: inputPath, depth = 2, maxEntries = 500 }, context) {
  const root = resolveSafePath(workspacePath(inputPath, context.workspace), context.roots, { mustExist: true });
  const maxDepth = Math.max(0, Math.min(6, Number(depth) || 0));
  const limit = Math.max(1, Math.min(2000, Number(maxEntries) || 500));
  const deadline = Date.now() + 15000;
  const output = [];
  async function walk(dir, currentDepth) {
    if (output.length >= limit || currentDepth > maxDepth || Date.now() >= deadline) return;
    let entries;
    try { entries = await fs.readdir(dir, { withFileTypes: true }); }
    catch { return; }
    entries.sort((a, b) => Number(b.isDirectory()) - Number(a.isDirectory()) || a.name.localeCompare(b.name));
    for (const entry of entries) {
      if (output.length >= limit || Date.now() >= deadline) break;
      if (IGNORED.has(entry.name) || entry.isSymbolicLink()) continue;
      const full = path.join(dir, entry.name);
      const relative = path.relative(root, full) || '.';
      output.push({ path: relative, type: entry.isDirectory() ? 'directory' : 'file', size: null });
      if (entry.isDirectory()) await walk(full, currentDepth + 1);
    }
  }
  await walk(root, 0);
  return { root, entries: output, truncated: output.length >= limit || Date.now() >= deadline };
}

async function readFile({ path: inputPath, startLine = 1, maxLines = 300 }, context) {
  const file = resolveSafePath(workspacePath(inputPath, context.workspace), context.roots, { mustExist: true });
  assertNoSecretFile(file);
  const stat = await fs.stat(file);
  if (!stat.isFile()) throw new Error('目标不是普通文件');
  if (stat.size > 2_000_000) throw new Error(`文件过大 (${stat.size} bytes)，请使用 search_text 或分段读取`);
  const lines = (await fs.readFile(file, 'utf8')).split(/\r?\n/);
  const start = Math.max(1, Number(startLine) || 1) - 1;
  const count = Math.max(1, Math.min(1000, Number(maxLines) || 300));
  return {
    path: file,
    totalLines: lines.length,
    startLine: start + 1,
    endLine: Math.min(lines.length, start + count),
    content: lines.slice(start, start + count).map((line, index) => `${String(start + index + 1).padStart(5)} | ${line}`).join('\n'),
  };
}

async function searchText({ query, path: inputPath, maxMatches = 100 }, context) {
  if (!query || String(query).length < 2) throw new Error('搜索词至少需要 2 个字符');
  const root = resolveSafePath(workspacePath(inputPath, context.workspace), context.roots, { mustExist: true });
  const needle = String(query).toLowerCase();
  const limit = Math.max(1, Math.min(1000, Number(maxMatches) || 100));
  const deadline = Date.now() + 30000;
  const matches = [];
  let scanned = 0;
  async function walk(dir) {
    if (matches.length >= limit || scanned >= 3000 || Date.now() >= deadline) return;
    let entries;
    try { entries = await fs.readdir(dir, { withFileTypes: true }); }
    catch { return; }
    for (const entry of entries) {
      if (matches.length >= limit || scanned >= 3000 || Date.now() >= deadline) break;
      if (IGNORED.has(entry.name) || entry.isSymbolicLink()) continue;
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) { await walk(full); continue; }
      if (!TEXT_EXTENSIONS.has(path.extname(entry.name).toLowerCase())) continue;
      let stat;
      try { stat = await fs.stat(full); } catch { continue; }
      if (!stat.isFile() || stat.size > 1_000_000) continue;
      scanned += 1;
      let content;
      try { content = await fs.readFile(full, 'utf8'); } catch { continue; }
      const lines = content.split(/\r?\n/);
      for (let index = 0; index < lines.length && matches.length < limit; index += 1) {
        if (lines[index].toLowerCase().includes(needle)) {
          matches.push({ path: path.relative(root, full), line: index + 1, text: lines[index].slice(0, 300) });
        }
      }
    }
  }
  await walk(root);
  return { root, query: String(query), scannedFiles: scanned, matches, truncated: matches.length >= limit || scanned >= 3000 || Date.now() >= deadline };
}

async function writeFile({ path: inputPath, content, append = false }, context) {
  const file = resolveSafePath(workspacePath(inputPath, context.workspace), context.roots);
  assertNoSecretFile(file);
  const details = { operation: append ? 'append' : 'write', path: file, bytes: Buffer.byteLength(String(content ?? ''), 'utf8') };
  const allowed = await context.requestApproval('file_write', details);
  if (!allowed) throw new Error('用户拒绝文件写入');
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, String(content ?? ''), { encoding: 'utf8', flag: append ? 'a' : 'w' });
  return { path: file, bytes: details.bytes, appended: Boolean(append) };
}

async function runCommand({ command, cwd, timeoutMs = 60000 }, context) {
  if (!command || typeof command !== 'string') throw new Error('command 不能为空');
  const workdir = resolveSafePath(workspacePath(cwd, context.workspace), context.roots, { mustExist: true });
  const allowed = await context.requestApproval('run_command', { command, cwd: workdir, timeoutMs });
  if (!allowed) throw new Error('用户拒绝执行命令');

  return await new Promise((resolve, reject) => {
    const child = spawn(command, {
      cwd: workdir,
      shell: true,
      windowsHide: true,
      env: { ...process.env, AGENT_WORKER: '1' },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';
    let finished = false;
    const timer = setTimeout(() => {
      if (!finished) {
        child.kill('SIGTERM');
        reject(new Error(`命令超时 (${timeoutMs} ms)`));
      }
    }, Math.max(1000, Math.min(600000, Number(timeoutMs) || 60000)));
    child.stdout.on('data', (chunk) => { if (stdout.length < 60000) stdout += chunk.toString(); });
    child.stderr.on('data', (chunk) => { if (stderr.length < 30000) stderr += chunk.toString(); });
    child.on('error', (error) => { finished = true; clearTimeout(timer); reject(error); });
    child.on('close', (code) => {
      finished = true;
      clearTimeout(timer);
      resolve({ command, cwd: workdir, exitCode: code, stdout: bounded(stdout, 60000), stderr: bounded(stderr, 30000) });
    });
  });
}

export const toolDefinitions = [
  { type: 'function', function: { name: 'list_files', description: '列出工作区内的文件和目录，适合先了解项目结构。', parameters: { type: 'object', properties: { path: { type: 'string' }, depth: { type: 'integer', minimum: 0, maximum: 6 }, maxEntries: { type: 'integer', minimum: 1, maximum: 2000 } } } } },
  { type: 'function', function: { name: 'read_file', description: '读取工作区内文本文件的指定行范围。', parameters: { type: 'object', properties: { path: { type: 'string' }, startLine: { type: 'integer' }, maxLines: { type: 'integer' } }, required: ['path'] } } },
  { type: 'function', function: { name: 'search_text', description: '在工作区内递归搜索文本。', parameters: { type: 'object', properties: { query: { type: 'string' }, path: { type: 'string' }, maxMatches: { type: 'integer' } }, required: ['query'] } } },
  { type: 'function', function: { name: 'memory_search', description: '只读检索 Router 的长期记忆笔记与 Wiki；不会修改记忆。', parameters: { type: 'object', properties: { query: { type: 'string' }, topK: { type: 'integer', minimum: 1, maximum: 12 } }, required: ['query'] } } },
  { type: 'function', function: { name: 'memory_read_page', description: '读取长期记忆 Wiki 页面详情；只读。', parameters: { type: 'object', properties: { id: { type: 'string' }, slug: { type: 'string' } }, required: [] } } },
  { type: 'function', function: { name: 'write_file', description: '写入或追加工作区文件，必须经过用户审批。', parameters: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' }, append: { type: 'boolean' } }, required: ['path', 'content'] } } },
  { type: 'function', function: { name: 'run_command', description: '在指定工作目录执行命令，必须经过用户审批。', parameters: { type: 'object', properties: { command: { type: 'string' }, cwd: { type: 'string' }, timeoutMs: { type: 'integer' } }, required: ['command'] } } },
  { type: 'function', function: { name: 'report_progress', description: '报告当前进展，不改变工作区。', parameters: { type: 'object', properties: { message: { type: 'string' } }, required: ['message'] } } },
];

export function toolsForCapabilities(capabilities = ['read']) {
  const allowed = new Set(['list_files', 'read_file', 'search_text', 'report_progress', 'memory_search', 'memory_read_page']);
  if (capabilities.includes('write')) allowed.add('write_file');
  if (capabilities.includes('execute')) allowed.add('run_command');
  return toolDefinitions.filter((definition) => allowed.has(definition.function.name));
}

export async function executeTool(name, args, context) {
  switch (name) {
    case 'list_files': return await listFiles(args || {}, context);
    case 'read_file': return await readFile(args || {}, context);
    case 'search_text': return await searchText(args || {}, context);
    case 'memory_search': return await context.requestMemory('memory_search', args || {});
    case 'memory_read_page': return await context.requestMemory('memory_read_page', args || {});
    case 'write_file': return await writeFile(args || {}, context);
    case 'run_command': return await runCommand(args || {}, context);
    case 'report_progress': return { progress: String(args?.message || '') };
    default: throw new Error(`未知工具: ${name}`);
  }
}

export { listFiles, readFile, searchText, writeFile, runCommand };

