import readline from 'node:readline';
import path from 'node:path';
import { executeTool, toolsForCapabilities, listFiles, readFile } from './tools.mjs';

const send = (message) => {
  process.stdout.write(`${JSON.stringify({ ...message, ts: new Date().toISOString() })}\n`);
};

const pending = new Map();
let task = null;
let cancelled = false;
let activeContext = null;
let currentProgress = 'Worker 正在初始化';
let taskStartedAt = 0;
let heartbeatTimer = null;

function setProgress(progress, detail = '') {
  currentProgress = String(progress || currentProgress).slice(0, 500);
  send({ type: 'progress', progress: currentProgress, detail });
}

function startHeartbeat() {
  stopHeartbeat();
  const intervalMs = Math.max(1000, Number(process.env.AGENT_TASK_HEARTBEAT_MS) || 10000);
  heartbeatTimer = setInterval(() => {
    send({
      type: 'heartbeat',
      progress: currentProgress,
      elapsedMs: Date.now() - taskStartedAt,
    });
  }, intervalMs);
  heartbeatTimer.unref?.();
}

function stopHeartbeat() {
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  heartbeatTimer = null;
}

async function executeToolWithTimeout(name, args, context) {
  const requested = Number(args?.timeoutMs) || 0;
  const timeoutMs = name === 'run_command'
    ? Math.max(120000, Math.min(615000, requested + 30000))
    : 120000;
  let timer;
  try {
    return await Promise.race([
      executeTool(name, args || {}, context),
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(`工具 ${name} 超过 ${Math.round(timeoutMs / 1000)} 秒，已中止本轮等待`)), timeoutMs);
        timer.unref?.();
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

function request(name, payload, timeoutMs = 180000) {
  const requestId = `${name}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      pending.delete(requestId);
      reject(new Error(`${name} 等待超时`));
    }, timeoutMs);
    pending.set(requestId, { resolve, reject, timer });
    send({ type: name, requestId, ...payload });
  });
}

function handleResponse(message) {
  const entry = pending.get(message.requestId);
  if (!entry) return;
  clearTimeout(entry.timer);
  pending.delete(message.requestId);
  if (message.error) entry.reject(new Error(message.error));
  else entry.resolve(message.result ?? message.approved ?? message);
}

async function requestLLM(messages, options) {
  return await request('llm_request', { messages, options }, options?.timeoutMs || 180000);
}

async function requestMemory(name, args) {
  return await request(name, args, 30000);
}

async function requestApproval(kind, details) {
  const response = await request('approval_request', { kind, details }, 10 * 60 * 1000);
  // request() resolves the transport payload itself for approval responses,
  // so a successful approval arrives as boolean `true` rather than an object.
  return response === true || response?.approved === true || response?.result === true;
}

function extractCandidatePath(text) {
  const windowsPath = String(text).match(/[A-Za-z]:[\\/][^\s"'<>|]+/);
  if (windowsPath) return windowsPath[0].replace(/[),.;，。；]+$/, '');
  const quoted = String(text).match(/[`"']([^`"']+\.[A-Za-z0-9]{1,8})[`"']/);
  if (quoted) return quoted[1];
  const relative = String(text).match(/((?:[\w.-]+[\\/])*[\w.-]+\.(?:md|txt|json|js|mjs|cjs|ts|tsx|jsx|css|html|py|rs|go|ya?ml|toml|ps1|sh))/i);
  return relative ? relative[1] : null;
}

async function fallbackAgent(currentTask, context) {
  const capabilities = new Set(currentTask.capabilities || ['read']);
  if (!capabilities.has('read')) {
    return {
      content: '当前未配置 LLM API Key，Worker 只能提供本地只读演示；该任务需要写文件或执行命令能力，已安全停止。',
      fallback: true,
    };
  }
  const candidate = extractCandidatePath(currentTask.prompt);
  let listing;
  try {
    listing = await listFiles({ path: candidate || context.workspace, depth: candidate ? 0 : 2, maxEntries: 250 }, context);
  } catch {
    listing = await listFiles({ path: context.workspace, depth: 2, maxEntries: 250 }, context);
  }
  const files = listing.entries.filter((entry) => entry.type === 'file');
  const interesting = files
    .filter((entry) => /(^|[\\/])(readme|package|pyproject|cargo|go\.mod|agents|config)[^\\/]*\./i.test(entry.path))
    .slice(0, 6);
  const samples = [];
  for (const entry of interesting) {
    try {
      const absolute = path.resolve(listing.root, entry.path);
      const result = await readFile({ path: absolute, maxLines: 120 }, context);
      samples.push(`## ${entry.path}\n${result.content.slice(0, 10000)}`);
    } catch {
      // Ignore files that are not readable as text.
    }
  }
  const summary = [
    `已对本地路径完成只读检查：${listing.root}`,
    `共发现 ${files.length} 个文件、${listing.entries.length - files.length} 个目录。`,
    files.slice(0, 40).map((entry) => `- ${entry.path}`).join('\n'),
    samples.length ? `\n关键文件摘录：\n${samples.join('\n\n')}` : '',
    '\n说明：当前是内置无 API Key 回退模式，只做结构扫描和关键文件摘录；配置 LLM 后可进行完整推理与多步工具调用。',
  ].filter(Boolean).join('\n');
  return { content: summary, fallback: true };
}

async function runAgent(currentTask, context) {
  const tools = toolsForCapabilities(currentTask.capabilities || ['read']);
  const role = currentTask.agentRole || 'general';
  const roleRules = {
    researcher: '你是研究/检索 Agent。优先收集可核查证据，明确来源与不确定性；除非任务明确要求，不要实施代码修改。',
    implementer: '你是执行 Agent。按分配边界完成实现或产物，使用工具验证结果，并明确列出改动路径与残留风险。',
    reviewer: '你是独立校验 Agent。不要扩大实现范围；逐项检查上游结果是否满足验收标准，输出 pass/revise/reject、证据与问题清单。',
    arbiter: '你是仲裁 Agent。只在上游结论冲突或风险无法收敛时作出有证据的最终裁决，并说明取舍。',
    archivist: '你是归档 Agent。把已确认结果整理成结构清晰、可追溯的最终产物，不引入未经上游验证的新事实。',
    general: '你是通用 Agent。严格完成分配的子任务，并提交可供下游直接使用的交接结果。',
  }[role] || '严格完成分配的子任务，并提交可供下游直接使用的交接结果。';
  const system = [
    '你是本地超级智能体中的一次性 Worker Agent，参与中心化多智能体协作。',
    '你只处理分配给你的任务。不得修改长期记忆；可按需通过 memory_search / memory_read_page 进行只读检索。',
    roleRules,
    '上游交接由 Coordinator 注入。不得假设 Agent 之间存在隐藏通信，也不得重复上游已经完成的工作。',
    '所有文件操作必须使用工具，不要臆造文件内容。',
    '工作区边界由运行时强制校验；不要尝试越界或读取 secrets/.env。',
    '写文件和执行命令会触发用户审批。',
    '完成后给出简洁但可核查的结果：做了什么、发现什么、产物路径、未解决问题。',
    `Agent 角色: ${role}`,
    `任务能力: ${(currentTask.capabilities || ['read']).join(', ')}`,
    `隔离级别: ${currentTask.isolation}`,
    `工作区: ${context.workspace}`,
    `预期产出: ${currentTask.expectedOutput || '完成任务并汇报'}`,
    `监督轮次: ${currentTask.attempt || 1}/${currentTask.maxAttempts || 3}`,
  ].join('\n');
  const supervisor = currentTask.supervisor || {};
  const continuation = supervisor.partialResult
    ? `\n\n这是自动续跑轮次。上一轮未完成前的结果如下，请先检查工作区里已经生成的产物，只补齐缺口，不要从头重做：\n${String(supervisor.partialResult).slice(0, 12000)}`
    : (supervisor.lastFailure ? `\n\n这是自动恢复轮次。上一轮中断原因：${supervisor.lastFailure}` : '');
  const messages = [
    { role: 'system', content: system },
    { role: 'user', content: `${currentTask.prompt}${continuation}` },
  ];
  let lastContent = '';
  for (let step = 0; step < 12 && !cancelled; step += 1) {
    let response;
    try {
      setProgress(`第 ${currentTask.attempt || 1} 轮：等待模型响应`);
      response = await requestLLM(messages, {
        model: currentTask.workerModel || undefined,
        tools,
        toolChoice: 'auto',
        temperature: 0.1,
      });
    } catch (error) {
      if (!lastContent) return await fallbackAgent(currentTask, context);
      throw error;
    }
    const message = response.message || { role: 'assistant', content: response.content || '' };
    setProgress(`第 ${currentTask.attempt || 1} 轮：模型已响应，正在处理`);
    messages.push(message);
    lastContent = message.content || lastContent;
    const toolCalls = message.tool_calls || response.toolCalls || [];
    if (!toolCalls.length) {
      return { content: message.content || lastContent || 'Worker 已完成，但没有返回文本结果。', steps: step + 1 };
    }
    for (const call of toolCalls) {
      const name = call.function?.name;
      let args = {};
      try { args = JSON.parse(call.function?.arguments || '{}'); } catch { args = {}; }
      let result;
      try {
        setProgress(`正在执行 ${name}`, JSON.stringify(args).slice(0, 500));
        send({ type: 'transcript', source: 'worker.tool_call', content: JSON.stringify({ tool: name, args }), metadata: { taskId: currentTask.id, tool: name } });
        result = await executeToolWithTimeout(name, args, context);
        send({ type: 'transcript', source: 'worker.tool_result', content: JSON.stringify(result).slice(0, 100000), metadata: { taskId: currentTask.id, tool: name } });
        if (name === 'report_progress') setProgress(result.progress, `工具: ${name}`);
        else setProgress(`${name} 已完成，等待下一轮决策`, `工具: ${name}`);
      } catch (error) {
        result = { error: error.message, tool: name };
        setProgress(`${name} 失败，准备调整方案`, error.message);
      }
      messages.push({ role: 'tool', tool_call_id: call.id, name, content: JSON.stringify(result).slice(0, 60000) });
    }
  }
  if (cancelled) throw new Error('Worker 被取消');
  return { content: lastContent || 'Worker 达到最大工具调用步数，尚未形成最终结论。', steps: 12, incomplete: true };
}

async function handleTask(message) {
  task = message.task;
  cancelled = false;
  const workspace = task.workspace || message.workspace;
  activeContext = {
    workspace,
    roots: message.roots,
    task,
    requestApproval,
    requestMemory,
  };
  taskStartedAt = Date.now();
  send({ type: 'started', taskId: task.id, pid: process.pid });
  setProgress(`第 ${task.attempt || 1}/${task.maxAttempts || 3} 轮：Worker 已启动`, task.title);
  startHeartbeat();
  try {
    const result = await runAgent(task, activeContext);
    if (!cancelled) {
      send({
        type: 'result',
        taskId: task.id,
        result: result.content,
        metadata: {
          steps: result.steps || 0,
          fallback: Boolean(result.fallback),
          incomplete: Boolean(result.incomplete),
          attempt: task.attempt || 1,
        },
      });
    }
  } catch (error) {
    if (!cancelled) send({ type: 'error', taskId: task.id, error: error.stack || error.message });
  } finally {
    stopHeartbeat();
  }
  activeContext = null;
}

const input = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
input.on('line', (line) => {
  if (!line.trim()) return;
  let message;
  try { message = JSON.parse(line); } catch (error) { send({ type: 'error', error: `Worker 收到无效 JSON: ${error.message}` }); return; }
  if (message.type === 'task') {
    handleTask(message).catch((error) => send({ type: 'error', error: error.stack || error.message }));
    return;
  }
  if (message.type === 'cancel') {
    cancelled = true;
    stopHeartbeat();
    for (const entry of pending.values()) {
      clearTimeout(entry.timer);
      entry.reject(new Error('Worker 已取消'));
    }
    pending.clear();
    send({ type: 'cancelled' });
    setTimeout(() => process.exit(0), 50);
    return;
  }
  if (message.requestId && pending.has(message.requestId)) handleResponse(message);
});

process.on('uncaughtException', (error) => send({ type: 'error', error: error.stack || error.message }));
process.on('unhandledRejection', (error) => send({ type: 'error', error: String(error?.stack || error) }));


