// Tauri shell for Local Super Agent.
//
// The shell is deliberately thin ("桌面壳只负责呈现和交互"):
//   * It starts the Node Router daemon as a managed child process on launch.
//   * It exposes a few read-only commands to the webview.
//   * It supervises the Router and terminates it on app exit.
//
// All agent logic stays in the Node / Worker layer. This process carries no
// routing, memory or tool behavior of its own.

use std::collections::HashSet;
use std::fs::OpenOptions;
use std::io::{BufRead, BufReader, Read, Write};
use std::net::TcpStream;
use std::path::PathBuf;
use std::process::{Child, Command, Stdio};
use std::sync::{Mutex, OnceLock};
use std::time::{Duration, Instant};
use tauri::menu::{Menu, MenuItem};
use tauri::tray::TrayIconBuilder;
use tauri::{AppHandle, Manager, RunEvent, State};
use tauri_plugin_notification::NotificationExt;

#[cfg(windows)]
use std::os::windows::process::CommandExt;

#[cfg(windows)]
const CREATE_NO_WINDOW: u32 = 0x0800_0000;

/// Port the Router daemon listens on. Must match config/default.json.
const ROUTER_PORT: u16 = 4317;

struct RouterProcess(Mutex<Option<Child>>);

/// True when `dir` looks like the Local Super Agent application root.
fn looks_like_app_root(dir: &PathBuf) -> bool {
    dir.join("bin").join("super-agent.mjs").exists()
}

/// Resolve the directory that holds `bin/`, `src/`, `config/` and `native/`.
///
/// Tauri installs `../`-style bundle resources one level up inside the install
/// directory (NSIS/MSI place them under `_up_`), so the shell probes a few
/// layout shapes before giving up:
///   <exe_dir>/            resources copied next to the executable
///   <exe_dir>/_up_/       Tauri bundle resources sourced from the parent dir
///   <exe_dir>/resources/  generic resource layout
fn project_root() -> PathBuf {
    // Development: Cargo runs from src-tauri, so the project root is its parent.
    if cfg!(debug_assertions) {
        if let Ok(manifest_dir) = std::env::var("CARGO_MANIFEST_DIR") {
            if let Some(parent) = PathBuf::from(manifest_dir).parent() {
                let parent = parent.to_path_buf();
                if looks_like_app_root(&parent) {
                    return parent;
                }
            }
        }
    }

    if let Ok(exe) = std::env::current_exe() {
        if let Some(dir) = exe.parent() {
            let candidates = [
                dir.to_path_buf(),
                dir.join("_up_"),
                dir.join("resources"),
                dir.join("resources").join("_up_"),
            ];
            for candidate in candidates {
                if looks_like_app_root(&candidate) {
                    return candidate;
                }
            }
        }
    }

    std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."))
}

/// Writable per-user state directory (sessions, memory, logs, saved settings).
///
/// The install directory may live under Program Files and be read-only, so the
/// Router keeps its SQLite database, logs and `config.local.json` here.
fn user_data_dir() -> PathBuf {
    let base = std::env::var("LOCALAPPDATA")
        .ok()
        .filter(|value| !value.trim().is_empty())
        .map(PathBuf::from)
        .or_else(|| std::env::var("XDG_DATA_HOME").ok().map(PathBuf::from))
        .or_else(|| {
            std::env::var("USERPROFILE")
                .ok()
                .map(|home| PathBuf::from(home).join("AppData").join("Local"))
        })
        .unwrap_or_else(std::env::temp_dir);
    base.join("LocalSuperAgent")
}

fn node_binary(root: &PathBuf) -> PathBuf {
    if let Ok(explicit) = std::env::var("AGENT_NODE_BINARY") {
        let candidate = PathBuf::from(explicit);
        if candidate.exists() {
            return candidate;
        }
    }

    let bundled = if cfg!(windows) {
        root.join("runtime").join("node.exe")
    } else {
        root.join("runtime").join("node")
    };
    if bundled.exists() {
        return bundled;
    }

    if cfg!(windows) {
        PathBuf::from("node.exe")
    } else {
        PathBuf::from("node")
    }
}

fn spawn_router(root: &PathBuf) -> std::io::Result<Child> {
    let entry = root.join("bin").join("super-agent.mjs");
    let node = node_binary(root);
    let data_dir = user_data_dir();
    let log_dir = data_dir.join("logs");
    let _ = std::fs::create_dir_all(&data_dir);
    let _ = std::fs::create_dir_all(&log_dir);
    let stdout = OpenOptions::new()
        .create(true)
        .append(true)
        .open(log_dir.join("router.stdout.log"))?;
    let stderr = OpenOptions::new()
        .create(true)
        .append(true)
        .open(log_dir.join("router.stderr.log"))?;
    shell_log(&format!(
        "starting router: node={} entry={} root={}",
        node.display(),
        entry.display(),
        root.display()
    ));

    let mut command = Command::new(&node);
    command
        .arg(&entry)
        .current_dir(root)
        .stdin(Stdio::null())
        .stdout(Stdio::from(stdout))
        .stderr(Stdio::from(stderr))
        .env("AGENT_SHELL", "tauri")
        .env("AGENT_DATA_DIR", &data_dir)
        .env("AGENT_LOG_DIR", &log_dir);
    #[cfg(windows)]
    command.creation_flags(CREATE_NO_WINDOW);

    let child = command.spawn()?;
    shell_log(&format!("router spawned: pid={}", child.id()));
    Ok(child)
}

/// Minimal blocking HTTP/1.0 GET against the Router's loopback port.
/// Implemented with std::net only, so the shell needs no HTTP crate.
fn http_get(path: &str) -> Result<String, String> {
    let address = format!("127.0.0.1:{ROUTER_PORT}");
    let mut stream =
        TcpStream::connect(&address).map_err(|error| format!("无法连接 Router: {error}"))?;
    stream
        .set_read_timeout(Some(Duration::from_secs(5)))
        .map_err(|error| error.to_string())?;
    let request = format!("GET {path} HTTP/1.0\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n");
    stream
        .write_all(request.as_bytes())
        .map_err(|error| error.to_string())?;

    let mut response = String::new();
    stream
        .read_to_string(&mut response)
        .map_err(|error| error.to_string())?;

    match response.split_once("\r\n\r\n") {
        Some((head, body))
            if head.starts_with("HTTP/1.1 200") || head.starts_with("HTTP/1.0 200") =>
        {
            Ok(body.to_string())
        }
        Some((head, _)) => Err(format!(
            "Router 返回异常状态: {}",
            head.lines().next().unwrap_or("")
        )),
        None => Err("Router 响应格式异常".to_string()),
    }
}

fn short_text(value: &str, limit: usize) -> String {
    let trimmed = value.trim().replace('\n', " ");
    if trimmed.chars().count() <= limit {
        trimmed
    } else {
        trimmed.chars().take(limit).collect::<String>() + "…"
    }
}

fn shell_log(message: &str) {
    let dir = user_data_dir().join("logs");
    let _ = std::fs::create_dir_all(&dir);
    if let Ok(mut file) = OpenOptions::new()
        .create(true)
        .append(true)
        .open(dir.join("shell.log"))
    {
        let timestamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|value| value.as_secs())
            .unwrap_or_default();
        let _ = writeln!(file, "[{timestamp}] {message}");
    }
}

fn show_task_notification(app: &AppHandle, title: &str, body: &str) -> bool {
    let sent = match app.notification().builder().title(title).body(body).show() {
        Ok(()) => {
            shell_log(&format!("notification sent: {title} | {body}"));
            true
        }
        Err(error) => {
            shell_log(&format!("notification failed: {title} | {error}"));
            eprintln!("桌面通知发送失败: {error}");
            false
        }
    };
    if let Some(window) = app.get_webview_window("main") {
        let _ = window.request_user_attention(Some(tauri::UserAttentionType::Informational));
    }
    sent
}

static NOTIFIED_KEYS: OnceLock<Mutex<HashSet<String>>> = OnceLock::new();

fn claim_notification(key: String) -> bool {
    let keys = NOTIFIED_KEYS.get_or_init(|| Mutex::new(HashSet::new()));
    match keys.lock() {
        Ok(mut guard) => guard.insert(key),
        Err(_) => false,
    }
}

fn router_event_key(event: &serde_json::Value) -> Option<String> {
    let kind = event.get("type")?.as_str()?;
    let task = event.get("task")?;
    let task_id = task.get("id")?.as_str()?;
    match kind {
        "task.completed" | "task.failed" => {
            let finished_at = task
                .get("finished_at")
                .and_then(|value| value.as_str())
                .unwrap_or_default();
            Some(format!("{kind}:{task_id}:{finished_at}"))
        }
        "approval.requested" => {
            let approval_id = event
                .get("approval")
                .and_then(|value| value.get("id"))
                .and_then(|value| value.as_str())
                .or_else(|| event.get("approvalId").and_then(|value| value.as_str()))
                .unwrap_or(task_id);
            Some(format!("approval.requested:{approval_id}"))
        }
        _ => None,
    }
}

fn handle_router_event(app: &AppHandle, event: &serde_json::Value) {
    let kind = event
        .get("type")
        .and_then(|value| value.as_str())
        .unwrap_or_default();
    if let Some(key) = router_event_key(event) {
        if !claim_notification(key) {
            return;
        }
    }
    let task = event.get("task");
    let task_title = task
        .and_then(|value| value.get("title"))
        .and_then(|value| value.as_str())
        .unwrap_or("本地任务");
    match kind {
        "task.completed" => {
            show_task_notification(
                app,
                "任务已完成",
                &format!("{}：可以回到应用查看最终结果。", short_text(task_title, 80)),
            );
        }
        "task.failed" => {
            let error = event
                .get("error")
                .and_then(|value| value.as_str())
                .or_else(|| {
                    task.and_then(|value| value.get("error"))
                        .and_then(|value| value.as_str())
                })
                .unwrap_or("任务未能完成，请回到应用查看详情。");
            show_task_notification(
                app,
                "任务需要处理",
                &format!("{}：{}", short_text(task_title, 60), short_text(error, 140)),
            );
        }
        "approval.requested" => {
            show_task_notification(
                app,
                "任务等待审批",
                &format!(
                    "{} 正在等待你的审批，处理后会继续执行。",
                    short_text(task_title, 80)
                ),
            );
        }
        _ => {}
    }
}

/// Poll terminal task state as a backup for SSE drops or malformed chunks.
/// The same in-memory key set de-duplicates notifications with the SSE path.
fn watch_task_completions(app: AppHandle) {
    std::thread::spawn(move || {
        let mut initialized = false;
        loop {
            if let Ok(body) = http_get("/api/tasks") {
                if let Ok(tasks) = serde_json::from_str::<Vec<serde_json::Value>>(&body) {
                    if !initialized {
                        shell_log(&format!(
                            "notification poll initialized with {} tasks",
                            tasks.len()
                        ));
                    }
                    for task in tasks {
                        let status = task
                            .get("status")
                            .and_then(|value| value.as_str())
                            .unwrap_or_default();
                        if !matches!(status, "completed" | "failed") {
                            continue;
                        }
                        let event = serde_json::json!({
                            "type": if status == "completed" { "task.completed" } else { "task.failed" },
                            "task": task
                        });
                        if initialized {
                            handle_router_event(&app, &event);
                        } else if let Some(key) = router_event_key(&event) {
                            // Existing terminal tasks at app launch should not re-notify.
                            let _ = claim_notification(key);
                        }
                    }
                    initialized = true;
                }
            }
            std::thread::sleep(Duration::from_secs(5));
        }
    });
}

/// Keep the local Router alive. A GUI launch may race with runtime startup,
/// and a transient Router crash must not leave the settings page permanently
/// unable to save. Restart only after a sustained health failure.
fn watch_router_health(app: AppHandle) {
    std::thread::spawn(move || {
        let mut unhealthy_since: Option<Instant> = None;
        loop {
            std::thread::sleep(Duration::from_secs(5));
            if http_get("/api/health").is_ok() {
                unhealthy_since = None;
                continue;
            }
            let since = *unhealthy_since.get_or_insert_with(Instant::now);
            if since.elapsed() < Duration::from_secs(15) {
                continue;
            }

            shell_log("router health check failed for 15s; restarting");
            let root = project_root();
            if let Some(state) = app.try_state::<RouterProcess>() {
                if let Ok(mut guard) = state.0.lock() {
                    if let Some(child) = guard.as_mut() {
                        let _ = child.kill();
                        let _ = child.wait();
                    }
                    *guard = None;
                }
                match spawn_router(&root) {
                    Ok(child) => {
                        if let Ok(mut guard) = state.0.lock() {
                            *guard = Some(child);
                        }
                        shell_log("router restart completed");
                    }
                    Err(error) => shell_log(&format!("router restart failed: {error}")),
                }
            }
            unhealthy_since = None;
        }
    });
}

/// Listen to the Router SSE stream even while the main window is hidden.
fn watch_router_events(app: AppHandle) {
    std::thread::spawn(move || loop {
        if let Ok(mut stream) = TcpStream::connect(format!("127.0.0.1:{ROUTER_PORT}")) {
            let _ = stream.set_read_timeout(Some(Duration::from_secs(45)));
            let request = "GET /api/events HTTP/1.1\r\nHost: 127.0.0.1\r\nAccept: text/event-stream\r\nConnection: keep-alive\r\n\r\n";
            if stream.write_all(request.as_bytes()).is_ok() {
                let reader = BufReader::new(stream);
                for line in reader.lines() {
                    let Ok(line) = line else { break };
                    let Some(data) = line.strip_prefix("data: ") else {
                        continue;
                    };
                    if let Ok(event) = serde_json::from_str::<serde_json::Value>(data) {
                        handle_router_event(&app, &event);
                    }
                }
            }
        }
        std::thread::sleep(Duration::from_secs(2));
    });
}
#[tauri::command]
fn agent_health() -> Result<serde_json::Value, String> {
    let body = http_get("/api/health")?;
    serde_json::from_str(&body).map_err(|error| error.to_string())
}

#[tauri::command]
fn agent_port() -> u16 {
    ROUTER_PORT
}

#[tauri::command]
fn open_data_dir() -> Result<String, String> {
    let data = user_data_dir();
    std::fs::create_dir_all(&data).map_err(|error| error.to_string())?;

    #[cfg(windows)]
    {
        let mut command = Command::new("explorer");
        command.arg(&data);
        command.creation_flags(CREATE_NO_WINDOW);
        command.spawn().map_err(|error| error.to_string())?;
    }

    Ok(data.to_string_lossy().to_string())
}

/// Open the native folder picker. The UI saves the returned path through the
/// Router, which validates the directory and adds it to the Worker allow-list.
#[tauri::command]
fn select_task_folder(current: Option<String>) -> Result<Option<String>, String> {
    #[cfg(windows)]
    {
        let script = r#"
Add-Type -AssemblyName System.Windows.Forms
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = '选择 Local Super Agent 任务文件夹'
$dialog.ShowNewFolderButton = $true
$dialog.UseDescriptionForTitle = $true
$initial = $env:LSA_FOLDER_INITIAL
if ($initial -and (Test-Path -LiteralPath $initial -PathType Container)) {
  $dialog.SelectedPath = $initial
}
$result = $dialog.ShowDialog()
if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
  [Console]::Out.Write($dialog.SelectedPath)
}
"#;
        let mut command = Command::new("powershell.exe");
        command.args([
            "-NoLogo",
            "-NoProfile",
            "-NonInteractive",
            "-STA",
            "-WindowStyle",
            "Hidden",
            "-Command",
            script,
        ]);
        if let Some(path) = current.filter(|value| !value.trim().is_empty()) {
            command.env("LSA_FOLDER_INITIAL", path);
        }
        command.creation_flags(CREATE_NO_WINDOW);
        let output = command
            .output()
            .map_err(|error| format!("无法打开文件夹选择器: {error}"))?;
        if !output.status.success() {
            let details = String::from_utf8_lossy(&output.stderr).trim().to_string();
            return Err(if details.is_empty() {
                "文件夹选择器异常退出".to_string()
            } else {
                format!("文件夹选择器异常退出: {details}")
            });
        }
        let selected = String::from_utf8_lossy(&output.stdout).trim().to_string();
        if selected.is_empty() {
            return Ok(None);
        }
        let path = PathBuf::from(&selected);
        if !path.is_dir() {
            return Err(format!("选择的路径不是有效文件夹: {selected}"));
        }
        Ok(Some(path.to_string_lossy().to_string()))
    }
    #[cfg(not(windows))]
    {
        let _ = current;
        Err("当前平台尚未实现原生文件夹选择器".to_string())
    }
}

#[tauri::command]
fn open_task_folder(path: String) -> Result<bool, String> {
    let folder = PathBuf::from(path);
    if !folder.is_dir() {
        return Err("任务文件夹不存在或无法访问".to_string());
    }
    #[cfg(windows)]
    {
        let mut command = Command::new("explorer.exe");
        command.arg(&folder);
        command.creation_flags(CREATE_NO_WINDOW);
        command
            .spawn()
            .map_err(|error| format!("无法打开资源管理器: {error}"))?;
    }
    #[cfg(not(windows))]
    {
        let mut command = Command::new("xdg-open");
        command.arg(&folder);
        command
            .spawn()
            .map_err(|error| format!("无法打开文件管理器: {error}"))?;
    }
    Ok(true)
}

#[tauri::command]
fn restart_router(state: State<RouterProcess>) -> Result<bool, String> {
    let root = project_root();
    let mut guard = state.0.lock().map_err(|error| error.to_string())?;
    if let Some(child) = guard.as_mut() {
        let _ = child.kill();
        let _ = child.wait();
    }
    match spawn_router(&root) {
        Ok(child) => {
            *guard = Some(child);
            Ok(true)
        }
        Err(error) => Err(format!("重启 Router 失败: {error}")),
    }
}

#[tauri::command]
fn shutdown_router(state: State<RouterProcess>) -> Result<bool, String> {
    let mut guard = state.0.lock().map_err(|error| error.to_string())?;
    if let Some(child) = guard.as_mut() {
        let _ = child.kill();
        let _ = child.wait();
    }
    *guard = None;
    Ok(true)
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let root = project_root();

    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_notification::init())
        .on_window_event(|window, event| {
            if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                // Closing the window must not kill a running Worker. The app
                // stays in the tray and the Router keeps supervising tasks.
                api.prevent_close();
                let _ = window.hide();
            }
        })
        .manage(RouterProcess(Mutex::new(None)))
        .setup(move |app| {
            let handle = app.handle().clone();

            // Reuse an already-running Router (for example one started from the
            // CLI, or a leftover from a previous session) instead of racing for
            // the port and crash-looping.
            let already_running = http_get("/api/health").is_ok();
            if already_running {
                eprintln!("检测到已在运行的 Router，直接复用。");
            }

            watch_router_events(app.handle().clone());
            watch_task_completions(app.handle().clone());
            match if already_running {
                Ok(None)
            } else {
                spawn_router(&root).map(Some)
            } {
                Ok(child) => {
                    if let (Some(child), Some(state)) = (child, handle.try_state::<RouterProcess>())
                    {
                        if let Ok(mut guard) = state.0.lock() {
                            *guard = Some(child);
                        }
                    }
                }
                Err(error) => {
                    shell_log(&format!("initial router start failed: {error}"));
                    eprintln!("无法启动 Router daemon: {error}");
                }
            }
            watch_router_health(app.handle().clone());

            // Fit the window to the available screen. The configured default is
            // sized for a 1080p+ display; on smaller or high-DPI screens a window
            // larger than the work area is clipped, so shrink and clamp instead.
            if let Some(window) = app.get_webview_window("main") {
                if let Ok(Some(monitor)) = window.current_monitor() {
                    let scale = monitor.scale_factor();
                    let monitor_size = monitor.size().to_logical::<f64>(scale);
                    let desired_w = 1200.0_f64.min(monitor_size.width - 48.0).max(640.0);
                    let desired_h = 780.0_f64.min(monitor_size.height - 96.0).max(420.0);
                    let _ = window.set_size(tauri::LogicalSize::new(desired_w, desired_h));
                    let _ = window.center();
                }
            }

            // System tray: keeps the Router reachable while the window is hidden.
            let show_item = MenuItem::with_id(app, "show", "显示窗口", true, None::<&str>)?;
            let restart_item =
                MenuItem::with_id(app, "restart", "重启 Router", true, None::<&str>)?;
            let quit_item = MenuItem::with_id(app, "quit", "退出", true, None::<&str>)?;
            let menu = Menu::with_items(app, &[&show_item, &restart_item, &quit_item])?;

            let mut tray_builder = TrayIconBuilder::with_id("main-tray")
                .tooltip("Local Super Agent")
                .menu(&menu)
                .show_menu_on_left_click(false)
                .on_menu_event(|app, event| match event.id.as_ref() {
                    "show" => {
                        if let Some(window) = app.get_webview_window("main") {
                            let _ = window.show();
                            let _ = window.set_focus();
                        }
                    }
                    "restart" => {
                        let root = project_root();
                        if let Some(state) = app.try_state::<RouterProcess>() {
                            if let Ok(mut guard) = state.0.lock() {
                                if let Some(child) = guard.as_mut() {
                                    let _ = child.kill();
                                    let _ = child.wait();
                                }
                                if let Ok(child) = spawn_router(&root) {
                                    *guard = Some(child);
                                }
                            }
                        }
                    }
                    "quit" => app.exit(0),
                    _ => {}
                });

            // Attach the bundled icon when present; otherwise keep the default.
            match app.default_window_icon() {
                Some(icon) => {
                    tray_builder = tray_builder.icon(icon.clone());
                }
                None => {}
            }

            tray_builder.build(app)?;
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            agent_health,
            agent_port,
            open_data_dir,
            select_task_folder,
            open_task_folder,
            restart_router,
            shutdown_router
        ])
        .build(tauri::generate_context!())
        .expect("failed to build Local Super Agent shell")
        .run(|app_handle, event| {
            if let RunEvent::ExitRequested { .. } = event {
                if let Some(state) = app_handle.try_state::<RouterProcess>() {
                    if let Ok(mut guard) = state.0.lock() {
                        if let Some(child) = guard.as_mut() {
                            let _ = child.kill();
                            let _ = child.wait();
                        }
                        *guard = None;
                    }
                }
            }
        });
}
